# 1 "text/lexer.mll"
 
open Parser
open Operators
open Source

let convert_pos pos =
  { file = pos.Lexing.pos_fname;
    line = pos.Lexing.pos_lnum;
    column = pos.Lexing.pos_cnum - pos.Lexing.pos_bol
  }

let region lexbuf =
  let left = convert_pos (Lexing.lexeme_start_p lexbuf) in
  let right = convert_pos (Lexing.lexeme_end_p lexbuf) in
  {left = left; right = right}

let error lexbuf msg = raise (Script.Syntax (region lexbuf, msg))
let error_nest start lexbuf msg =
  lexbuf.Lexing.lex_start_p <- start;
  error lexbuf msg

let unknown lexbuf = error lexbuf ("unknown operator " ^ Lexing.lexeme lexbuf)

let string s =
  let b = Buffer.create (String.length s) in
  let i = ref 1 in
  while !i < String.length s - 1 do
    let c = if s.[!i] <> '\\' then s.[!i] else
      match (incr i; s.[!i]) with
      | 'n' -> '\n'
      | 'r' -> '\r'
      | 't' -> '\t'
      | '\\' -> '\\'
      | '\'' -> '\''
      | '\"' -> '\"'
      | 'u' ->
        let j = !i + 2 in
        i := String.index_from s j '}';
        let n = int_of_string ("0x" ^ String.sub s j (!i - j)) in
        let bs = Utf8.encode [n] in
        Buffer.add_substring b bs 0 (String.length bs - 1);
        bs.[String.length bs - 1]
      | h ->
        incr i;
        Char.chr (int_of_string ("0x" ^ String.make 1 h ^ String.make 1 s.[!i]))
    in Buffer.add_char b c;
    incr i
  done;
  Buffer.contents b

let opt = Lib.Option.get

# 55 "text/lexer.ml"

let rec __ocaml_lex_refill_buf lexbuf _buf _len _curr _last =
  if lexbuf.Lexing.lex_eof_reached then
    256, _buf, _len, _curr, _last
  else begin
    lexbuf.Lexing.lex_curr_pos <- _curr;
    lexbuf.Lexing.lex_last_pos <- _last;
    lexbuf.Lexing.refill_buff lexbuf;
    let _curr = lexbuf.Lexing.lex_curr_pos in
    let _last = lexbuf.Lexing.lex_last_pos in
    let _len = lexbuf.Lexing.lex_buffer_len in
    let _buf = lexbuf.Lexing.lex_buffer in
    if _curr < _len then
      Char.code (Bytes.unsafe_get _buf _curr), _buf, _len, (_curr + 1), _last
    else
      __ocaml_lex_refill_buf lexbuf _buf _len _curr _last
  end

let rec __ocaml_lex_state11 lexbuf _last_action _buf _len _curr _last =
  (* *)
  let _last = _curr in
  let _last_action = 20 in
  let next_char, _buf, _len, _curr, _last =
    if _curr >= _len then
      __ocaml_lex_refill_buf lexbuf _buf _len _curr _last
    else
      Char.code (Bytes.unsafe_get _buf _curr),
      _buf, _len, (_curr + 1), _last
  in
  begin match next_char with
    (* |'"' *)
    | 34 ->
      __ocaml_lex_state29 lexbuf 20 (* = last_action *) _buf _len _curr _last
    (* |'!'|'#'|'$'|'%'|'&'|'\''|'*'|'+'|'-'|'.'|'/'|'0'|'1'|'2'|'3'|'4'|'5'|'6'|'7'|'8'|'9'|':'|'<'|'='|'>'|'?'|'@'|'A'|'B'|'C'|'D'|'E'|'F'|'G'|'H'|'I'|'J'|'K'|'L'|'M'|'N'|'O'|'P'|'Q'|'R'|'S'|'T'|'U'|'V'|'W'|'X'|'Y'|'Z'|'\\'|'^'|'_'|'`'|'a'|'b'|'c'|'d'|'e'|'f'|'g'|'h'|'i'|'j'|'k'|'l'|'m'|'n'|'o'|'p'|'q'|'r'|'s'|'t'|'u'|'v'|'w'|'x'|'y'|'z'|'|'|'~' *)
    |33|35|36|37|38|39|42|43|45|46|47|48|49|50|51|52|53|54|55|56|57|58|60|61|62|63|64|65|66|67|68|69|70|71|72|73|74|75|76|77|78|79|80|81|82|83|84|85|86|87|88|89|90|92|94|95|96|97|98|99|100|101|102|103|104|105|106|107|108|109|110|111|112|113|114|115|116|117|118|119|120|121|122|124|126 ->
      __ocaml_lex_state11 lexbuf 20 (* = last_action *) _buf _len _curr _last
    | _ ->
      let _curr = _last in
      lexbuf.Lexing.lex_curr_pos <- _curr;
      lexbuf.Lexing.lex_last_pos <- _last;
      20 (* = last_action *)
  end

and __ocaml_lex_state24 lexbuf _last_action _buf _len _curr _last =
  (* *)
  let _last = _curr in
  let _last_action = 2 in
  let next_char, _buf, _len, _curr, _last =
    if _curr >= _len then
      __ocaml_lex_refill_buf lexbuf _buf _len _curr _last
    else
      Char.code (Bytes.unsafe_get _buf _curr),
      _buf, _len, (_curr + 1), _last
  in
  begin match next_char with
    (* |'E'|'e' *)
    |69|101 ->
      __ocaml_lex_state30 lexbuf 2 (* = last_action *) _buf _len _curr _last
    (* |'0'|'1'|'2'|'3'|'4'|'5'|'6'|'7'|'8'|'9' *)
    |48|49|50|51|52|53|54|55|56|57 ->
      __ocaml_lex_state24 lexbuf 2 (* = last_action *) _buf _len _curr _last
    (* |'.' *)
    | 46 ->
      __ocaml_lex_state31 lexbuf 2 (* = last_action *) _buf _len _curr _last
    (* |'"' *)
    | 34 ->
      __ocaml_lex_state29 lexbuf 2 (* = last_action *) _buf _len _curr _last
    (* |'_' *)
    | 95 ->
      __ocaml_lex_state33 lexbuf 2 (* = last_action *) _buf _len _curr _last
    (* |'!'|'#'|'$'|'%'|'&'|'\''|'*'|'+'|'-'|'/'|':'|'<'|'='|'>'|'?'|'@'|'A'|'B'|'C'|'D'|'F'|'G'|'H'|'I'|'J'|'K'|'L'|'M'|'N'|'O'|'P'|'Q'|'R'|'S'|'T'|'U'|'V'|'W'|'X'|'Y'|'Z'|'\\'|'^'|'`'|'a'|'b'|'c'|'d'|'f'|'g'|'h'|'i'|'j'|'k'|'l'|'m'|'n'|'o'|'p'|'q'|'r'|'s'|'t'|'u'|'v'|'w'|'x'|'y'|'z'|'|'|'~' *)
    |33|35|36|37|38|39|42|43|45|47|58|60|61|62|63|64|65|66|67|68|70|71|72|73|74|75|76|77|78|79|80|81|82|83|84|85|86|87|88|89|90|92|94|96|97|98|99|100|102|103|104|105|106|107|108|109|110|111|112|113|114|115|116|117|118|119|120|121|122|124|126 ->
      __ocaml_lex_state11 lexbuf 2 (* = last_action *) _buf _len _curr _last
    | _ ->
      let _curr = _last in
      lexbuf.Lexing.lex_curr_pos <- _curr;
      lexbuf.Lexing.lex_last_pos <- _last;
      2 (* = last_action *)
  end

and __ocaml_lex_state29 lexbuf _last_action _buf _len _curr _last =
  let next_char, _buf, _len, _curr, _last =
    if _curr >= _len then
      __ocaml_lex_refill_buf lexbuf _buf _len _curr _last
    else
      Char.code (Bytes.unsafe_get _buf _curr),
      _buf, _len, (_curr + 1), _last
  in
  begin match next_char with
    (* |'\240' *)
    | 240 ->
      let next_char, _buf, _len, _curr, _last =
        if _curr >= _len then
          __ocaml_lex_refill_buf lexbuf _buf _len _curr _last
        else
          Char.code (Bytes.unsafe_get _buf _curr),
          _buf, _len, (_curr + 1), _last
      in
      begin match next_char with
        (* |'\144'|'\145'|'\146'|'\147'|'\148'|'\149'|'\150'|'\151'|'\152'|'\153'|'\154'|'\155'|'\156'|'\157'|'\158'|'\159'|'\160'|'\161'|'\162'|'\163'|'\164'|'\165'|'\166'|'\167'|'\168'|'\169'|'\170'|'\171'|'\172'|'\173'|'\174'|'\175'|'\176'|'\177'|'\178'|'\179'|'\180'|'\181'|'\182'|'\183'|'\184'|'\185'|'\186'|'\187'|'\188'|'\189'|'\190'|'\191' *)
        |144|145|146|147|148|149|150|151|152|153|154|155|156|157|158|159|160|161|162|163|164|165|166|167|168|169|170|171|172|173|174|175|176|177|178|179|180|181|182|183|184|185|186|187|188|189|190|191 ->
          let next_char, _buf, _len, _curr, _last =
            if _curr >= _len then
              __ocaml_lex_refill_buf lexbuf _buf _len _curr _last
            else
              Char.code (Bytes.unsafe_get _buf _curr),
              _buf, _len, (_curr + 1), _last
          in
          begin match next_char with
            (* |'\128'|'\129'|'\130'|'\131'|'\132'|'\133'|'\134'|'\135'|'\136'|'\137'|'\138'|'\139'|'\140'|'\141'|'\142'|'\143'|'\144'|'\145'|'\146'|'\147'|'\148'|'\149'|'\150'|'\151'|'\152'|'\153'|'\154'|'\155'|'\156'|'\157'|'\158'|'\159'|'\160'|'\161'|'\162'|'\163'|'\164'|'\165'|'\166'|'\167'|'\168'|'\169'|'\170'|'\171'|'\172'|'\173'|'\174'|'\175'|'\176'|'\177'|'\178'|'\179'|'\180'|'\181'|'\182'|'\183'|'\184'|'\185'|'\186'|'\187'|'\188'|'\189'|'\190'|'\191' *)
            |128|129|130|131|132|133|134|135|136|137|138|139|140|141|142|143|144|145|146|147|148|149|150|151|152|153|154|155|156|157|158|159|160|161|162|163|164|165|166|167|168|169|170|171|172|173|174|175|176|177|178|179|180|181|182|183|184|185|186|187|188|189|190|191 ->
              let next_char, _buf, _len, _curr, _last =
                if _curr >= _len then
                  __ocaml_lex_refill_buf lexbuf _buf _len _curr _last
                else
                  Char.code (Bytes.unsafe_get _buf _curr),
                  _buf, _len, (_curr + 1), _last
              in
              begin match next_char with
                (* |'\128'|'\129'|'\130'|'\131'|'\132'|'\133'|'\134'|'\135'|'\136'|'\137'|'\138'|'\139'|'\140'|'\141'|'\142'|'\143'|'\144'|'\145'|'\146'|'\147'|'\148'|'\149'|'\150'|'\151'|'\152'|'\153'|'\154'|'\155'|'\156'|'\157'|'\158'|'\159'|'\160'|'\161'|'\162'|'\163'|'\164'|'\165'|'\166'|'\167'|'\168'|'\169'|'\170'|'\171'|'\172'|'\173'|'\174'|'\175'|'\176'|'\177'|'\178'|'\179'|'\180'|'\181'|'\182'|'\183'|'\184'|'\185'|'\186'|'\187'|'\188'|'\189'|'\190'|'\191' *)
                |128|129|130|131|132|133|134|135|136|137|138|139|140|141|142|143|144|145|146|147|148|149|150|151|152|153|154|155|156|157|158|159|160|161|162|163|164|165|166|167|168|169|170|171|172|173|174|175|176|177|178|179|180|181|182|183|184|185|186|187|188|189|190|191 ->
                  __ocaml_lex_state29 lexbuf _last_action _buf _len _curr _last
                | _ ->
                  let _curr = _last in
                  lexbuf.Lexing.lex_curr_pos <- _curr;
                  lexbuf.Lexing.lex_last_pos <- _last;
                  _last_action
              end
            | _ ->
              let _curr = _last in
              lexbuf.Lexing.lex_curr_pos <- _curr;
              lexbuf.Lexing.lex_last_pos <- _last;
              _last_action
          end
        | _ ->
          let _curr = _last in
          lexbuf.Lexing.lex_curr_pos <- _curr;
          lexbuf.Lexing.lex_last_pos <- _last;
          _last_action
      end
    (* |'\224' *)
    | 224 ->
      let next_char, _buf, _len, _curr, _last =
        if _curr >= _len then
          __ocaml_lex_refill_buf lexbuf _buf _len _curr _last
        else
          Char.code (Bytes.unsafe_get _buf _curr),
          _buf, _len, (_curr + 1), _last
      in
      begin match next_char with
        (* |'\160'|'\161'|'\162'|'\163'|'\164'|'\165'|'\166'|'\167'|'\168'|'\169'|'\170'|'\171'|'\172'|'\173'|'\174'|'\175'|'\176'|'\177'|'\178'|'\179'|'\180'|'\181'|'\182'|'\183'|'\184'|'\185'|'\186'|'\187'|'\188'|'\189'|'\190'|'\191' *)
        |160|161|162|163|164|165|166|167|168|169|170|171|172|173|174|175|176|177|178|179|180|181|182|183|184|185|186|187|188|189|190|191 ->
          let next_char, _buf, _len, _curr, _last =
            if _curr >= _len then
              __ocaml_lex_refill_buf lexbuf _buf _len _curr _last
            else
              Char.code (Bytes.unsafe_get _buf _curr),
              _buf, _len, (_curr + 1), _last
          in
          begin match next_char with
            (* |'\128'|'\129'|'\130'|'\131'|'\132'|'\133'|'\134'|'\135'|'\136'|'\137'|'\138'|'\139'|'\140'|'\141'|'\142'|'\143'|'\144'|'\145'|'\146'|'\147'|'\148'|'\149'|'\150'|'\151'|'\152'|'\153'|'\154'|'\155'|'\156'|'\157'|'\158'|'\159'|'\160'|'\161'|'\162'|'\163'|'\164'|'\165'|'\166'|'\167'|'\168'|'\169'|'\170'|'\171'|'\172'|'\173'|'\174'|'\175'|'\176'|'\177'|'\178'|'\179'|'\180'|'\181'|'\182'|'\183'|'\184'|'\185'|'\186'|'\187'|'\188'|'\189'|'\190'|'\191' *)
            |128|129|130|131|132|133|134|135|136|137|138|139|140|141|142|143|144|145|146|147|148|149|150|151|152|153|154|155|156|157|158|159|160|161|162|163|164|165|166|167|168|169|170|171|172|173|174|175|176|177|178|179|180|181|182|183|184|185|186|187|188|189|190|191 ->
              __ocaml_lex_state29 lexbuf _last_action _buf _len _curr _last
            | _ ->
              let _curr = _last in
              lexbuf.Lexing.lex_curr_pos <- _curr;
              lexbuf.Lexing.lex_last_pos <- _last;
              _last_action
          end
        | _ ->
          let _curr = _last in
          lexbuf.Lexing.lex_curr_pos <- _curr;
          lexbuf.Lexing.lex_last_pos <- _last;
          _last_action
      end
    (* |'\241'|'\242'|'\243' *)
    |241|242|243 ->
      let next_char, _buf, _len, _curr, _last =
        if _curr >= _len then
          __ocaml_lex_refill_buf lexbuf _buf _len _curr _last
        else
          Char.code (Bytes.unsafe_get _buf _curr),
          _buf, _len, (_curr + 1), _last
      in
      begin match next_char with
        (* |'\128'|'\129'|'\130'|'\131'|'\132'|'\133'|'\134'|'\135'|'\136'|'\137'|'\138'|'\139'|'\140'|'\141'|'\142'|'\143'|'\144'|'\145'|'\146'|'\147'|'\148'|'\149'|'\150'|'\151'|'\152'|'\153'|'\154'|'\155'|'\156'|'\157'|'\158'|'\159'|'\160'|'\161'|'\162'|'\163'|'\164'|'\165'|'\166'|'\167'|'\168'|'\169'|'\170'|'\171'|'\172'|'\173'|'\174'|'\175'|'\176'|'\177'|'\178'|'\179'|'\180'|'\181'|'\182'|'\183'|'\184'|'\185'|'\186'|'\187'|'\188'|'\189'|'\190'|'\191' *)
        |128|129|130|131|132|133|134|135|136|137|138|139|140|141|142|143|144|145|146|147|148|149|150|151|152|153|154|155|156|157|158|159|160|161|162|163|164|165|166|167|168|169|170|171|172|173|174|175|176|177|178|179|180|181|182|183|184|185|186|187|188|189|190|191 ->
          let next_char, _buf, _len, _curr, _last =
            if _curr >= _len then
              __ocaml_lex_refill_buf lexbuf _buf _len _curr _last
            else
              Char.code (Bytes.unsafe_get _buf _curr),
              _buf, _len, (_curr + 1), _last
          in
          begin match next_char with
            (* |'\128'|'\129'|'\130'|'\131'|'\132'|'\133'|'\134'|'\135'|'\136'|'\137'|'\138'|'\139'|'\140'|'\141'|'\142'|'\143'|'\144'|'\145'|'\146'|'\147'|'\148'|'\149'|'\150'|'\151'|'\152'|'\153'|'\154'|'\155'|'\156'|'\157'|'\158'|'\159'|'\160'|'\161'|'\162'|'\163'|'\164'|'\165'|'\166'|'\167'|'\168'|'\169'|'\170'|'\171'|'\172'|'\173'|'\174'|'\175'|'\176'|'\177'|'\178'|'\179'|'\180'|'\181'|'\182'|'\183'|'\184'|'\185'|'\186'|'\187'|'\188'|'\189'|'\190'|'\191' *)
            |128|129|130|131|132|133|134|135|136|137|138|139|140|141|142|143|144|145|146|147|148|149|150|151|152|153|154|155|156|157|158|159|160|161|162|163|164|165|166|167|168|169|170|171|172|173|174|175|176|177|178|179|180|181|182|183|184|185|186|187|188|189|190|191 ->
              let next_char, _buf, _len, _curr, _last =
                if _curr >= _len then
                  __ocaml_lex_refill_buf lexbuf _buf _len _curr _last
                else
                  Char.code (Bytes.unsafe_get _buf _curr),
                  _buf, _len, (_curr + 1), _last
              in
              begin match next_char with
                (* |'\128'|'\129'|'\130'|'\131'|'\132'|'\133'|'\134'|'\135'|'\136'|'\137'|'\138'|'\139'|'\140'|'\141'|'\142'|'\143'|'\144'|'\145'|'\146'|'\147'|'\148'|'\149'|'\150'|'\151'|'\152'|'\153'|'\154'|'\155'|'\156'|'\157'|'\158'|'\159'|'\160'|'\161'|'\162'|'\163'|'\164'|'\165'|'\166'|'\167'|'\168'|'\169'|'\170'|'\171'|'\172'|'\173'|'\174'|'\175'|'\176'|'\177'|'\178'|'\179'|'\180'|'\181'|'\182'|'\183'|'\184'|'\185'|'\186'|'\187'|'\188'|'\189'|'\190'|'\191' *)
                |128|129|130|131|132|133|134|135|136|137|138|139|140|141|142|143|144|145|146|147|148|149|150|151|152|153|154|155|156|157|158|159|160|161|162|163|164|165|166|167|168|169|170|171|172|173|174|175|176|177|178|179|180|181|182|183|184|185|186|187|188|189|190|191 ->
                  __ocaml_lex_state29 lexbuf _last_action _buf _len _curr _last
                | _ ->
                  let _curr = _last in
                  lexbuf.Lexing.lex_curr_pos <- _curr;
                  lexbuf.Lexing.lex_last_pos <- _last;
                  _last_action
              end
            | _ ->
              let _curr = _last in
              lexbuf.Lexing.lex_curr_pos <- _curr;
              lexbuf.Lexing.lex_last_pos <- _last;
              _last_action
          end
        | _ ->
          let _curr = _last in
          lexbuf.Lexing.lex_curr_pos <- _curr;
          lexbuf.Lexing.lex_last_pos <- _last;
          _last_action
      end
    (* |'\237' *)
    | 237 ->
      let next_char, _buf, _len, _curr, _last =
        if _curr >= _len then
          __ocaml_lex_refill_buf lexbuf _buf _len _curr _last
        else
          Char.code (Bytes.unsafe_get _buf _curr),
          _buf, _len, (_curr + 1), _last
      in
      begin match next_char with
        (* |'\128'|'\129'|'\130'|'\131'|'\132'|'\133'|'\134'|'\135'|'\136'|'\137'|'\138'|'\139'|'\140'|'\141'|'\142'|'\143'|'\144'|'\145'|'\146'|'\147'|'\148'|'\149'|'\150'|'\151'|'\152'|'\153'|'\154'|'\155'|'\156'|'\157'|'\158'|'\159' *)
        |128|129|130|131|132|133|134|135|136|137|138|139|140|141|142|143|144|145|146|147|148|149|150|151|152|153|154|155|156|157|158|159 ->
          let next_char, _buf, _len, _curr, _last =
            if _curr >= _len then
              __ocaml_lex_refill_buf lexbuf _buf _len _curr _last
            else
              Char.code (Bytes.unsafe_get _buf _curr),
              _buf, _len, (_curr + 1), _last
          in
          begin match next_char with
            (* |'\128'|'\129'|'\130'|'\131'|'\132'|'\133'|'\134'|'\135'|'\136'|'\137'|'\138'|'\139'|'\140'|'\141'|'\142'|'\143'|'\144'|'\145'|'\146'|'\147'|'\148'|'\149'|'\150'|'\151'|'\152'|'\153'|'\154'|'\155'|'\156'|'\157'|'\158'|'\159'|'\160'|'\161'|'\162'|'\163'|'\164'|'\165'|'\166'|'\167'|'\168'|'\169'|'\170'|'\171'|'\172'|'\173'|'\174'|'\175'|'\176'|'\177'|'\178'|'\179'|'\180'|'\181'|'\182'|'\183'|'\184'|'\185'|'\186'|'\187'|'\188'|'\189'|'\190'|'\191' *)
            |128|129|130|131|132|133|134|135|136|137|138|139|140|141|142|143|144|145|146|147|148|149|150|151|152|153|154|155|156|157|158|159|160|161|162|163|164|165|166|167|168|169|170|171|172|173|174|175|176|177|178|179|180|181|182|183|184|185|186|187|188|189|190|191 ->
              __ocaml_lex_state29 lexbuf _last_action _buf _len _curr _last
            | _ ->
              let _curr = _last in
              lexbuf.Lexing.lex_curr_pos <- _curr;
              lexbuf.Lexing.lex_last_pos <- _last;
              _last_action
          end
        | _ ->
          let _curr = _last in
          lexbuf.Lexing.lex_curr_pos <- _curr;
          lexbuf.Lexing.lex_last_pos <- _last;
          _last_action
      end
    (* |'\194'|'\195'|'\196'|'\197'|'\198'|'\199'|'\200'|'\201'|'\202'|'\203'|'\204'|'\205'|'\206'|'\207'|'\208'|'\209'|'\210'|'\211'|'\212'|'\213'|'\214'|'\215'|'\216'|'\217'|'\218'|'\219'|'\220'|'\221'|'\222'|'\223' *)
    |194|195|196|197|198|199|200|201|202|203|204|205|206|207|208|209|210|211|212|213|214|215|216|217|218|219|220|221|222|223 ->
      let next_char, _buf, _len, _curr, _last =
        if _curr >= _len then
          __ocaml_lex_refill_buf lexbuf _buf _len _curr _last
        else
          Char.code (Bytes.unsafe_get _buf _curr),
          _buf, _len, (_curr + 1), _last
      in
      begin match next_char with
        (* |'\128'|'\129'|'\130'|'\131'|'\132'|'\133'|'\134'|'\135'|'\136'|'\137'|'\138'|'\139'|'\140'|'\141'|'\142'|'\143'|'\144'|'\145'|'\146'|'\147'|'\148'|'\149'|'\150'|'\151'|'\152'|'\153'|'\154'|'\155'|'\156'|'\157'|'\158'|'\159'|'\160'|'\161'|'\162'|'\163'|'\164'|'\165'|'\166'|'\167'|'\168'|'\169'|'\170'|'\171'|'\172'|'\173'|'\174'|'\175'|'\176'|'\177'|'\178'|'\179'|'\180'|'\181'|'\182'|'\183'|'\184'|'\185'|'\186'|'\187'|'\188'|'\189'|'\190'|'\191' *)
        |128|129|130|131|132|133|134|135|136|137|138|139|140|141|142|143|144|145|146|147|148|149|150|151|152|153|154|155|156|157|158|159|160|161|162|163|164|165|166|167|168|169|170|171|172|173|174|175|176|177|178|179|180|181|182|183|184|185|186|187|188|189|190|191 ->
          __ocaml_lex_state29 lexbuf _last_action _buf _len _curr _last
        | _ ->
          let _curr = _last in
          lexbuf.Lexing.lex_curr_pos <- _curr;
          lexbuf.Lexing.lex_last_pos <- _last;
          _last_action
      end
    (* |' '|'!'|'#'|'$'|'%'|'&'|'\''|'('|')'|'*'|'+'|','|'-'|'.'|'/'|'0'|'1'|'2'|'3'|'4'|'5'|'6'|'7'|'8'|'9'|':'|';'|'<'|'='|'>'|'?'|'@'|'A'|'B'|'C'|'D'|'E'|'F'|'G'|'H'|'I'|'J'|'K'|'L'|'M'|'N'|'O'|'P'|'Q'|'R'|'S'|'T'|'U'|'V'|'W'|'X'|'Y'|'Z'|'['|']'|'^'|'_'|'`'|'a'|'b'|'c'|'d'|'e'|'f'|'g'|'h'|'i'|'j'|'k'|'l'|'m'|'n'|'o'|'p'|'q'|'r'|'s'|'t'|'u'|'v'|'w'|'x'|'y'|'z'|'{'|'|'|'}'|'~' *)
    |32|33|35|36|37|38|39|40|41|42|43|44|45|46|47|48|49|50|51|52|53|54|55|56|57|58|59|60|61|62|63|64|65|66|67|68|69|70|71|72|73|74|75|76|77|78|79|80|81|82|83|84|85|86|87|88|89|90|91|93|94|95|96|97|98|99|100|101|102|103|104|105|106|107|108|109|110|111|112|113|114|115|116|117|118|119|120|121|122|123|124|125|126 ->
      __ocaml_lex_state29 lexbuf _last_action _buf _len _curr _last
    (* |'"' *)
    | 34 ->
      __ocaml_lex_state11 lexbuf _last_action _buf _len _curr _last
    (* |'\\' *)
    | 92 ->
      let next_char, _buf, _len, _curr, _last =
        if _curr >= _len then
          __ocaml_lex_refill_buf lexbuf _buf _len _curr _last
        else
          Char.code (Bytes.unsafe_get _buf _curr),
          _buf, _len, (_curr + 1), _last
      in
      begin match next_char with
        (* |'u' *)
        | 117 ->
          let next_char, _buf, _len, _curr, _last =
            if _curr >= _len then
              __ocaml_lex_refill_buf lexbuf _buf _len _curr _last
            else
              Char.code (Bytes.unsafe_get _buf _curr),
              _buf, _len, (_curr + 1), _last
          in
          begin match next_char with
            (* |'{' *)
            | 123 ->
              let next_char, _buf, _len, _curr, _last =
                if _curr >= _len then
                  __ocaml_lex_refill_buf lexbuf _buf _len _curr _last
                else
                  Char.code (Bytes.unsafe_get _buf _curr),
                  _buf, _len, (_curr + 1), _last
              in
              begin match next_char with
                (* |'0'|'1'|'2'|'3'|'4'|'5'|'6'|'7'|'8'|'9'|'A'|'B'|'C'|'D'|'E'|'F'|'a'|'b'|'c'|'d'|'e'|'f' *)
                |48|49|50|51|52|53|54|55|56|57|65|66|67|68|69|70|97|98|99|100|101|102 ->
                  __ocaml_lex_state68 lexbuf _last_action _buf _len _curr _last
                | _ ->
                  let _curr = _last in
                  lexbuf.Lexing.lex_curr_pos <- _curr;
                  lexbuf.Lexing.lex_last_pos <- _last;
                  _last_action
              end
            | _ ->
              let _curr = _last in
              lexbuf.Lexing.lex_curr_pos <- _curr;
              lexbuf.Lexing.lex_last_pos <- _last;
              _last_action
          end
        (* |'0'|'1'|'2'|'3'|'4'|'5'|'6'|'7'|'8'|'9'|'A'|'B'|'C'|'D'|'E'|'F'|'a'|'b'|'c'|'d'|'e'|'f' *)
        |48|49|50|51|52|53|54|55|56|57|65|66|67|68|69|70|97|98|99|100|101|102 ->
          let next_char, _buf, _len, _curr, _last =
            if _curr >= _len then
              __ocaml_lex_refill_buf lexbuf _buf _len _curr _last
            else
              Char.code (Bytes.unsafe_get _buf _curr),
              _buf, _len, (_curr + 1), _last
          in
          begin match next_char with
            (* |'0'|'1'|'2'|'3'|'4'|'5'|'6'|'7'|'8'|'9'|'A'|'B'|'C'|'D'|'E'|'F'|'a'|'b'|'c'|'d'|'e'|'f' *)
            |48|49|50|51|52|53|54|55|56|57|65|66|67|68|69|70|97|98|99|100|101|102 ->
              __ocaml_lex_state29 lexbuf _last_action _buf _len _curr _last
            | _ ->
              let _curr = _last in
              lexbuf.Lexing.lex_curr_pos <- _curr;
              lexbuf.Lexing.lex_last_pos <- _last;
              _last_action
          end
        (* |'"'|'\''|'\\'|'n'|'r'|'t' *)
        |34|39|92|110|114|116 ->
          __ocaml_lex_state29 lexbuf _last_action _buf _len _curr _last
        | _ ->
          let _curr = _last in
          lexbuf.Lexing.lex_curr_pos <- _curr;
          lexbuf.Lexing.lex_last_pos <- _last;
          _last_action
      end
    (* |'\244' *)
    | 244 ->
      let next_char, _buf, _len, _curr, _last =
        if _curr >= _len then
          __ocaml_lex_refill_buf lexbuf _buf _len _curr _last
        else
          Char.code (Bytes.unsafe_get _buf _curr),
          _buf, _len, (_curr + 1), _last
      in
      begin match next_char with
        (* |'\128'|'\129'|'\130'|'\131'|'\132'|'\133'|'\134'|'\135'|'\136'|'\137'|'\138'|'\139'|'\140'|'\141'|'\142'|'\143' *)
        |128|129|130|131|132|133|134|135|136|137|138|139|140|141|142|143 ->
          let next_char, _buf, _len, _curr, _last =
            if _curr >= _len then
              __ocaml_lex_refill_buf lexbuf _buf _len _curr _last
            else
              Char.code (Bytes.unsafe_get _buf _curr),
              _buf, _len, (_curr + 1), _last
          in
          begin match next_char with
            (* |'\128'|'\129'|'\130'|'\131'|'\132'|'\133'|'\134'|'\135'|'\136'|'\137'|'\138'|'\139'|'\140'|'\141'|'\142'|'\143'|'\144'|'\145'|'\146'|'\147'|'\148'|'\149'|'\150'|'\151'|'\152'|'\153'|'\154'|'\155'|'\156'|'\157'|'\158'|'\159'|'\160'|'\161'|'\162'|'\163'|'\164'|'\165'|'\166'|'\167'|'\168'|'\169'|'\170'|'\171'|'\172'|'\173'|'\174'|'\175'|'\176'|'\177'|'\178'|'\179'|'\180'|'\181'|'\182'|'\183'|'\184'|'\185'|'\186'|'\187'|'\188'|'\189'|'\190'|'\191' *)
            |128|129|130|131|132|133|134|135|136|137|138|139|140|141|142|143|144|145|146|147|148|149|150|151|152|153|154|155|156|157|158|159|160|161|162|163|164|165|166|167|168|169|170|171|172|173|174|175|176|177|178|179|180|181|182|183|184|185|186|187|188|189|190|191 ->
              let next_char, _buf, _len, _curr, _last =
                if _curr >= _len then
                  __ocaml_lex_refill_buf lexbuf _buf _len _curr _last
                else
                  Char.code (Bytes.unsafe_get _buf _curr),
                  _buf, _len, (_curr + 1), _last
              in
              begin match next_char with
                (* |'\128'|'\129'|'\130'|'\131'|'\132'|'\133'|'\134'|'\135'|'\136'|'\137'|'\138'|'\139'|'\140'|'\141'|'\142'|'\143'|'\144'|'\145'|'\146'|'\147'|'\148'|'\149'|'\150'|'\151'|'\152'|'\153'|'\154'|'\155'|'\156'|'\157'|'\158'|'\159'|'\160'|'\161'|'\162'|'\163'|'\164'|'\165'|'\166'|'\167'|'\168'|'\169'|'\170'|'\171'|'\172'|'\173'|'\174'|'\175'|'\176'|'\177'|'\178'|'\179'|'\180'|'\181'|'\182'|'\183'|'\184'|'\185'|'\186'|'\187'|'\188'|'\189'|'\190'|'\191' *)
                |128|129|130|131|132|133|134|135|136|137|138|139|140|141|142|143|144|145|146|147|148|149|150|151|152|153|154|155|156|157|158|159|160|161|162|163|164|165|166|167|168|169|170|171|172|173|174|175|176|177|178|179|180|181|182|183|184|185|186|187|188|189|190|191 ->
                  __ocaml_lex_state29 lexbuf _last_action _buf _len _curr _last
                | _ ->
                  let _curr = _last in
                  lexbuf.Lexing.lex_curr_pos <- _curr;
                  lexbuf.Lexing.lex_last_pos <- _last;
                  _last_action
              end
            | _ ->
              let _curr = _last in
              lexbuf.Lexing.lex_curr_pos <- _curr;
              lexbuf.Lexing.lex_last_pos <- _last;
              _last_action
          end
        | _ ->
          let _curr = _last in
          lexbuf.Lexing.lex_curr_pos <- _curr;
          lexbuf.Lexing.lex_last_pos <- _last;
          _last_action
      end
    (* |'\225'|'\226'|'\227'|'\228'|'\229'|'\230'|'\231'|'\232'|'\233'|'\234'|'\235'|'\236'|'\238'|'\239' *)
    |225|226|227|228|229|230|231|232|233|234|235|236|238|239 ->
      let next_char, _buf, _len, _curr, _last =
        if _curr >= _len then
          __ocaml_lex_refill_buf lexbuf _buf _len _curr _last
        else
          Char.code (Bytes.unsafe_get _buf _curr),
          _buf, _len, (_curr + 1), _last
      in
      begin match next_char with
        (* |'\128'|'\129'|'\130'|'\131'|'\132'|'\133'|'\134'|'\135'|'\136'|'\137'|'\138'|'\139'|'\140'|'\141'|'\142'|'\143'|'\144'|'\145'|'\146'|'\147'|'\148'|'\149'|'\150'|'\151'|'\152'|'\153'|'\154'|'\155'|'\156'|'\157'|'\158'|'\159'|'\160'|'\161'|'\162'|'\163'|'\164'|'\165'|'\166'|'\167'|'\168'|'\169'|'\170'|'\171'|'\172'|'\173'|'\174'|'\175'|'\176'|'\177'|'\178'|'\179'|'\180'|'\181'|'\182'|'\183'|'\184'|'\185'|'\186'|'\187'|'\188'|'\189'|'\190'|'\191' *)
        |128|129|130|131|132|133|134|135|136|137|138|139|140|141|142|143|144|145|146|147|148|149|150|151|152|153|154|155|156|157|158|159|160|161|162|163|164|165|166|167|168|169|170|171|172|173|174|175|176|177|178|179|180|181|182|183|184|185|186|187|188|189|190|191 ->
          let next_char, _buf, _len, _curr, _last =
            if _curr >= _len then
              __ocaml_lex_refill_buf lexbuf _buf _len _curr _last
            else
              Char.code (Bytes.unsafe_get _buf _curr),
              _buf, _len, (_curr + 1), _last
          in
          begin match next_char with
            (* |'\128'|'\129'|'\130'|'\131'|'\132'|'\133'|'\134'|'\135'|'\136'|'\137'|'\138'|'\139'|'\140'|'\141'|'\142'|'\143'|'\144'|'\145'|'\146'|'\147'|'\148'|'\149'|'\150'|'\151'|'\152'|'\153'|'\154'|'\155'|'\156'|'\157'|'\158'|'\159'|'\160'|'\161'|'\162'|'\163'|'\164'|'\165'|'\166'|'\167'|'\168'|'\169'|'\170'|'\171'|'\172'|'\173'|'\174'|'\175'|'\176'|'\177'|'\178'|'\179'|'\180'|'\181'|'\182'|'\183'|'\184'|'\185'|'\186'|'\187'|'\188'|'\189'|'\190'|'\191' *)
            |128|129|130|131|132|133|134|135|136|137|138|139|140|141|142|143|144|145|146|147|148|149|150|151|152|153|154|155|156|157|158|159|160|161|162|163|164|165|166|167|168|169|170|171|172|173|174|175|176|177|178|179|180|181|182|183|184|185|186|187|188|189|190|191 ->
              __ocaml_lex_state29 lexbuf _last_action _buf _len _curr _last
            | _ ->
              let _curr = _last in
              lexbuf.Lexing.lex_curr_pos <- _curr;
              lexbuf.Lexing.lex_last_pos <- _last;
              _last_action
          end
        | _ ->
          let _curr = _last in
          lexbuf.Lexing.lex_curr_pos <- _curr;
          lexbuf.Lexing.lex_last_pos <- _last;
          _last_action
      end
    | _ ->
      let _curr = _last in
      lexbuf.Lexing.lex_curr_pos <- _curr;
      lexbuf.Lexing.lex_last_pos <- _last;
      _last_action
  end

and __ocaml_lex_state30 lexbuf _last_action _buf _len _curr _last =
  (* *)
  let _last = _curr in
  let _last_action = 20 in
  let next_char, _buf, _len, _curr, _last =
    if _curr >= _len then
      __ocaml_lex_refill_buf lexbuf _buf _len _curr _last
    else
      Char.code (Bytes.unsafe_get _buf _curr),
      _buf, _len, (_curr + 1), _last
  in
  begin match next_char with
    (* |'"' *)
    | 34 ->
      __ocaml_lex_state29 lexbuf 20 (* = last_action *) _buf _len _curr _last
    (* |'0'|'1'|'2'|'3'|'4'|'5'|'6'|'7'|'8'|'9' *)
    |48|49|50|51|52|53|54|55|56|57 ->
      __ocaml_lex_state45 lexbuf 20 (* = last_action *) _buf _len _curr _last
    (* |'!'|'#'|'$'|'%'|'&'|'\''|'*'|'.'|'/'|':'|'<'|'='|'>'|'?'|'@'|'A'|'B'|'C'|'D'|'E'|'F'|'G'|'H'|'I'|'J'|'K'|'L'|'M'|'N'|'O'|'P'|'Q'|'R'|'S'|'T'|'U'|'V'|'W'|'X'|'Y'|'Z'|'\\'|'^'|'_'|'`'|'a'|'b'|'c'|'d'|'e'|'f'|'g'|'h'|'i'|'j'|'k'|'l'|'m'|'n'|'o'|'p'|'q'|'r'|'s'|'t'|'u'|'v'|'w'|'x'|'y'|'z'|'|'|'~' *)
    |33|35|36|37|38|39|42|46|47|58|60|61|62|63|64|65|66|67|68|69|70|71|72|73|74|75|76|77|78|79|80|81|82|83|84|85|86|87|88|89|90|92|94|95|96|97|98|99|100|101|102|103|104|105|106|107|108|109|110|111|112|113|114|115|116|117|118|119|120|121|122|124|126 ->
      __ocaml_lex_state11 lexbuf 20 (* = last_action *) _buf _len _curr _last
    (* |'+'|'-' *)
    |43|45 ->
      (* *)
      let _last = _curr in
      (* let _last_action = 20 in*)
      let next_char, _buf, _len, _curr, _last =
        if _curr >= _len then
          __ocaml_lex_refill_buf lexbuf _buf _len _curr _last
        else
          Char.code (Bytes.unsafe_get _buf _curr),
          _buf, _len, (_curr + 1), _last
      in
      begin match next_char with
        (* |'"' *)
        | 34 ->
          __ocaml_lex_state29 lexbuf 20 (* = last_action *) _buf _len _curr _last
        (* |'0'|'1'|'2'|'3'|'4'|'5'|'6'|'7'|'8'|'9' *)
        |48|49|50|51|52|53|54|55|56|57 ->
          __ocaml_lex_state45 lexbuf 20 (* = last_action *) _buf _len _curr _last
        (* |'!'|'#'|'$'|'%'|'&'|'\''|'*'|'+'|'-'|'.'|'/'|':'|'<'|'='|'>'|'?'|'@'|'A'|'B'|'C'|'D'|'E'|'F'|'G'|'H'|'I'|'J'|'K'|'L'|'M'|'N'|'O'|'P'|'Q'|'R'|'S'|'T'|'U'|'V'|'W'|'X'|'Y'|'Z'|'\\'|'^'|'_'|'`'|'a'|'b'|'c'|'d'|'e'|'f'|'g'|'h'|'i'|'j'|'k'|'l'|'m'|'n'|'o'|'p'|'q'|'r'|'s'|'t'|'u'|'v'|'w'|'x'|'y'|'z'|'|'|'~' *)
        |33|35|36|37|38|39|42|43|45|46|47|58|60|61|62|63|64|65|66|67|68|69|70|71|72|73|74|75|76|77|78|79|80|81|82|83|84|85|86|87|88|89|90|92|94|95|96|97|98|99|100|101|102|103|104|105|106|107|108|109|110|111|112|113|114|115|116|117|118|119|120|121|122|124|126 ->
          __ocaml_lex_state11 lexbuf 20 (* = last_action *) _buf _len _curr _last
        | _ ->
          let _curr = _last in
          lexbuf.Lexing.lex_curr_pos <- _curr;
          lexbuf.Lexing.lex_last_pos <- _last;
          20 (* = last_action *)
      end
    | _ ->
      let _curr = _last in
      lexbuf.Lexing.lex_curr_pos <- _curr;
      lexbuf.Lexing.lex_last_pos <- _last;
      20 (* = last_action *)
  end

and __ocaml_lex_state31 lexbuf _last_action _buf _len _curr _last =
  (* *)
  let _last = _curr in
  let _last_action = 4 in
  let next_char, _buf, _len, _curr, _last =
    if _curr >= _len then
      __ocaml_lex_refill_buf lexbuf _buf _len _curr _last
    else
      Char.code (Bytes.unsafe_get _buf _curr),
      _buf, _len, (_curr + 1), _last
  in
  begin match next_char with
    (* |'0'|'1'|'2'|'3'|'4'|'5'|'6'|'7'|'8'|'9' *)
    |48|49|50|51|52|53|54|55|56|57 ->
      __ocaml_lex_state43 lexbuf 4 (* = last_action *) _buf _len _curr _last
    (* |'E'|'e' *)
    |69|101 ->
      __ocaml_lex_state30 lexbuf 4 (* = last_action *) _buf _len _curr _last
    (* |'"' *)
    | 34 ->
      __ocaml_lex_state29 lexbuf 4 (* = last_action *) _buf _len _curr _last
    (* |'!'|'#'|'$'|'%'|'&'|'\''|'*'|'+'|'-'|'.'|'/'|':'|'<'|'='|'>'|'?'|'@'|'A'|'B'|'C'|'D'|'F'|'G'|'H'|'I'|'J'|'K'|'L'|'M'|'N'|'O'|'P'|'Q'|'R'|'S'|'T'|'U'|'V'|'W'|'X'|'Y'|'Z'|'\\'|'^'|'_'|'`'|'a'|'b'|'c'|'d'|'f'|'g'|'h'|'i'|'j'|'k'|'l'|'m'|'n'|'o'|'p'|'q'|'r'|'s'|'t'|'u'|'v'|'w'|'x'|'y'|'z'|'|'|'~' *)
    |33|35|36|37|38|39|42|43|45|46|47|58|60|61|62|63|64|65|66|67|68|70|71|72|73|74|75|76|77|78|79|80|81|82|83|84|85|86|87|88|89|90|92|94|95|96|97|98|99|100|102|103|104|105|106|107|108|109|110|111|112|113|114|115|116|117|118|119|120|121|122|124|126 ->
      __ocaml_lex_state11 lexbuf 4 (* = last_action *) _buf _len _curr _last
    | _ ->
      let _curr = _last in
      lexbuf.Lexing.lex_curr_pos <- _curr;
      lexbuf.Lexing.lex_last_pos <- _last;
      4 (* = last_action *)
  end

and __ocaml_lex_state33 lexbuf _last_action _buf _len _curr _last =
  (* *)
  let _last = _curr in
  let _last_action = 20 in
  let next_char, _buf, _len, _curr, _last =
    if _curr >= _len then
      __ocaml_lex_refill_buf lexbuf _buf _len _curr _last
    else
      Char.code (Bytes.unsafe_get _buf _curr),
      _buf, _len, (_curr + 1), _last
  in
  begin match next_char with
    (* |'0'|'1'|'2'|'3'|'4'|'5'|'6'|'7'|'8'|'9' *)
    |48|49|50|51|52|53|54|55|56|57 ->
      __ocaml_lex_state24 lexbuf 20 (* = last_action *) _buf _len _curr _last
    (* |'"' *)
    | 34 ->
      __ocaml_lex_state29 lexbuf 20 (* = last_action *) _buf _len _curr _last
    (* |'!'|'#'|'$'|'%'|'&'|'\''|'*'|'+'|'-'|'.'|'/'|':'|'<'|'='|'>'|'?'|'@'|'A'|'B'|'C'|'D'|'E'|'F'|'G'|'H'|'I'|'J'|'K'|'L'|'M'|'N'|'O'|'P'|'Q'|'R'|'S'|'T'|'U'|'V'|'W'|'X'|'Y'|'Z'|'\\'|'^'|'_'|'`'|'a'|'b'|'c'|'d'|'e'|'f'|'g'|'h'|'i'|'j'|'k'|'l'|'m'|'n'|'o'|'p'|'q'|'r'|'s'|'t'|'u'|'v'|'w'|'x'|'y'|'z'|'|'|'~' *)
    |33|35|36|37|38|39|42|43|45|46|47|58|60|61|62|63|64|65|66|67|68|69|70|71|72|73|74|75|76|77|78|79|80|81|82|83|84|85|86|87|88|89|90|92|94|95|96|97|98|99|100|101|102|103|104|105|106|107|108|109|110|111|112|113|114|115|116|117|118|119|120|121|122|124|126 ->
      __ocaml_lex_state11 lexbuf 20 (* = last_action *) _buf _len _curr _last
    | _ ->
      let _curr = _last in
      lexbuf.Lexing.lex_curr_pos <- _curr;
      lexbuf.Lexing.lex_last_pos <- _last;
      20 (* = last_action *)
  end

and __ocaml_lex_state34 lexbuf _last_action _buf _len _curr _last =
  (* *)
  let _last = _curr in
  let _last_action = 2 in
  let next_char, _buf, _len, _curr, _last =
    if _curr >= _len then
      __ocaml_lex_refill_buf lexbuf _buf _len _curr _last
    else
      Char.code (Bytes.unsafe_get _buf _curr),
      _buf, _len, (_curr + 1), _last
  in
  begin match next_char with
    (* |'0'|'1'|'2'|'3'|'4'|'5'|'6'|'7'|'8'|'9'|'A'|'B'|'C'|'D'|'E'|'F'|'a'|'b'|'c'|'d'|'e'|'f' *)
    |48|49|50|51|52|53|54|55|56|57|65|66|67|68|69|70|97|98|99|100|101|102 ->
      __ocaml_lex_state34 lexbuf 2 (* = last_action *) _buf _len _curr _last
    (* |'_' *)
    | 95 ->
      (* *)
      let _last = _curr in
      let _last_action = 20 in
      let next_char, _buf, _len, _curr, _last =
        if _curr >= _len then
          __ocaml_lex_refill_buf lexbuf _buf _len _curr _last
        else
          Char.code (Bytes.unsafe_get _buf _curr),
          _buf, _len, (_curr + 1), _last
      in
      begin match next_char with
        (* |'0'|'1'|'2'|'3'|'4'|'5'|'6'|'7'|'8'|'9'|'A'|'B'|'C'|'D'|'E'|'F'|'a'|'b'|'c'|'d'|'e'|'f' *)
        |48|49|50|51|52|53|54|55|56|57|65|66|67|68|69|70|97|98|99|100|101|102 ->
          __ocaml_lex_state34 lexbuf 20 (* = last_action *) _buf _len _curr _last
        (* |'"' *)
        | 34 ->
          __ocaml_lex_state29 lexbuf 20 (* = last_action *) _buf _len _curr _last
        (* |'!'|'#'|'$'|'%'|'&'|'\''|'*'|'+'|'-'|'.'|'/'|':'|'<'|'='|'>'|'?'|'@'|'G'|'H'|'I'|'J'|'K'|'L'|'M'|'N'|'O'|'P'|'Q'|'R'|'S'|'T'|'U'|'V'|'W'|'X'|'Y'|'Z'|'\\'|'^'|'_'|'`'|'g'|'h'|'i'|'j'|'k'|'l'|'m'|'n'|'o'|'p'|'q'|'r'|'s'|'t'|'u'|'v'|'w'|'x'|'y'|'z'|'|'|'~' *)
        |33|35|36|37|38|39|42|43|45|46|47|58|60|61|62|63|64|71|72|73|74|75|76|77|78|79|80|81|82|83|84|85|86|87|88|89|90|92|94|95|96|103|104|105|106|107|108|109|110|111|112|113|114|115|116|117|118|119|120|121|122|124|126 ->
          __ocaml_lex_state11 lexbuf 20 (* = last_action *) _buf _len _curr _last
        | _ ->
          let _curr = _last in
          lexbuf.Lexing.lex_curr_pos <- _curr;
          lexbuf.Lexing.lex_last_pos <- _last;
          20 (* = last_action *)
      end
    (* |'P'|'p' *)
    |80|112 ->
      __ocaml_lex_state35 lexbuf 2 (* = last_action *) _buf _len _curr _last
    (* |'"' *)
    | 34 ->
      __ocaml_lex_state29 lexbuf 2 (* = last_action *) _buf _len _curr _last
    (* |'.' *)
    | 46 ->
      __ocaml_lex_state36 lexbuf 2 (* = last_action *) _buf _len _curr _last
    (* |'!'|'#'|'$'|'%'|'&'|'\''|'*'|'+'|'-'|'/'|':'|'<'|'='|'>'|'?'|'@'|'G'|'H'|'I'|'J'|'K'|'L'|'M'|'N'|'O'|'Q'|'R'|'S'|'T'|'U'|'V'|'W'|'X'|'Y'|'Z'|'\\'|'^'|'`'|'g'|'h'|'i'|'j'|'k'|'l'|'m'|'n'|'o'|'q'|'r'|'s'|'t'|'u'|'v'|'w'|'x'|'y'|'z'|'|'|'~' *)
    |33|35|36|37|38|39|42|43|45|47|58|60|61|62|63|64|71|72|73|74|75|76|77|78|79|81|82|83|84|85|86|87|88|89|90|92|94|96|103|104|105|106|107|108|109|110|111|113|114|115|116|117|118|119|120|121|122|124|126 ->
      __ocaml_lex_state11 lexbuf 2 (* = last_action *) _buf _len _curr _last
    | _ ->
      let _curr = _last in
      lexbuf.Lexing.lex_curr_pos <- _curr;
      lexbuf.Lexing.lex_last_pos <- _last;
      2 (* = last_action *)
  end

and __ocaml_lex_state35 lexbuf _last_action _buf _len _curr _last =
  (* *)
  let _last = _curr in
  let _last_action = 20 in
  let next_char, _buf, _len, _curr, _last =
    if _curr >= _len then
      __ocaml_lex_refill_buf lexbuf _buf _len _curr _last
    else
      Char.code (Bytes.unsafe_get _buf _curr),
      _buf, _len, (_curr + 1), _last
  in
  begin match next_char with
    (* |'+'|'-' *)
    |43|45 ->
      (* *)
      let _last = _curr in
      (* let _last_action = 20 in*)
      let next_char, _buf, _len, _curr, _last =
        if _curr >= _len then
          __ocaml_lex_refill_buf lexbuf _buf _len _curr _last
        else
          Char.code (Bytes.unsafe_get _buf _curr),
          _buf, _len, (_curr + 1), _last
      in
      begin match next_char with
        (* |'"' *)
        | 34 ->
          __ocaml_lex_state29 lexbuf 20 (* = last_action *) _buf _len _curr _last
        (* |'!'|'#'|'$'|'%'|'&'|'\''|'*'|'+'|'-'|'.'|'/'|':'|'<'|'='|'>'|'?'|'@'|'A'|'B'|'C'|'D'|'E'|'F'|'G'|'H'|'I'|'J'|'K'|'L'|'M'|'N'|'O'|'P'|'Q'|'R'|'S'|'T'|'U'|'V'|'W'|'X'|'Y'|'Z'|'\\'|'^'|'_'|'`'|'a'|'b'|'c'|'d'|'e'|'f'|'g'|'h'|'i'|'j'|'k'|'l'|'m'|'n'|'o'|'p'|'q'|'r'|'s'|'t'|'u'|'v'|'w'|'x'|'y'|'z'|'|'|'~' *)
        |33|35|36|37|38|39|42|43|45|46|47|58|60|61|62|63|64|65|66|67|68|69|70|71|72|73|74|75|76|77|78|79|80|81|82|83|84|85|86|87|88|89|90|92|94|95|96|97|98|99|100|101|102|103|104|105|106|107|108|109|110|111|112|113|114|115|116|117|118|119|120|121|122|124|126 ->
          __ocaml_lex_state11 lexbuf 20 (* = last_action *) _buf _len _curr _last
        (* |'0'|'1'|'2'|'3'|'4'|'5'|'6'|'7'|'8'|'9' *)
        |48|49|50|51|52|53|54|55|56|57 ->
          __ocaml_lex_state40 lexbuf 20 (* = last_action *) _buf _len _curr _last
        | _ ->
          let _curr = _last in
          lexbuf.Lexing.lex_curr_pos <- _curr;
          lexbuf.Lexing.lex_last_pos <- _last;
          20 (* = last_action *)
      end
    (* |'"' *)
    | 34 ->
      __ocaml_lex_state29 lexbuf 20 (* = last_action *) _buf _len _curr _last
    (* |'!'|'#'|'$'|'%'|'&'|'\''|'*'|'.'|'/'|':'|'<'|'='|'>'|'?'|'@'|'A'|'B'|'C'|'D'|'E'|'F'|'G'|'H'|'I'|'J'|'K'|'L'|'M'|'N'|'O'|'P'|'Q'|'R'|'S'|'T'|'U'|'V'|'W'|'X'|'Y'|'Z'|'\\'|'^'|'_'|'`'|'a'|'b'|'c'|'d'|'e'|'f'|'g'|'h'|'i'|'j'|'k'|'l'|'m'|'n'|'o'|'p'|'q'|'r'|'s'|'t'|'u'|'v'|'w'|'x'|'y'|'z'|'|'|'~' *)
    |33|35|36|37|38|39|42|46|47|58|60|61|62|63|64|65|66|67|68|69|70|71|72|73|74|75|76|77|78|79|80|81|82|83|84|85|86|87|88|89|90|92|94|95|96|97|98|99|100|101|102|103|104|105|106|107|108|109|110|111|112|113|114|115|116|117|118|119|120|121|122|124|126 ->
      __ocaml_lex_state11 lexbuf 20 (* = last_action *) _buf _len _curr _last
    (* |'0'|'1'|'2'|'3'|'4'|'5'|'6'|'7'|'8'|'9' *)
    |48|49|50|51|52|53|54|55|56|57 ->
      __ocaml_lex_state40 lexbuf 20 (* = last_action *) _buf _len _curr _last
    | _ ->
      let _curr = _last in
      lexbuf.Lexing.lex_curr_pos <- _curr;
      lexbuf.Lexing.lex_last_pos <- _last;
      20 (* = last_action *)
  end

and __ocaml_lex_state36 lexbuf _last_action _buf _len _curr _last =
  (* *)
  let _last = _curr in
  let _last_action = 4 in
  let next_char, _buf, _len, _curr, _last =
    if _curr >= _len then
      __ocaml_lex_refill_buf lexbuf _buf _len _curr _last
    else
      Char.code (Bytes.unsafe_get _buf _curr),
      _buf, _len, (_curr + 1), _last
  in
  begin match next_char with
    (* |'P'|'p' *)
    |80|112 ->
      __ocaml_lex_state35 lexbuf 4 (* = last_action *) _buf _len _curr _last
    (* |'0'|'1'|'2'|'3'|'4'|'5'|'6'|'7'|'8'|'9'|'A'|'B'|'C'|'D'|'E'|'F'|'a'|'b'|'c'|'d'|'e'|'f' *)
    |48|49|50|51|52|53|54|55|56|57|65|66|67|68|69|70|97|98|99|100|101|102 ->
      __ocaml_lex_state38 lexbuf 4 (* = last_action *) _buf _len _curr _last
    (* |'"' *)
    | 34 ->
      __ocaml_lex_state29 lexbuf 4 (* = last_action *) _buf _len _curr _last
    (* |'!'|'#'|'$'|'%'|'&'|'\''|'*'|'+'|'-'|'.'|'/'|':'|'<'|'='|'>'|'?'|'@'|'G'|'H'|'I'|'J'|'K'|'L'|'M'|'N'|'O'|'Q'|'R'|'S'|'T'|'U'|'V'|'W'|'X'|'Y'|'Z'|'\\'|'^'|'_'|'`'|'g'|'h'|'i'|'j'|'k'|'l'|'m'|'n'|'o'|'q'|'r'|'s'|'t'|'u'|'v'|'w'|'x'|'y'|'z'|'|'|'~' *)
    |33|35|36|37|38|39|42|43|45|46|47|58|60|61|62|63|64|71|72|73|74|75|76|77|78|79|81|82|83|84|85|86|87|88|89|90|92|94|95|96|103|104|105|106|107|108|109|110|111|113|114|115|116|117|118|119|120|121|122|124|126 ->
      __ocaml_lex_state11 lexbuf 4 (* = last_action *) _buf _len _curr _last
    | _ ->
      let _curr = _last in
      lexbuf.Lexing.lex_curr_pos <- _curr;
      lexbuf.Lexing.lex_last_pos <- _last;
      4 (* = last_action *)
  end

and __ocaml_lex_state38 lexbuf _last_action _buf _len _curr _last =
  (* *)
  let _last = _curr in
  let _last_action = 4 in
  let next_char, _buf, _len, _curr, _last =
    if _curr >= _len then
      __ocaml_lex_refill_buf lexbuf _buf _len _curr _last
    else
      Char.code (Bytes.unsafe_get _buf _curr),
      _buf, _len, (_curr + 1), _last
  in
  begin match next_char with
    (* |'_' *)
    | 95 ->
      (* *)
      let _last = _curr in
      let _last_action = 20 in
      let next_char, _buf, _len, _curr, _last =
        if _curr >= _len then
          __ocaml_lex_refill_buf lexbuf _buf _len _curr _last
        else
          Char.code (Bytes.unsafe_get _buf _curr),
          _buf, _len, (_curr + 1), _last
      in
      begin match next_char with
        (* |'0'|'1'|'2'|'3'|'4'|'5'|'6'|'7'|'8'|'9'|'A'|'B'|'C'|'D'|'E'|'F'|'a'|'b'|'c'|'d'|'e'|'f' *)
        |48|49|50|51|52|53|54|55|56|57|65|66|67|68|69|70|97|98|99|100|101|102 ->
          __ocaml_lex_state38 lexbuf 20 (* = last_action *) _buf _len _curr _last
        (* |'"' *)
        | 34 ->
          __ocaml_lex_state29 lexbuf 20 (* = last_action *) _buf _len _curr _last
        (* |'!'|'#'|'$'|'%'|'&'|'\''|'*'|'+'|'-'|'.'|'/'|':'|'<'|'='|'>'|'?'|'@'|'G'|'H'|'I'|'J'|'K'|'L'|'M'|'N'|'O'|'P'|'Q'|'R'|'S'|'T'|'U'|'V'|'W'|'X'|'Y'|'Z'|'\\'|'^'|'_'|'`'|'g'|'h'|'i'|'j'|'k'|'l'|'m'|'n'|'o'|'p'|'q'|'r'|'s'|'t'|'u'|'v'|'w'|'x'|'y'|'z'|'|'|'~' *)
        |33|35|36|37|38|39|42|43|45|46|47|58|60|61|62|63|64|71|72|73|74|75|76|77|78|79|80|81|82|83|84|85|86|87|88|89|90|92|94|95|96|103|104|105|106|107|108|109|110|111|112|113|114|115|116|117|118|119|120|121|122|124|126 ->
          __ocaml_lex_state11 lexbuf 20 (* = last_action *) _buf _len _curr _last
        | _ ->
          let _curr = _last in
          lexbuf.Lexing.lex_curr_pos <- _curr;
          lexbuf.Lexing.lex_last_pos <- _last;
          20 (* = last_action *)
      end
    (* |'P'|'p' *)
    |80|112 ->
      __ocaml_lex_state35 lexbuf 4 (* = last_action *) _buf _len _curr _last
    (* |'0'|'1'|'2'|'3'|'4'|'5'|'6'|'7'|'8'|'9'|'A'|'B'|'C'|'D'|'E'|'F'|'a'|'b'|'c'|'d'|'e'|'f' *)
    |48|49|50|51|52|53|54|55|56|57|65|66|67|68|69|70|97|98|99|100|101|102 ->
      __ocaml_lex_state38 lexbuf 4 (* = last_action *) _buf _len _curr _last
    (* |'"' *)
    | 34 ->
      __ocaml_lex_state29 lexbuf 4 (* = last_action *) _buf _len _curr _last
    (* |'!'|'#'|'$'|'%'|'&'|'\''|'*'|'+'|'-'|'.'|'/'|':'|'<'|'='|'>'|'?'|'@'|'G'|'H'|'I'|'J'|'K'|'L'|'M'|'N'|'O'|'Q'|'R'|'S'|'T'|'U'|'V'|'W'|'X'|'Y'|'Z'|'\\'|'^'|'`'|'g'|'h'|'i'|'j'|'k'|'l'|'m'|'n'|'o'|'q'|'r'|'s'|'t'|'u'|'v'|'w'|'x'|'y'|'z'|'|'|'~' *)
    |33|35|36|37|38|39|42|43|45|46|47|58|60|61|62|63|64|71|72|73|74|75|76|77|78|79|81|82|83|84|85|86|87|88|89|90|92|94|96|103|104|105|106|107|108|109|110|111|113|114|115|116|117|118|119|120|121|122|124|126 ->
      __ocaml_lex_state11 lexbuf 4 (* = last_action *) _buf _len _curr _last
    | _ ->
      let _curr = _last in
      lexbuf.Lexing.lex_curr_pos <- _curr;
      lexbuf.Lexing.lex_last_pos <- _last;
      4 (* = last_action *)
  end

and __ocaml_lex_state40 lexbuf _last_action _buf _len _curr _last =
  (* *)
  let _last = _curr in
  let _last_action = 4 in
  let next_char, _buf, _len, _curr, _last =
    if _curr >= _len then
      __ocaml_lex_refill_buf lexbuf _buf _len _curr _last
    else
      Char.code (Bytes.unsafe_get _buf _curr),
      _buf, _len, (_curr + 1), _last
  in
  begin match next_char with
    (* |'_' *)
    | 95 ->
      (* *)
      let _last = _curr in
      let _last_action = 20 in
      let next_char, _buf, _len, _curr, _last =
        if _curr >= _len then
          __ocaml_lex_refill_buf lexbuf _buf _len _curr _last
        else
          Char.code (Bytes.unsafe_get _buf _curr),
          _buf, _len, (_curr + 1), _last
      in
      begin match next_char with
        (* |'"' *)
        | 34 ->
          __ocaml_lex_state29 lexbuf 20 (* = last_action *) _buf _len _curr _last
        (* |'!'|'#'|'$'|'%'|'&'|'\''|'*'|'+'|'-'|'.'|'/'|':'|'<'|'='|'>'|'?'|'@'|'A'|'B'|'C'|'D'|'E'|'F'|'G'|'H'|'I'|'J'|'K'|'L'|'M'|'N'|'O'|'P'|'Q'|'R'|'S'|'T'|'U'|'V'|'W'|'X'|'Y'|'Z'|'\\'|'^'|'_'|'`'|'a'|'b'|'c'|'d'|'e'|'f'|'g'|'h'|'i'|'j'|'k'|'l'|'m'|'n'|'o'|'p'|'q'|'r'|'s'|'t'|'u'|'v'|'w'|'x'|'y'|'z'|'|'|'~' *)
        |33|35|36|37|38|39|42|43|45|46|47|58|60|61|62|63|64|65|66|67|68|69|70|71|72|73|74|75|76|77|78|79|80|81|82|83|84|85|86|87|88|89|90|92|94|95|96|97|98|99|100|101|102|103|104|105|106|107|108|109|110|111|112|113|114|115|116|117|118|119|120|121|122|124|126 ->
          __ocaml_lex_state11 lexbuf 20 (* = last_action *) _buf _len _curr _last
        (* |'0'|'1'|'2'|'3'|'4'|'5'|'6'|'7'|'8'|'9' *)
        |48|49|50|51|52|53|54|55|56|57 ->
          __ocaml_lex_state40 lexbuf 20 (* = last_action *) _buf _len _curr _last
        | _ ->
          let _curr = _last in
          lexbuf.Lexing.lex_curr_pos <- _curr;
          lexbuf.Lexing.lex_last_pos <- _last;
          20 (* = last_action *)
      end
    (* |'"' *)
    | 34 ->
      __ocaml_lex_state29 lexbuf 4 (* = last_action *) _buf _len _curr _last
    (* |'!'|'#'|'$'|'%'|'&'|'\''|'*'|'+'|'-'|'.'|'/'|':'|'<'|'='|'>'|'?'|'@'|'A'|'B'|'C'|'D'|'E'|'F'|'G'|'H'|'I'|'J'|'K'|'L'|'M'|'N'|'O'|'P'|'Q'|'R'|'S'|'T'|'U'|'V'|'W'|'X'|'Y'|'Z'|'\\'|'^'|'`'|'a'|'b'|'c'|'d'|'e'|'f'|'g'|'h'|'i'|'j'|'k'|'l'|'m'|'n'|'o'|'p'|'q'|'r'|'s'|'t'|'u'|'v'|'w'|'x'|'y'|'z'|'|'|'~' *)
    |33|35|36|37|38|39|42|43|45|46|47|58|60|61|62|63|64|65|66|67|68|69|70|71|72|73|74|75|76|77|78|79|80|81|82|83|84|85|86|87|88|89|90|92|94|96|97|98|99|100|101|102|103|104|105|106|107|108|109|110|111|112|113|114|115|116|117|118|119|120|121|122|124|126 ->
      __ocaml_lex_state11 lexbuf 4 (* = last_action *) _buf _len _curr _last
    (* |'0'|'1'|'2'|'3'|'4'|'5'|'6'|'7'|'8'|'9' *)
    |48|49|50|51|52|53|54|55|56|57 ->
      __ocaml_lex_state40 lexbuf 4 (* = last_action *) _buf _len _curr _last
    | _ ->
      let _curr = _last in
      lexbuf.Lexing.lex_curr_pos <- _curr;
      lexbuf.Lexing.lex_last_pos <- _last;
      4 (* = last_action *)
  end

and __ocaml_lex_state43 lexbuf _last_action _buf _len _curr _last =
  (* *)
  let _last = _curr in
  let _last_action = 4 in
  let next_char, _buf, _len, _curr, _last =
    if _curr >= _len then
      __ocaml_lex_refill_buf lexbuf _buf _len _curr _last
    else
      Char.code (Bytes.unsafe_get _buf _curr),
      _buf, _len, (_curr + 1), _last
  in
  begin match next_char with
    (* |'0'|'1'|'2'|'3'|'4'|'5'|'6'|'7'|'8'|'9' *)
    |48|49|50|51|52|53|54|55|56|57 ->
      __ocaml_lex_state43 lexbuf 4 (* = last_action *) _buf _len _curr _last
    (* |'E'|'e' *)
    |69|101 ->
      __ocaml_lex_state30 lexbuf 4 (* = last_action *) _buf _len _curr _last
    (* |'"' *)
    | 34 ->
      __ocaml_lex_state29 lexbuf 4 (* = last_action *) _buf _len _curr _last
    (* |'_' *)
    | 95 ->
      (* *)
      let _last = _curr in
      let _last_action = 20 in
      let next_char, _buf, _len, _curr, _last =
        if _curr >= _len then
          __ocaml_lex_refill_buf lexbuf _buf _len _curr _last
        else
          Char.code (Bytes.unsafe_get _buf _curr),
          _buf, _len, (_curr + 1), _last
      in
      begin match next_char with
        (* |'0'|'1'|'2'|'3'|'4'|'5'|'6'|'7'|'8'|'9' *)
        |48|49|50|51|52|53|54|55|56|57 ->
          __ocaml_lex_state43 lexbuf 20 (* = last_action *) _buf _len _curr _last
        (* |'"' *)
        | 34 ->
          __ocaml_lex_state29 lexbuf 20 (* = last_action *) _buf _len _curr _last
        (* |'!'|'#'|'$'|'%'|'&'|'\''|'*'|'+'|'-'|'.'|'/'|':'|'<'|'='|'>'|'?'|'@'|'A'|'B'|'C'|'D'|'E'|'F'|'G'|'H'|'I'|'J'|'K'|'L'|'M'|'N'|'O'|'P'|'Q'|'R'|'S'|'T'|'U'|'V'|'W'|'X'|'Y'|'Z'|'\\'|'^'|'_'|'`'|'a'|'b'|'c'|'d'|'e'|'f'|'g'|'h'|'i'|'j'|'k'|'l'|'m'|'n'|'o'|'p'|'q'|'r'|'s'|'t'|'u'|'v'|'w'|'x'|'y'|'z'|'|'|'~' *)
        |33|35|36|37|38|39|42|43|45|46|47|58|60|61|62|63|64|65|66|67|68|69|70|71|72|73|74|75|76|77|78|79|80|81|82|83|84|85|86|87|88|89|90|92|94|95|96|97|98|99|100|101|102|103|104|105|106|107|108|109|110|111|112|113|114|115|116|117|118|119|120|121|122|124|126 ->
          __ocaml_lex_state11 lexbuf 20 (* = last_action *) _buf _len _curr _last
        | _ ->
          let _curr = _last in
          lexbuf.Lexing.lex_curr_pos <- _curr;
          lexbuf.Lexing.lex_last_pos <- _last;
          20 (* = last_action *)
      end
    (* |'!'|'#'|'$'|'%'|'&'|'\''|'*'|'+'|'-'|'.'|'/'|':'|'<'|'='|'>'|'?'|'@'|'A'|'B'|'C'|'D'|'F'|'G'|'H'|'I'|'J'|'K'|'L'|'M'|'N'|'O'|'P'|'Q'|'R'|'S'|'T'|'U'|'V'|'W'|'X'|'Y'|'Z'|'\\'|'^'|'`'|'a'|'b'|'c'|'d'|'f'|'g'|'h'|'i'|'j'|'k'|'l'|'m'|'n'|'o'|'p'|'q'|'r'|'s'|'t'|'u'|'v'|'w'|'x'|'y'|'z'|'|'|'~' *)
    |33|35|36|37|38|39|42|43|45|46|47|58|60|61|62|63|64|65|66|67|68|70|71|72|73|74|75|76|77|78|79|80|81|82|83|84|85|86|87|88|89|90|92|94|96|97|98|99|100|102|103|104|105|106|107|108|109|110|111|112|113|114|115|116|117|118|119|120|121|122|124|126 ->
      __ocaml_lex_state11 lexbuf 4 (* = last_action *) _buf _len _curr _last
    | _ ->
      let _curr = _last in
      lexbuf.Lexing.lex_curr_pos <- _curr;
      lexbuf.Lexing.lex_last_pos <- _last;
      4 (* = last_action *)
  end

and __ocaml_lex_state45 lexbuf _last_action _buf _len _curr _last =
  (* *)
  let _last = _curr in
  let _last_action = 4 in
  let next_char, _buf, _len, _curr, _last =
    if _curr >= _len then
      __ocaml_lex_refill_buf lexbuf _buf _len _curr _last
    else
      Char.code (Bytes.unsafe_get _buf _curr),
      _buf, _len, (_curr + 1), _last
  in
  begin match next_char with
    (* |'"' *)
    | 34 ->
      __ocaml_lex_state29 lexbuf 4 (* = last_action *) _buf _len _curr _last
    (* |'_' *)
    | 95 ->
      (* *)
      let _last = _curr in
      let _last_action = 20 in
      let next_char, _buf, _len, _curr, _last =
        if _curr >= _len then
          __ocaml_lex_refill_buf lexbuf _buf _len _curr _last
        else
          Char.code (Bytes.unsafe_get _buf _curr),
          _buf, _len, (_curr + 1), _last
      in
      begin match next_char with
        (* |'"' *)
        | 34 ->
          __ocaml_lex_state29 lexbuf 20 (* = last_action *) _buf _len _curr _last
        (* |'0'|'1'|'2'|'3'|'4'|'5'|'6'|'7'|'8'|'9' *)
        |48|49|50|51|52|53|54|55|56|57 ->
          __ocaml_lex_state45 lexbuf 20 (* = last_action *) _buf _len _curr _last
        (* |'!'|'#'|'$'|'%'|'&'|'\''|'*'|'+'|'-'|'.'|'/'|':'|'<'|'='|'>'|'?'|'@'|'A'|'B'|'C'|'D'|'E'|'F'|'G'|'H'|'I'|'J'|'K'|'L'|'M'|'N'|'O'|'P'|'Q'|'R'|'S'|'T'|'U'|'V'|'W'|'X'|'Y'|'Z'|'\\'|'^'|'_'|'`'|'a'|'b'|'c'|'d'|'e'|'f'|'g'|'h'|'i'|'j'|'k'|'l'|'m'|'n'|'o'|'p'|'q'|'r'|'s'|'t'|'u'|'v'|'w'|'x'|'y'|'z'|'|'|'~' *)
        |33|35|36|37|38|39|42|43|45|46|47|58|60|61|62|63|64|65|66|67|68|69|70|71|72|73|74|75|76|77|78|79|80|81|82|83|84|85|86|87|88|89|90|92|94|95|96|97|98|99|100|101|102|103|104|105|106|107|108|109|110|111|112|113|114|115|116|117|118|119|120|121|122|124|126 ->
          __ocaml_lex_state11 lexbuf 20 (* = last_action *) _buf _len _curr _last
        | _ ->
          let _curr = _last in
          lexbuf.Lexing.lex_curr_pos <- _curr;
          lexbuf.Lexing.lex_last_pos <- _last;
          20 (* = last_action *)
      end
    (* |'0'|'1'|'2'|'3'|'4'|'5'|'6'|'7'|'8'|'9' *)
    |48|49|50|51|52|53|54|55|56|57 ->
      __ocaml_lex_state45 lexbuf 4 (* = last_action *) _buf _len _curr _last
    (* |'!'|'#'|'$'|'%'|'&'|'\''|'*'|'+'|'-'|'.'|'/'|':'|'<'|'='|'>'|'?'|'@'|'A'|'B'|'C'|'D'|'E'|'F'|'G'|'H'|'I'|'J'|'K'|'L'|'M'|'N'|'O'|'P'|'Q'|'R'|'S'|'T'|'U'|'V'|'W'|'X'|'Y'|'Z'|'\\'|'^'|'`'|'a'|'b'|'c'|'d'|'e'|'f'|'g'|'h'|'i'|'j'|'k'|'l'|'m'|'n'|'o'|'p'|'q'|'r'|'s'|'t'|'u'|'v'|'w'|'x'|'y'|'z'|'|'|'~' *)
    |33|35|36|37|38|39|42|43|45|46|47|58|60|61|62|63|64|65|66|67|68|69|70|71|72|73|74|75|76|77|78|79|80|81|82|83|84|85|86|87|88|89|90|92|94|96|97|98|99|100|101|102|103|104|105|106|107|108|109|110|111|112|113|114|115|116|117|118|119|120|121|122|124|126 ->
      __ocaml_lex_state11 lexbuf 4 (* = last_action *) _buf _len _curr _last
    | _ ->
      let _curr = _last in
      lexbuf.Lexing.lex_curr_pos <- _curr;
      lexbuf.Lexing.lex_last_pos <- _last;
      4 (* = last_action *)
  end

and __ocaml_lex_state68 lexbuf _last_action _buf _len _curr _last =
  let next_char, _buf, _len, _curr, _last =
    if _curr >= _len then
      __ocaml_lex_refill_buf lexbuf _buf _len _curr _last
    else
      Char.code (Bytes.unsafe_get _buf _curr),
      _buf, _len, (_curr + 1), _last
  in
  begin match next_char with
    (* |'}' *)
    | 125 ->
      __ocaml_lex_state29 lexbuf _last_action _buf _len _curr _last
    (* |'0'|'1'|'2'|'3'|'4'|'5'|'6'|'7'|'8'|'9'|'A'|'B'|'C'|'D'|'E'|'F'|'a'|'b'|'c'|'d'|'e'|'f' *)
    |48|49|50|51|52|53|54|55|56|57|65|66|67|68|69|70|97|98|99|100|101|102 ->
      __ocaml_lex_state68 lexbuf _last_action _buf _len _curr _last
    (* |'_' *)
    | 95 ->
      let next_char, _buf, _len, _curr, _last =
        if _curr >= _len then
          __ocaml_lex_refill_buf lexbuf _buf _len _curr _last
        else
          Char.code (Bytes.unsafe_get _buf _curr),
          _buf, _len, (_curr + 1), _last
      in
      begin match next_char with
        (* |'0'|'1'|'2'|'3'|'4'|'5'|'6'|'7'|'8'|'9'|'A'|'B'|'C'|'D'|'E'|'F'|'a'|'b'|'c'|'d'|'e'|'f' *)
        |48|49|50|51|52|53|54|55|56|57|65|66|67|68|69|70|97|98|99|100|101|102 ->
          __ocaml_lex_state68 lexbuf _last_action _buf _len _curr _last
        | _ ->
          let _curr = _last in
          lexbuf.Lexing.lex_curr_pos <- _curr;
          lexbuf.Lexing.lex_last_pos <- _last;
          _last_action
      end
    | _ ->
      let _curr = _last in
      lexbuf.Lexing.lex_curr_pos <- _curr;
      lexbuf.Lexing.lex_last_pos <- _last;
      _last_action
  end

and __ocaml_lex_state72 lexbuf _last_action _buf _len _curr _last =
  (* *)
  let _last = _curr in
  let _last_action = 3 in
  let next_char, _buf, _len, _curr, _last =
    if _curr >= _len then
      __ocaml_lex_refill_buf lexbuf _buf _len _curr _last
    else
      Char.code (Bytes.unsafe_get _buf _curr),
      _buf, _len, (_curr + 1), _last
  in
  begin match next_char with
    (* |'0'|'1'|'2'|'3'|'4'|'5'|'6'|'7'|'8'|'9' *)
    |48|49|50|51|52|53|54|55|56|57 ->
      __ocaml_lex_state72 lexbuf 3 (* = last_action *) _buf _len _curr _last
    (* |'E'|'e' *)
    |69|101 ->
      __ocaml_lex_state30 lexbuf 3 (* = last_action *) _buf _len _curr _last
    (* |'.' *)
    | 46 ->
      __ocaml_lex_state31 lexbuf 3 (* = last_action *) _buf _len _curr _last
    (* |'"' *)
    | 34 ->
      __ocaml_lex_state29 lexbuf 3 (* = last_action *) _buf _len _curr _last
    (* |'_' *)
    | 95 ->
      __ocaml_lex_state75 lexbuf 3 (* = last_action *) _buf _len _curr _last
    (* |'!'|'#'|'$'|'%'|'&'|'\''|'*'|'+'|'-'|'/'|':'|'<'|'='|'>'|'?'|'@'|'A'|'B'|'C'|'D'|'F'|'G'|'H'|'I'|'J'|'K'|'L'|'M'|'N'|'O'|'P'|'Q'|'R'|'S'|'T'|'U'|'V'|'W'|'X'|'Y'|'Z'|'\\'|'^'|'`'|'a'|'b'|'c'|'d'|'f'|'g'|'h'|'i'|'j'|'k'|'l'|'m'|'n'|'o'|'p'|'q'|'r'|'s'|'t'|'u'|'v'|'w'|'x'|'y'|'z'|'|'|'~' *)
    |33|35|36|37|38|39|42|43|45|47|58|60|61|62|63|64|65|66|67|68|70|71|72|73|74|75|76|77|78|79|80|81|82|83|84|85|86|87|88|89|90|92|94|96|97|98|99|100|102|103|104|105|106|107|108|109|110|111|112|113|114|115|116|117|118|119|120|121|122|124|126 ->
      __ocaml_lex_state11 lexbuf 3 (* = last_action *) _buf _len _curr _last
    | _ ->
      let _curr = _last in
      lexbuf.Lexing.lex_curr_pos <- _curr;
      lexbuf.Lexing.lex_last_pos <- _last;
      3 (* = last_action *)
  end

and __ocaml_lex_state75 lexbuf _last_action _buf _len _curr _last =
  (* *)
  let _last = _curr in
  let _last_action = 20 in
  let next_char, _buf, _len, _curr, _last =
    if _curr >= _len then
      __ocaml_lex_refill_buf lexbuf _buf _len _curr _last
    else
      Char.code (Bytes.unsafe_get _buf _curr),
      _buf, _len, (_curr + 1), _last
  in
  begin match next_char with
    (* |'0'|'1'|'2'|'3'|'4'|'5'|'6'|'7'|'8'|'9' *)
    |48|49|50|51|52|53|54|55|56|57 ->
      __ocaml_lex_state72 lexbuf 20 (* = last_action *) _buf _len _curr _last
    (* |'"' *)
    | 34 ->
      __ocaml_lex_state29 lexbuf 20 (* = last_action *) _buf _len _curr _last
    (* |'!'|'#'|'$'|'%'|'&'|'\''|'*'|'+'|'-'|'.'|'/'|':'|'<'|'='|'>'|'?'|'@'|'A'|'B'|'C'|'D'|'E'|'F'|'G'|'H'|'I'|'J'|'K'|'L'|'M'|'N'|'O'|'P'|'Q'|'R'|'S'|'T'|'U'|'V'|'W'|'X'|'Y'|'Z'|'\\'|'^'|'_'|'`'|'a'|'b'|'c'|'d'|'e'|'f'|'g'|'h'|'i'|'j'|'k'|'l'|'m'|'n'|'o'|'p'|'q'|'r'|'s'|'t'|'u'|'v'|'w'|'x'|'y'|'z'|'|'|'~' *)
    |33|35|36|37|38|39|42|43|45|46|47|58|60|61|62|63|64|65|66|67|68|69|70|71|72|73|74|75|76|77|78|79|80|81|82|83|84|85|86|87|88|89|90|92|94|95|96|97|98|99|100|101|102|103|104|105|106|107|108|109|110|111|112|113|114|115|116|117|118|119|120|121|122|124|126 ->
      __ocaml_lex_state11 lexbuf 20 (* = last_action *) _buf _len _curr _last
    | _ ->
      let _curr = _last in
      lexbuf.Lexing.lex_curr_pos <- _curr;
      lexbuf.Lexing.lex_last_pos <- _last;
      20 (* = last_action *)
  end

and __ocaml_lex_state76 lexbuf _last_action _buf _len _curr _last =
  (* *)
  let _last = _curr in
  let _last_action = 3 in
  let next_char, _buf, _len, _curr, _last =
    if _curr >= _len then
      __ocaml_lex_refill_buf lexbuf _buf _len _curr _last
    else
      Char.code (Bytes.unsafe_get _buf _curr),
      _buf, _len, (_curr + 1), _last
  in
  begin match next_char with
    (* |'P'|'p' *)
    |80|112 ->
      __ocaml_lex_state35 lexbuf 3 (* = last_action *) _buf _len _curr _last
    (* |'0'|'1'|'2'|'3'|'4'|'5'|'6'|'7'|'8'|'9'|'A'|'B'|'C'|'D'|'E'|'F'|'a'|'b'|'c'|'d'|'e'|'f' *)
    |48|49|50|51|52|53|54|55|56|57|65|66|67|68|69|70|97|98|99|100|101|102 ->
      __ocaml_lex_state76 lexbuf 3 (* = last_action *) _buf _len _curr _last
    (* |'"' *)
    | 34 ->
      __ocaml_lex_state29 lexbuf 3 (* = last_action *) _buf _len _curr _last
    (* |'.' *)
    | 46 ->
      __ocaml_lex_state36 lexbuf 3 (* = last_action *) _buf _len _curr _last
    (* |'!'|'#'|'$'|'%'|'&'|'\''|'*'|'+'|'-'|'/'|':'|'<'|'='|'>'|'?'|'@'|'G'|'H'|'I'|'J'|'K'|'L'|'M'|'N'|'O'|'Q'|'R'|'S'|'T'|'U'|'V'|'W'|'X'|'Y'|'Z'|'\\'|'^'|'`'|'g'|'h'|'i'|'j'|'k'|'l'|'m'|'n'|'o'|'q'|'r'|'s'|'t'|'u'|'v'|'w'|'x'|'y'|'z'|'|'|'~' *)
    |33|35|36|37|38|39|42|43|45|47|58|60|61|62|63|64|71|72|73|74|75|76|77|78|79|81|82|83|84|85|86|87|88|89|90|92|94|96|103|104|105|106|107|108|109|110|111|113|114|115|116|117|118|119|120|121|122|124|126 ->
      __ocaml_lex_state11 lexbuf 3 (* = last_action *) _buf _len _curr _last
    (* |'_' *)
    | 95 ->
      (* *)
      let _last = _curr in
      let _last_action = 20 in
      let next_char, _buf, _len, _curr, _last =
        if _curr >= _len then
          __ocaml_lex_refill_buf lexbuf _buf _len _curr _last
        else
          Char.code (Bytes.unsafe_get _buf _curr),
          _buf, _len, (_curr + 1), _last
      in
      begin match next_char with
        (* |'0'|'1'|'2'|'3'|'4'|'5'|'6'|'7'|'8'|'9'|'A'|'B'|'C'|'D'|'E'|'F'|'a'|'b'|'c'|'d'|'e'|'f' *)
        |48|49|50|51|52|53|54|55|56|57|65|66|67|68|69|70|97|98|99|100|101|102 ->
          __ocaml_lex_state76 lexbuf 20 (* = last_action *) _buf _len _curr _last
        (* |'"' *)
        | 34 ->
          __ocaml_lex_state29 lexbuf 20 (* = last_action *) _buf _len _curr _last
        (* |'!'|'#'|'$'|'%'|'&'|'\''|'*'|'+'|'-'|'.'|'/'|':'|'<'|'='|'>'|'?'|'@'|'G'|'H'|'I'|'J'|'K'|'L'|'M'|'N'|'O'|'P'|'Q'|'R'|'S'|'T'|'U'|'V'|'W'|'X'|'Y'|'Z'|'\\'|'^'|'_'|'`'|'g'|'h'|'i'|'j'|'k'|'l'|'m'|'n'|'o'|'p'|'q'|'r'|'s'|'t'|'u'|'v'|'w'|'x'|'y'|'z'|'|'|'~' *)
        |33|35|36|37|38|39|42|43|45|46|47|58|60|61|62|63|64|71|72|73|74|75|76|77|78|79|80|81|82|83|84|85|86|87|88|89|90|92|94|95|96|103|104|105|106|107|108|109|110|111|112|113|114|115|116|117|118|119|120|121|122|124|126 ->
          __ocaml_lex_state11 lexbuf 20 (* = last_action *) _buf _len _curr _last
        | _ ->
          let _curr = _last in
          lexbuf.Lexing.lex_curr_pos <- _curr;
          lexbuf.Lexing.lex_last_pos <- _last;
          20 (* = last_action *)
      end
    | _ ->
      let _curr = _last in
      lexbuf.Lexing.lex_curr_pos <- _curr;
      lexbuf.Lexing.lex_last_pos <- _last;
      3 (* = last_action *)
  end

and __ocaml_lex_state85 lexbuf _last_action _buf _len _curr _last =
  (* *)
  let _last = _curr in
  let _last_action = 4 in
  let next_char, _buf, _len, _curr, _last =
    if _curr >= _len then
      __ocaml_lex_refill_buf lexbuf _buf _len _curr _last
    else
      Char.code (Bytes.unsafe_get _buf _curr),
      _buf, _len, (_curr + 1), _last
  in
  begin match next_char with
    (* |'_' *)
    | 95 ->
      (* *)
      let _last = _curr in
      let _last_action = 20 in
      let next_char, _buf, _len, _curr, _last =
        if _curr >= _len then
          __ocaml_lex_refill_buf lexbuf _buf _len _curr _last
        else
          Char.code (Bytes.unsafe_get _buf _curr),
          _buf, _len, (_curr + 1), _last
      in
      begin match next_char with
        (* |'"' *)
        | 34 ->
          __ocaml_lex_state29 lexbuf 20 (* = last_action *) _buf _len _curr _last
        (* |'!'|'#'|'$'|'%'|'&'|'\''|'*'|'+'|'-'|'.'|'/'|':'|'<'|'='|'>'|'?'|'@'|'G'|'H'|'I'|'J'|'K'|'L'|'M'|'N'|'O'|'P'|'Q'|'R'|'S'|'T'|'U'|'V'|'W'|'X'|'Y'|'Z'|'\\'|'^'|'_'|'`'|'g'|'h'|'i'|'j'|'k'|'l'|'m'|'n'|'o'|'p'|'q'|'r'|'s'|'t'|'u'|'v'|'w'|'x'|'y'|'z'|'|'|'~' *)
        |33|35|36|37|38|39|42|43|45|46|47|58|60|61|62|63|64|71|72|73|74|75|76|77|78|79|80|81|82|83|84|85|86|87|88|89|90|92|94|95|96|103|104|105|106|107|108|109|110|111|112|113|114|115|116|117|118|119|120|121|122|124|126 ->
          __ocaml_lex_state11 lexbuf 20 (* = last_action *) _buf _len _curr _last
        (* |'0'|'1'|'2'|'3'|'4'|'5'|'6'|'7'|'8'|'9'|'A'|'B'|'C'|'D'|'E'|'F'|'a'|'b'|'c'|'d'|'e'|'f' *)
        |48|49|50|51|52|53|54|55|56|57|65|66|67|68|69|70|97|98|99|100|101|102 ->
          __ocaml_lex_state85 lexbuf 20 (* = last_action *) _buf _len _curr _last
        | _ ->
          let _curr = _last in
          lexbuf.Lexing.lex_curr_pos <- _curr;
          lexbuf.Lexing.lex_last_pos <- _last;
          20 (* = last_action *)
      end
    (* |'"' *)
    | 34 ->
      __ocaml_lex_state29 lexbuf 4 (* = last_action *) _buf _len _curr _last
    (* |'!'|'#'|'$'|'%'|'&'|'\''|'*'|'+'|'-'|'.'|'/'|':'|'<'|'='|'>'|'?'|'@'|'G'|'H'|'I'|'J'|'K'|'L'|'M'|'N'|'O'|'P'|'Q'|'R'|'S'|'T'|'U'|'V'|'W'|'X'|'Y'|'Z'|'\\'|'^'|'`'|'g'|'h'|'i'|'j'|'k'|'l'|'m'|'n'|'o'|'p'|'q'|'r'|'s'|'t'|'u'|'v'|'w'|'x'|'y'|'z'|'|'|'~' *)
    |33|35|36|37|38|39|42|43|45|46|47|58|60|61|62|63|64|71|72|73|74|75|76|77|78|79|80|81|82|83|84|85|86|87|88|89|90|92|94|96|103|104|105|106|107|108|109|110|111|112|113|114|115|116|117|118|119|120|121|122|124|126 ->
      __ocaml_lex_state11 lexbuf 4 (* = last_action *) _buf _len _curr _last
    (* |'0'|'1'|'2'|'3'|'4'|'5'|'6'|'7'|'8'|'9'|'A'|'B'|'C'|'D'|'E'|'F'|'a'|'b'|'c'|'d'|'e'|'f' *)
    |48|49|50|51|52|53|54|55|56|57|65|66|67|68|69|70|97|98|99|100|101|102 ->
      __ocaml_lex_state85 lexbuf 4 (* = last_action *) _buf _len _curr _last
    | _ ->
      let _curr = _last in
      lexbuf.Lexing.lex_curr_pos <- _curr;
      lexbuf.Lexing.lex_last_pos <- _last;
      4 (* = last_action *)
  end

and __ocaml_lex_state87 lexbuf _last_action _buf _len _curr _last =
  (* *)
  let _last = _curr in
  let _last_action = 9 in
  let next_char, _buf, _len, _curr, _last =
    if _curr >= _len then
      __ocaml_lex_refill_buf lexbuf _buf _len _curr _last
    else
      Char.code (Bytes.unsafe_get _buf _curr),
      _buf, _len, (_curr + 1), _last
  in
  begin match next_char with
    (* |'"' *)
    | 34 ->
      __ocaml_lex_state29 lexbuf 9 (* = last_action *) _buf _len _curr _last
    (* |'.'|'0'|'1'|'2'|'3'|'4'|'5'|'6'|'7'|'8'|'9'|':'|'A'|'B'|'C'|'D'|'E'|'F'|'G'|'H'|'I'|'J'|'K'|'L'|'M'|'N'|'O'|'P'|'Q'|'R'|'S'|'T'|'U'|'V'|'W'|'X'|'Y'|'Z'|'_'|'a'|'b'|'c'|'d'|'e'|'f'|'g'|'h'|'i'|'j'|'k'|'l'|'m'|'n'|'o'|'p'|'q'|'r'|'s'|'t'|'u'|'v'|'w'|'x'|'y'|'z' *)
    |46|48|49|50|51|52|53|54|55|56|57|58|65|66|67|68|69|70|71|72|73|74|75|76|77|78|79|80|81|82|83|84|85|86|87|88|89|90|95|97|98|99|100|101|102|103|104|105|106|107|108|109|110|111|112|113|114|115|116|117|118|119|120|121|122 ->
      __ocaml_lex_state87 lexbuf 9 (* = last_action *) _buf _len _curr _last
    (* |'!'|'#'|'$'|'%'|'&'|'\''|'*'|'+'|'-'|'/'|'<'|'='|'>'|'?'|'@'|'\\'|'^'|'`'|'|'|'~' *)
    |33|35|36|37|38|39|42|43|45|47|60|61|62|63|64|92|94|96|124|126 ->
      __ocaml_lex_state11 lexbuf 9 (* = last_action *) _buf _len _curr _last
    | _ ->
      let _curr = _last in
      lexbuf.Lexing.lex_curr_pos <- _curr;
      lexbuf.Lexing.lex_last_pos <- _last;
      9 (* = last_action *)
  end

and __ocaml_lex_state95 lexbuf _last_action _buf _len _curr _last =
  (* *)
  let _last = _curr in
  let _last_action = 4 in
  let next_char, _buf, _len, _curr, _last =
    if _curr >= _len then
      __ocaml_lex_refill_buf lexbuf _buf _len _curr _last
    else
      Char.code (Bytes.unsafe_get _buf _curr),
      _buf, _len, (_curr + 1), _last
  in
  begin match next_char with
    (* |'0'|'1'|'2'|'3'|'4'|'5'|'6'|'7'|'8'|'9'|'A'|'B'|'C'|'D'|'E'|'F'|'a'|'b'|'c'|'d'|'e'|'f' *)
    |48|49|50|51|52|53|54|55|56|57|65|66|67|68|69|70|97|98|99|100|101|102 ->
      __ocaml_lex_state95 lexbuf 4 (* = last_action *) _buf _len _curr _last
    (* |'"' *)
    | 34 ->
      __ocaml_lex_state29 lexbuf 4 (* = last_action *) _buf _len _curr _last
    (* |'.'|':'|'G'|'H'|'I'|'J'|'K'|'L'|'M'|'N'|'O'|'P'|'Q'|'R'|'S'|'T'|'U'|'V'|'W'|'X'|'Y'|'Z'|'g'|'h'|'i'|'j'|'k'|'l'|'m'|'n'|'o'|'p'|'q'|'r'|'s'|'t'|'u'|'v'|'w'|'x'|'y'|'z' *)
    |46|58|71|72|73|74|75|76|77|78|79|80|81|82|83|84|85|86|87|88|89|90|103|104|105|106|107|108|109|110|111|112|113|114|115|116|117|118|119|120|121|122 ->
      __ocaml_lex_state87 lexbuf 4 (* = last_action *) _buf _len _curr _last
    (* |'!'|'#'|'$'|'%'|'&'|'\''|'*'|'+'|'-'|'/'|'<'|'='|'>'|'?'|'@'|'\\'|'^'|'`'|'|'|'~' *)
    |33|35|36|37|38|39|42|43|45|47|60|61|62|63|64|92|94|96|124|126 ->
      __ocaml_lex_state11 lexbuf 4 (* = last_action *) _buf _len _curr _last
    (* |'_' *)
    | 95 ->
      (* *)
      let _last = _curr in
      let _last_action = 9 in
      let next_char, _buf, _len, _curr, _last =
        if _curr >= _len then
          __ocaml_lex_refill_buf lexbuf _buf _len _curr _last
        else
          Char.code (Bytes.unsafe_get _buf _curr),
          _buf, _len, (_curr + 1), _last
      in
      begin match next_char with
        (* |'0'|'1'|'2'|'3'|'4'|'5'|'6'|'7'|'8'|'9'|'A'|'B'|'C'|'D'|'E'|'F'|'a'|'b'|'c'|'d'|'e'|'f' *)
        |48|49|50|51|52|53|54|55|56|57|65|66|67|68|69|70|97|98|99|100|101|102 ->
          __ocaml_lex_state95 lexbuf 9 (* = last_action *) _buf _len _curr _last
        (* |'"' *)
        | 34 ->
          __ocaml_lex_state29 lexbuf 9 (* = last_action *) _buf _len _curr _last
        (* |'.'|':'|'G'|'H'|'I'|'J'|'K'|'L'|'M'|'N'|'O'|'P'|'Q'|'R'|'S'|'T'|'U'|'V'|'W'|'X'|'Y'|'Z'|'_'|'g'|'h'|'i'|'j'|'k'|'l'|'m'|'n'|'o'|'p'|'q'|'r'|'s'|'t'|'u'|'v'|'w'|'x'|'y'|'z' *)
        |46|58|71|72|73|74|75|76|77|78|79|80|81|82|83|84|85|86|87|88|89|90|95|103|104|105|106|107|108|109|110|111|112|113|114|115|116|117|118|119|120|121|122 ->
          __ocaml_lex_state87 lexbuf 9 (* = last_action *) _buf _len _curr _last
        (* |'!'|'#'|'$'|'%'|'&'|'\''|'*'|'+'|'-'|'/'|'<'|'='|'>'|'?'|'@'|'\\'|'^'|'`'|'|'|'~' *)
        |33|35|36|37|38|39|42|43|45|47|60|61|62|63|64|92|94|96|124|126 ->
          __ocaml_lex_state11 lexbuf 9 (* = last_action *) _buf _len _curr _last
        | _ ->
          let _curr = _last in
          lexbuf.Lexing.lex_curr_pos <- _curr;
          lexbuf.Lexing.lex_last_pos <- _last;
          9 (* = last_action *)
      end
    | _ ->
      let _curr = _last in
      lexbuf.Lexing.lex_curr_pos <- _curr;
      lexbuf.Lexing.lex_last_pos <- _last;
      4 (* = last_action *)
  end

and __ocaml_lex_state99 lexbuf _last_action _buf _len _curr _last =
  (* *)
  let _last = _curr in
  let _last_action = 5 in
  let next_char, _buf, _len, _curr, _last =
    if _curr >= _len then
      __ocaml_lex_refill_buf lexbuf _buf _len _curr _last
    else
      Char.code (Bytes.unsafe_get _buf _curr),
      _buf, _len, (_curr + 1), _last
  in
  begin match next_char with
    (* |'"' *)
    | 34 ->
      __ocaml_lex_state29 lexbuf 5 (* = last_action *) _buf _len _curr _last
    (* |'!'|'#'|'$'|'%'|'&'|'\''|'*'|'+'|'-'|'.'|'/'|'0'|'1'|'2'|'3'|'4'|'5'|'6'|'7'|'8'|'9'|':'|'<'|'='|'>'|'?'|'@'|'A'|'B'|'C'|'D'|'E'|'F'|'G'|'H'|'I'|'J'|'K'|'L'|'M'|'N'|'O'|'P'|'Q'|'R'|'S'|'T'|'U'|'V'|'W'|'X'|'Y'|'Z'|'\\'|'^'|'_'|'`'|'a'|'b'|'c'|'d'|'e'|'f'|'g'|'h'|'i'|'j'|'k'|'l'|'m'|'n'|'o'|'p'|'q'|'r'|'s'|'t'|'u'|'v'|'w'|'x'|'y'|'z'|'|'|'~' *)
    |33|35|36|37|38|39|42|43|45|46|47|48|49|50|51|52|53|54|55|56|57|58|60|61|62|63|64|65|66|67|68|69|70|71|72|73|74|75|76|77|78|79|80|81|82|83|84|85|86|87|88|89|90|92|94|95|96|97|98|99|100|101|102|103|104|105|106|107|108|109|110|111|112|113|114|115|116|117|118|119|120|121|122|124|126 ->
      __ocaml_lex_state11 lexbuf 5 (* = last_action *) _buf _len _curr _last
    | _ ->
      let _curr = _last in
      lexbuf.Lexing.lex_curr_pos <- _curr;
      lexbuf.Lexing.lex_last_pos <- _last;
      5 (* = last_action *)
  end

and __ocaml_lex_state100 lexbuf _last_action _buf _len _curr _last =
  let next_char, _buf, _len, _curr, _last =
    if _curr >= _len then
      __ocaml_lex_refill_buf lexbuf _buf _len _curr _last
    else
      Char.code (Bytes.unsafe_get _buf _curr),
      _buf, _len, (_curr + 1), _last
  in
  begin match next_char with
    (* |'0'|'1'|'2'|'3'|'4'|'5'|'6'|'7'|'8'|'9'|'A'|'B'|'C'|'D'|'E'|'F'|'a'|'b'|'c'|'d'|'e'|'f' *)
    |48|49|50|51|52|53|54|55|56|57|65|66|67|68|69|70|97|98|99|100|101|102 ->
      (* *)
      let _last = _curr in
      let _last_action = 8 in
      let next_char, _buf, _len, _curr, _last =
        if _curr >= _len then
          __ocaml_lex_refill_buf lexbuf _buf _len _curr _last
        else
          Char.code (Bytes.unsafe_get _buf _curr),
          _buf, _len, (_curr + 1), _last
      in
      begin match next_char with
        (* |'0'|'1'|'2'|'3'|'4'|'5'|'6'|'7'|'8'|'9'|'A'|'B'|'C'|'D'|'E'|'F'|'a'|'b'|'c'|'d'|'e'|'f' *)
        |48|49|50|51|52|53|54|55|56|57|65|66|67|68|69|70|97|98|99|100|101|102 ->
          __ocaml_lex_state108 lexbuf 8 (* = last_action *) _buf _len _curr _last
        | _ ->
          let _curr = _last in
          lexbuf.Lexing.lex_curr_pos <- _curr;
          lexbuf.Lexing.lex_last_pos <- _last;
          8 (* = last_action *)
      end
    (* |eof *)
    | 256 ->
      let _curr = _last in
      lexbuf.Lexing.lex_curr_pos <- _curr;
      lexbuf.Lexing.lex_last_pos <- _last;
      _last_action
    (* |'"'|'\''|'\\'|'n'|'r'|'t' *)
    |34|39|92|110|114|116 ->
      (* *)
      let _last = _curr in
      let _last_action = 8 in
      let next_char, _buf, _len, _curr, _last =
        if _curr >= _len then
          __ocaml_lex_refill_buf lexbuf _buf _len _curr _last
        else
          Char.code (Bytes.unsafe_get _buf _curr),
          _buf, _len, (_curr + 1), _last
      in
      begin match next_char with
        (* |'\224' *)
        | 224 ->
          __ocaml_lex_state106 lexbuf 8 (* = last_action *) _buf _len _curr _last
        (* |'\128'|'\129'|'\130'|'\131'|'\132'|'\133'|'\134'|'\135'|'\136'|'\137'|'\138'|'\139'|'\140'|'\141'|'\142'|'\143'|'\144'|'\145'|'\146'|'\147'|'\148'|'\149'|'\150'|'\151'|'\152'|'\153'|'\154'|'\155'|'\156'|'\157'|'\158'|'\159'|'\160'|'\161'|'\162'|'\163'|'\164'|'\165'|'\166'|'\167'|'\168'|'\169'|'\170'|'\171'|'\172'|'\173'|'\174'|'\175'|'\176'|'\177'|'\178'|'\179'|'\180'|'\181'|'\182'|'\183'|'\184'|'\185'|'\186'|'\187'|'\188'|'\189'|'\190'|'\191'|'\192'|'\193'|'\245'|'\246'|'\247'|'\248'|'\249'|'\250'|'\251'|'\252'|'\253'|'\254'|'\255' *)
        |128|129|130|131|132|133|134|135|136|137|138|139|140|141|142|143|144|145|146|147|148|149|150|151|152|153|154|155|156|157|158|159|160|161|162|163|164|165|166|167|168|169|170|171|172|173|174|175|176|177|178|179|180|181|182|183|184|185|186|187|188|189|190|191|192|193|245|246|247|248|249|250|251|252|253|254|255 ->
          let _curr = _last in
          lexbuf.Lexing.lex_curr_pos <- _curr;
          lexbuf.Lexing.lex_last_pos <- _last;
          8 (* = last_action *)
        (* |'\n'|eof *)
        |10|256 ->
          (* *)
          lexbuf.Lexing.lex_curr_pos <- _curr;
          lexbuf.Lexing.lex_last_pos <- _last;
          6
        (* |'\240' *)
        | 240 ->
          __ocaml_lex_state103 lexbuf 8 (* = last_action *) _buf _len _curr _last
        (* |'\194'|'\195'|'\196'|'\197'|'\198'|'\199'|'\200'|'\201'|'\202'|'\203'|'\204'|'\205'|'\206'|'\207'|'\208'|'\209'|'\210'|'\211'|'\212'|'\213'|'\214'|'\215'|'\216'|'\217'|'\218'|'\219'|'\220'|'\221'|'\222'|'\223' *)
        |194|195|196|197|198|199|200|201|202|203|204|205|206|207|208|209|210|211|212|213|214|215|216|217|218|219|220|221|222|223 ->
          __ocaml_lex_state107 lexbuf 8 (* = last_action *) _buf _len _curr _last
        (* |'\\' *)
        | 92 ->
          __ocaml_lex_state100 lexbuf 8 (* = last_action *) _buf _len _curr _last
        (* |'\241'|'\242'|'\243' *)
        |241|242|243 ->
          __ocaml_lex_state101 lexbuf 8 (* = last_action *) _buf _len _curr _last
        (* |'\237' *)
        | 237 ->
          __ocaml_lex_state105 lexbuf 8 (* = last_action *) _buf _len _curr _last
        (* |'\225'|'\226'|'\227'|'\228'|'\229'|'\230'|'\231'|'\232'|'\233'|'\234'|'\235'|'\236'|'\238'|'\239' *)
        |225|226|227|228|229|230|231|232|233|234|235|236|238|239 ->
          __ocaml_lex_state104 lexbuf 8 (* = last_action *) _buf _len _curr _last
        (* |'\244' *)
        | 244 ->
          __ocaml_lex_state102 lexbuf 8 (* = last_action *) _buf _len _curr _last
        (* |'\000'|'\001'|'\002'|'\003'|'\004'|'\005'|'\006'|'\007'|'\b'|'\t'|'\011'|'\012'|'\r'|'\014'|'\015'|'\016'|'\017'|'\018'|'\019'|'\020'|'\021'|'\022'|'\023'|'\024'|'\025'|'\026'|'\027'|'\028'|'\029'|'\030'|'\031'|'\127' *)
        |0|1|2|3|4|5|6|7|8|9|11|12|13|14|15|16|17|18|19|20|21|22|23|24|25|26|27|28|29|30|31|127 ->
          (* *)
          lexbuf.Lexing.lex_curr_pos <- _curr;
          lexbuf.Lexing.lex_last_pos <- _last;
          7
        (* |'"' *)
        | 34 ->
          __ocaml_lex_state99 lexbuf 8 (* = last_action *) _buf _len _curr _last
        | _ ->
          __ocaml_lex_state108 lexbuf 8 (* = last_action *) _buf _len _curr _last
      end
    (* |'u' *)
    | 117 ->
      (* *)
      let _last = _curr in
      let _last_action = 8 in
      let next_char, _buf, _len, _curr, _last =
        if _curr >= _len then
          __ocaml_lex_refill_buf lexbuf _buf _len _curr _last
        else
          Char.code (Bytes.unsafe_get _buf _curr),
          _buf, _len, (_curr + 1), _last
      in
      begin match next_char with
        (* |'{' *)
        | 123 ->
          let next_char, _buf, _len, _curr, _last =
            if _curr >= _len then
              __ocaml_lex_refill_buf lexbuf _buf _len _curr _last
            else
              Char.code (Bytes.unsafe_get _buf _curr),
              _buf, _len, (_curr + 1), _last
          in
          begin match next_char with
            (* |'0'|'1'|'2'|'3'|'4'|'5'|'6'|'7'|'8'|'9'|'A'|'B'|'C'|'D'|'E'|'F'|'a'|'b'|'c'|'d'|'e'|'f' *)
            |48|49|50|51|52|53|54|55|56|57|65|66|67|68|69|70|97|98|99|100|101|102 ->
              __ocaml_lex_state123 lexbuf 8 (* = last_action *) _buf _len _curr _last
            | _ ->
              let _curr = _last in
              lexbuf.Lexing.lex_curr_pos <- _curr;
              lexbuf.Lexing.lex_last_pos <- _last;
              8 (* = last_action *)
          end
        | _ ->
          let _curr = _last in
          lexbuf.Lexing.lex_curr_pos <- _curr;
          lexbuf.Lexing.lex_last_pos <- _last;
          8 (* = last_action *)
      end
    | _ ->
      (* *)
      lexbuf.Lexing.lex_curr_pos <- _curr;
      lexbuf.Lexing.lex_last_pos <- _last;
      8
  end

and __ocaml_lex_state101 lexbuf _last_action _buf _len _curr _last =
  let next_char, _buf, _len, _curr, _last =
    if _curr >= _len then
      __ocaml_lex_refill_buf lexbuf _buf _len _curr _last
    else
      Char.code (Bytes.unsafe_get _buf _curr),
      _buf, _len, (_curr + 1), _last
  in
  begin match next_char with
    (* |'\128'|'\129'|'\130'|'\131'|'\132'|'\133'|'\134'|'\135'|'\136'|'\137'|'\138'|'\139'|'\140'|'\141'|'\142'|'\143'|'\144'|'\145'|'\146'|'\147'|'\148'|'\149'|'\150'|'\151'|'\152'|'\153'|'\154'|'\155'|'\156'|'\157'|'\158'|'\159'|'\160'|'\161'|'\162'|'\163'|'\164'|'\165'|'\166'|'\167'|'\168'|'\169'|'\170'|'\171'|'\172'|'\173'|'\174'|'\175'|'\176'|'\177'|'\178'|'\179'|'\180'|'\181'|'\182'|'\183'|'\184'|'\185'|'\186'|'\187'|'\188'|'\189'|'\190'|'\191' *)
    |128|129|130|131|132|133|134|135|136|137|138|139|140|141|142|143|144|145|146|147|148|149|150|151|152|153|154|155|156|157|158|159|160|161|162|163|164|165|166|167|168|169|170|171|172|173|174|175|176|177|178|179|180|181|182|183|184|185|186|187|188|189|190|191 ->
      let next_char, _buf, _len, _curr, _last =
        if _curr >= _len then
          __ocaml_lex_refill_buf lexbuf _buf _len _curr _last
        else
          Char.code (Bytes.unsafe_get _buf _curr),
          _buf, _len, (_curr + 1), _last
      in
      begin match next_char with
        (* |'\128'|'\129'|'\130'|'\131'|'\132'|'\133'|'\134'|'\135'|'\136'|'\137'|'\138'|'\139'|'\140'|'\141'|'\142'|'\143'|'\144'|'\145'|'\146'|'\147'|'\148'|'\149'|'\150'|'\151'|'\152'|'\153'|'\154'|'\155'|'\156'|'\157'|'\158'|'\159'|'\160'|'\161'|'\162'|'\163'|'\164'|'\165'|'\166'|'\167'|'\168'|'\169'|'\170'|'\171'|'\172'|'\173'|'\174'|'\175'|'\176'|'\177'|'\178'|'\179'|'\180'|'\181'|'\182'|'\183'|'\184'|'\185'|'\186'|'\187'|'\188'|'\189'|'\190'|'\191' *)
        |128|129|130|131|132|133|134|135|136|137|138|139|140|141|142|143|144|145|146|147|148|149|150|151|152|153|154|155|156|157|158|159|160|161|162|163|164|165|166|167|168|169|170|171|172|173|174|175|176|177|178|179|180|181|182|183|184|185|186|187|188|189|190|191 ->
          let next_char, _buf, _len, _curr, _last =
            if _curr >= _len then
              __ocaml_lex_refill_buf lexbuf _buf _len _curr _last
            else
              Char.code (Bytes.unsafe_get _buf _curr),
              _buf, _len, (_curr + 1), _last
          in
          begin match next_char with
            (* |'\128'|'\129'|'\130'|'\131'|'\132'|'\133'|'\134'|'\135'|'\136'|'\137'|'\138'|'\139'|'\140'|'\141'|'\142'|'\143'|'\144'|'\145'|'\146'|'\147'|'\148'|'\149'|'\150'|'\151'|'\152'|'\153'|'\154'|'\155'|'\156'|'\157'|'\158'|'\159'|'\160'|'\161'|'\162'|'\163'|'\164'|'\165'|'\166'|'\167'|'\168'|'\169'|'\170'|'\171'|'\172'|'\173'|'\174'|'\175'|'\176'|'\177'|'\178'|'\179'|'\180'|'\181'|'\182'|'\183'|'\184'|'\185'|'\186'|'\187'|'\188'|'\189'|'\190'|'\191' *)
            |128|129|130|131|132|133|134|135|136|137|138|139|140|141|142|143|144|145|146|147|148|149|150|151|152|153|154|155|156|157|158|159|160|161|162|163|164|165|166|167|168|169|170|171|172|173|174|175|176|177|178|179|180|181|182|183|184|185|186|187|188|189|190|191 ->
              __ocaml_lex_state108 lexbuf _last_action _buf _len _curr _last
            | _ ->
              let _curr = _last in
              lexbuf.Lexing.lex_curr_pos <- _curr;
              lexbuf.Lexing.lex_last_pos <- _last;
              _last_action
          end
        | _ ->
          let _curr = _last in
          lexbuf.Lexing.lex_curr_pos <- _curr;
          lexbuf.Lexing.lex_last_pos <- _last;
          _last_action
      end
    | _ ->
      let _curr = _last in
      lexbuf.Lexing.lex_curr_pos <- _curr;
      lexbuf.Lexing.lex_last_pos <- _last;
      _last_action
  end

and __ocaml_lex_state102 lexbuf _last_action _buf _len _curr _last =
  let next_char, _buf, _len, _curr, _last =
    if _curr >= _len then
      __ocaml_lex_refill_buf lexbuf _buf _len _curr _last
    else
      Char.code (Bytes.unsafe_get _buf _curr),
      _buf, _len, (_curr + 1), _last
  in
  begin match next_char with
    (* |'\128'|'\129'|'\130'|'\131'|'\132'|'\133'|'\134'|'\135'|'\136'|'\137'|'\138'|'\139'|'\140'|'\141'|'\142'|'\143' *)
    |128|129|130|131|132|133|134|135|136|137|138|139|140|141|142|143 ->
      let next_char, _buf, _len, _curr, _last =
        if _curr >= _len then
          __ocaml_lex_refill_buf lexbuf _buf _len _curr _last
        else
          Char.code (Bytes.unsafe_get _buf _curr),
          _buf, _len, (_curr + 1), _last
      in
      begin match next_char with
        (* |'\128'|'\129'|'\130'|'\131'|'\132'|'\133'|'\134'|'\135'|'\136'|'\137'|'\138'|'\139'|'\140'|'\141'|'\142'|'\143'|'\144'|'\145'|'\146'|'\147'|'\148'|'\149'|'\150'|'\151'|'\152'|'\153'|'\154'|'\155'|'\156'|'\157'|'\158'|'\159'|'\160'|'\161'|'\162'|'\163'|'\164'|'\165'|'\166'|'\167'|'\168'|'\169'|'\170'|'\171'|'\172'|'\173'|'\174'|'\175'|'\176'|'\177'|'\178'|'\179'|'\180'|'\181'|'\182'|'\183'|'\184'|'\185'|'\186'|'\187'|'\188'|'\189'|'\190'|'\191' *)
        |128|129|130|131|132|133|134|135|136|137|138|139|140|141|142|143|144|145|146|147|148|149|150|151|152|153|154|155|156|157|158|159|160|161|162|163|164|165|166|167|168|169|170|171|172|173|174|175|176|177|178|179|180|181|182|183|184|185|186|187|188|189|190|191 ->
          let next_char, _buf, _len, _curr, _last =
            if _curr >= _len then
              __ocaml_lex_refill_buf lexbuf _buf _len _curr _last
            else
              Char.code (Bytes.unsafe_get _buf _curr),
              _buf, _len, (_curr + 1), _last
          in
          begin match next_char with
            (* |'\128'|'\129'|'\130'|'\131'|'\132'|'\133'|'\134'|'\135'|'\136'|'\137'|'\138'|'\139'|'\140'|'\141'|'\142'|'\143'|'\144'|'\145'|'\146'|'\147'|'\148'|'\149'|'\150'|'\151'|'\152'|'\153'|'\154'|'\155'|'\156'|'\157'|'\158'|'\159'|'\160'|'\161'|'\162'|'\163'|'\164'|'\165'|'\166'|'\167'|'\168'|'\169'|'\170'|'\171'|'\172'|'\173'|'\174'|'\175'|'\176'|'\177'|'\178'|'\179'|'\180'|'\181'|'\182'|'\183'|'\184'|'\185'|'\186'|'\187'|'\188'|'\189'|'\190'|'\191' *)
            |128|129|130|131|132|133|134|135|136|137|138|139|140|141|142|143|144|145|146|147|148|149|150|151|152|153|154|155|156|157|158|159|160|161|162|163|164|165|166|167|168|169|170|171|172|173|174|175|176|177|178|179|180|181|182|183|184|185|186|187|188|189|190|191 ->
              __ocaml_lex_state108 lexbuf _last_action _buf _len _curr _last
            | _ ->
              let _curr = _last in
              lexbuf.Lexing.lex_curr_pos <- _curr;
              lexbuf.Lexing.lex_last_pos <- _last;
              _last_action
          end
        | _ ->
          let _curr = _last in
          lexbuf.Lexing.lex_curr_pos <- _curr;
          lexbuf.Lexing.lex_last_pos <- _last;
          _last_action
      end
    | _ ->
      let _curr = _last in
      lexbuf.Lexing.lex_curr_pos <- _curr;
      lexbuf.Lexing.lex_last_pos <- _last;
      _last_action
  end

and __ocaml_lex_state103 lexbuf _last_action _buf _len _curr _last =
  let next_char, _buf, _len, _curr, _last =
    if _curr >= _len then
      __ocaml_lex_refill_buf lexbuf _buf _len _curr _last
    else
      Char.code (Bytes.unsafe_get _buf _curr),
      _buf, _len, (_curr + 1), _last
  in
  begin match next_char with
    (* |'\144'|'\145'|'\146'|'\147'|'\148'|'\149'|'\150'|'\151'|'\152'|'\153'|'\154'|'\155'|'\156'|'\157'|'\158'|'\159'|'\160'|'\161'|'\162'|'\163'|'\164'|'\165'|'\166'|'\167'|'\168'|'\169'|'\170'|'\171'|'\172'|'\173'|'\174'|'\175'|'\176'|'\177'|'\178'|'\179'|'\180'|'\181'|'\182'|'\183'|'\184'|'\185'|'\186'|'\187'|'\188'|'\189'|'\190'|'\191' *)
    |144|145|146|147|148|149|150|151|152|153|154|155|156|157|158|159|160|161|162|163|164|165|166|167|168|169|170|171|172|173|174|175|176|177|178|179|180|181|182|183|184|185|186|187|188|189|190|191 ->
      let next_char, _buf, _len, _curr, _last =
        if _curr >= _len then
          __ocaml_lex_refill_buf lexbuf _buf _len _curr _last
        else
          Char.code (Bytes.unsafe_get _buf _curr),
          _buf, _len, (_curr + 1), _last
      in
      begin match next_char with
        (* |'\128'|'\129'|'\130'|'\131'|'\132'|'\133'|'\134'|'\135'|'\136'|'\137'|'\138'|'\139'|'\140'|'\141'|'\142'|'\143'|'\144'|'\145'|'\146'|'\147'|'\148'|'\149'|'\150'|'\151'|'\152'|'\153'|'\154'|'\155'|'\156'|'\157'|'\158'|'\159'|'\160'|'\161'|'\162'|'\163'|'\164'|'\165'|'\166'|'\167'|'\168'|'\169'|'\170'|'\171'|'\172'|'\173'|'\174'|'\175'|'\176'|'\177'|'\178'|'\179'|'\180'|'\181'|'\182'|'\183'|'\184'|'\185'|'\186'|'\187'|'\188'|'\189'|'\190'|'\191' *)
        |128|129|130|131|132|133|134|135|136|137|138|139|140|141|142|143|144|145|146|147|148|149|150|151|152|153|154|155|156|157|158|159|160|161|162|163|164|165|166|167|168|169|170|171|172|173|174|175|176|177|178|179|180|181|182|183|184|185|186|187|188|189|190|191 ->
          let next_char, _buf, _len, _curr, _last =
            if _curr >= _len then
              __ocaml_lex_refill_buf lexbuf _buf _len _curr _last
            else
              Char.code (Bytes.unsafe_get _buf _curr),
              _buf, _len, (_curr + 1), _last
          in
          begin match next_char with
            (* |'\128'|'\129'|'\130'|'\131'|'\132'|'\133'|'\134'|'\135'|'\136'|'\137'|'\138'|'\139'|'\140'|'\141'|'\142'|'\143'|'\144'|'\145'|'\146'|'\147'|'\148'|'\149'|'\150'|'\151'|'\152'|'\153'|'\154'|'\155'|'\156'|'\157'|'\158'|'\159'|'\160'|'\161'|'\162'|'\163'|'\164'|'\165'|'\166'|'\167'|'\168'|'\169'|'\170'|'\171'|'\172'|'\173'|'\174'|'\175'|'\176'|'\177'|'\178'|'\179'|'\180'|'\181'|'\182'|'\183'|'\184'|'\185'|'\186'|'\187'|'\188'|'\189'|'\190'|'\191' *)
            |128|129|130|131|132|133|134|135|136|137|138|139|140|141|142|143|144|145|146|147|148|149|150|151|152|153|154|155|156|157|158|159|160|161|162|163|164|165|166|167|168|169|170|171|172|173|174|175|176|177|178|179|180|181|182|183|184|185|186|187|188|189|190|191 ->
              __ocaml_lex_state108 lexbuf _last_action _buf _len _curr _last
            | _ ->
              let _curr = _last in
              lexbuf.Lexing.lex_curr_pos <- _curr;
              lexbuf.Lexing.lex_last_pos <- _last;
              _last_action
          end
        | _ ->
          let _curr = _last in
          lexbuf.Lexing.lex_curr_pos <- _curr;
          lexbuf.Lexing.lex_last_pos <- _last;
          _last_action
      end
    | _ ->
      let _curr = _last in
      lexbuf.Lexing.lex_curr_pos <- _curr;
      lexbuf.Lexing.lex_last_pos <- _last;
      _last_action
  end

and __ocaml_lex_state104 lexbuf _last_action _buf _len _curr _last =
  let next_char, _buf, _len, _curr, _last =
    if _curr >= _len then
      __ocaml_lex_refill_buf lexbuf _buf _len _curr _last
    else
      Char.code (Bytes.unsafe_get _buf _curr),
      _buf, _len, (_curr + 1), _last
  in
  begin match next_char with
    (* |'\128'|'\129'|'\130'|'\131'|'\132'|'\133'|'\134'|'\135'|'\136'|'\137'|'\138'|'\139'|'\140'|'\141'|'\142'|'\143'|'\144'|'\145'|'\146'|'\147'|'\148'|'\149'|'\150'|'\151'|'\152'|'\153'|'\154'|'\155'|'\156'|'\157'|'\158'|'\159'|'\160'|'\161'|'\162'|'\163'|'\164'|'\165'|'\166'|'\167'|'\168'|'\169'|'\170'|'\171'|'\172'|'\173'|'\174'|'\175'|'\176'|'\177'|'\178'|'\179'|'\180'|'\181'|'\182'|'\183'|'\184'|'\185'|'\186'|'\187'|'\188'|'\189'|'\190'|'\191' *)
    |128|129|130|131|132|133|134|135|136|137|138|139|140|141|142|143|144|145|146|147|148|149|150|151|152|153|154|155|156|157|158|159|160|161|162|163|164|165|166|167|168|169|170|171|172|173|174|175|176|177|178|179|180|181|182|183|184|185|186|187|188|189|190|191 ->
      let next_char, _buf, _len, _curr, _last =
        if _curr >= _len then
          __ocaml_lex_refill_buf lexbuf _buf _len _curr _last
        else
          Char.code (Bytes.unsafe_get _buf _curr),
          _buf, _len, (_curr + 1), _last
      in
      begin match next_char with
        (* |'\128'|'\129'|'\130'|'\131'|'\132'|'\133'|'\134'|'\135'|'\136'|'\137'|'\138'|'\139'|'\140'|'\141'|'\142'|'\143'|'\144'|'\145'|'\146'|'\147'|'\148'|'\149'|'\150'|'\151'|'\152'|'\153'|'\154'|'\155'|'\156'|'\157'|'\158'|'\159'|'\160'|'\161'|'\162'|'\163'|'\164'|'\165'|'\166'|'\167'|'\168'|'\169'|'\170'|'\171'|'\172'|'\173'|'\174'|'\175'|'\176'|'\177'|'\178'|'\179'|'\180'|'\181'|'\182'|'\183'|'\184'|'\185'|'\186'|'\187'|'\188'|'\189'|'\190'|'\191' *)
        |128|129|130|131|132|133|134|135|136|137|138|139|140|141|142|143|144|145|146|147|148|149|150|151|152|153|154|155|156|157|158|159|160|161|162|163|164|165|166|167|168|169|170|171|172|173|174|175|176|177|178|179|180|181|182|183|184|185|186|187|188|189|190|191 ->
          __ocaml_lex_state108 lexbuf _last_action _buf _len _curr _last
        | _ ->
          let _curr = _last in
          lexbuf.Lexing.lex_curr_pos <- _curr;
          lexbuf.Lexing.lex_last_pos <- _last;
          _last_action
      end
    | _ ->
      let _curr = _last in
      lexbuf.Lexing.lex_curr_pos <- _curr;
      lexbuf.Lexing.lex_last_pos <- _last;
      _last_action
  end

and __ocaml_lex_state105 lexbuf _last_action _buf _len _curr _last =
  let next_char, _buf, _len, _curr, _last =
    if _curr >= _len then
      __ocaml_lex_refill_buf lexbuf _buf _len _curr _last
    else
      Char.code (Bytes.unsafe_get _buf _curr),
      _buf, _len, (_curr + 1), _last
  in
  begin match next_char with
    (* |'\128'|'\129'|'\130'|'\131'|'\132'|'\133'|'\134'|'\135'|'\136'|'\137'|'\138'|'\139'|'\140'|'\141'|'\142'|'\143'|'\144'|'\145'|'\146'|'\147'|'\148'|'\149'|'\150'|'\151'|'\152'|'\153'|'\154'|'\155'|'\156'|'\157'|'\158'|'\159' *)
    |128|129|130|131|132|133|134|135|136|137|138|139|140|141|142|143|144|145|146|147|148|149|150|151|152|153|154|155|156|157|158|159 ->
      let next_char, _buf, _len, _curr, _last =
        if _curr >= _len then
          __ocaml_lex_refill_buf lexbuf _buf _len _curr _last
        else
          Char.code (Bytes.unsafe_get _buf _curr),
          _buf, _len, (_curr + 1), _last
      in
      begin match next_char with
        (* |'\128'|'\129'|'\130'|'\131'|'\132'|'\133'|'\134'|'\135'|'\136'|'\137'|'\138'|'\139'|'\140'|'\141'|'\142'|'\143'|'\144'|'\145'|'\146'|'\147'|'\148'|'\149'|'\150'|'\151'|'\152'|'\153'|'\154'|'\155'|'\156'|'\157'|'\158'|'\159'|'\160'|'\161'|'\162'|'\163'|'\164'|'\165'|'\166'|'\167'|'\168'|'\169'|'\170'|'\171'|'\172'|'\173'|'\174'|'\175'|'\176'|'\177'|'\178'|'\179'|'\180'|'\181'|'\182'|'\183'|'\184'|'\185'|'\186'|'\187'|'\188'|'\189'|'\190'|'\191' *)
        |128|129|130|131|132|133|134|135|136|137|138|139|140|141|142|143|144|145|146|147|148|149|150|151|152|153|154|155|156|157|158|159|160|161|162|163|164|165|166|167|168|169|170|171|172|173|174|175|176|177|178|179|180|181|182|183|184|185|186|187|188|189|190|191 ->
          __ocaml_lex_state108 lexbuf _last_action _buf _len _curr _last
        | _ ->
          let _curr = _last in
          lexbuf.Lexing.lex_curr_pos <- _curr;
          lexbuf.Lexing.lex_last_pos <- _last;
          _last_action
      end
    | _ ->
      let _curr = _last in
      lexbuf.Lexing.lex_curr_pos <- _curr;
      lexbuf.Lexing.lex_last_pos <- _last;
      _last_action
  end

and __ocaml_lex_state106 lexbuf _last_action _buf _len _curr _last =
  let next_char, _buf, _len, _curr, _last =
    if _curr >= _len then
      __ocaml_lex_refill_buf lexbuf _buf _len _curr _last
    else
      Char.code (Bytes.unsafe_get _buf _curr),
      _buf, _len, (_curr + 1), _last
  in
  begin match next_char with
    (* |'\160'|'\161'|'\162'|'\163'|'\164'|'\165'|'\166'|'\167'|'\168'|'\169'|'\170'|'\171'|'\172'|'\173'|'\174'|'\175'|'\176'|'\177'|'\178'|'\179'|'\180'|'\181'|'\182'|'\183'|'\184'|'\185'|'\186'|'\187'|'\188'|'\189'|'\190'|'\191' *)
    |160|161|162|163|164|165|166|167|168|169|170|171|172|173|174|175|176|177|178|179|180|181|182|183|184|185|186|187|188|189|190|191 ->
      let next_char, _buf, _len, _curr, _last =
        if _curr >= _len then
          __ocaml_lex_refill_buf lexbuf _buf _len _curr _last
        else
          Char.code (Bytes.unsafe_get _buf _curr),
          _buf, _len, (_curr + 1), _last
      in
      begin match next_char with
        (* |'\128'|'\129'|'\130'|'\131'|'\132'|'\133'|'\134'|'\135'|'\136'|'\137'|'\138'|'\139'|'\140'|'\141'|'\142'|'\143'|'\144'|'\145'|'\146'|'\147'|'\148'|'\149'|'\150'|'\151'|'\152'|'\153'|'\154'|'\155'|'\156'|'\157'|'\158'|'\159'|'\160'|'\161'|'\162'|'\163'|'\164'|'\165'|'\166'|'\167'|'\168'|'\169'|'\170'|'\171'|'\172'|'\173'|'\174'|'\175'|'\176'|'\177'|'\178'|'\179'|'\180'|'\181'|'\182'|'\183'|'\184'|'\185'|'\186'|'\187'|'\188'|'\189'|'\190'|'\191' *)
        |128|129|130|131|132|133|134|135|136|137|138|139|140|141|142|143|144|145|146|147|148|149|150|151|152|153|154|155|156|157|158|159|160|161|162|163|164|165|166|167|168|169|170|171|172|173|174|175|176|177|178|179|180|181|182|183|184|185|186|187|188|189|190|191 ->
          __ocaml_lex_state108 lexbuf _last_action _buf _len _curr _last
        | _ ->
          let _curr = _last in
          lexbuf.Lexing.lex_curr_pos <- _curr;
          lexbuf.Lexing.lex_last_pos <- _last;
          _last_action
      end
    | _ ->
      let _curr = _last in
      lexbuf.Lexing.lex_curr_pos <- _curr;
      lexbuf.Lexing.lex_last_pos <- _last;
      _last_action
  end

and __ocaml_lex_state107 lexbuf _last_action _buf _len _curr _last =
  let next_char, _buf, _len, _curr, _last =
    if _curr >= _len then
      __ocaml_lex_refill_buf lexbuf _buf _len _curr _last
    else
      Char.code (Bytes.unsafe_get _buf _curr),
      _buf, _len, (_curr + 1), _last
  in
  begin match next_char with
    (* |'\128'|'\129'|'\130'|'\131'|'\132'|'\133'|'\134'|'\135'|'\136'|'\137'|'\138'|'\139'|'\140'|'\141'|'\142'|'\143'|'\144'|'\145'|'\146'|'\147'|'\148'|'\149'|'\150'|'\151'|'\152'|'\153'|'\154'|'\155'|'\156'|'\157'|'\158'|'\159'|'\160'|'\161'|'\162'|'\163'|'\164'|'\165'|'\166'|'\167'|'\168'|'\169'|'\170'|'\171'|'\172'|'\173'|'\174'|'\175'|'\176'|'\177'|'\178'|'\179'|'\180'|'\181'|'\182'|'\183'|'\184'|'\185'|'\186'|'\187'|'\188'|'\189'|'\190'|'\191' *)
    |128|129|130|131|132|133|134|135|136|137|138|139|140|141|142|143|144|145|146|147|148|149|150|151|152|153|154|155|156|157|158|159|160|161|162|163|164|165|166|167|168|169|170|171|172|173|174|175|176|177|178|179|180|181|182|183|184|185|186|187|188|189|190|191 ->
      __ocaml_lex_state108 lexbuf _last_action _buf _len _curr _last
    | _ ->
      let _curr = _last in
      lexbuf.Lexing.lex_curr_pos <- _curr;
      lexbuf.Lexing.lex_last_pos <- _last;
      _last_action
  end

and __ocaml_lex_state108 lexbuf _last_action _buf _len _curr _last =
  let next_char, _buf, _len, _curr, _last =
    if _curr >= _len then
      __ocaml_lex_refill_buf lexbuf _buf _len _curr _last
    else
      Char.code (Bytes.unsafe_get _buf _curr),
      _buf, _len, (_curr + 1), _last
  in
  begin match next_char with
    (* |'\224' *)
    | 224 ->
      __ocaml_lex_state106 lexbuf _last_action _buf _len _curr _last
    (* |'\128'|'\129'|'\130'|'\131'|'\132'|'\133'|'\134'|'\135'|'\136'|'\137'|'\138'|'\139'|'\140'|'\141'|'\142'|'\143'|'\144'|'\145'|'\146'|'\147'|'\148'|'\149'|'\150'|'\151'|'\152'|'\153'|'\154'|'\155'|'\156'|'\157'|'\158'|'\159'|'\160'|'\161'|'\162'|'\163'|'\164'|'\165'|'\166'|'\167'|'\168'|'\169'|'\170'|'\171'|'\172'|'\173'|'\174'|'\175'|'\176'|'\177'|'\178'|'\179'|'\180'|'\181'|'\182'|'\183'|'\184'|'\185'|'\186'|'\187'|'\188'|'\189'|'\190'|'\191'|'\192'|'\193'|'\245'|'\246'|'\247'|'\248'|'\249'|'\250'|'\251'|'\252'|'\253'|'\254'|'\255' *)
    |128|129|130|131|132|133|134|135|136|137|138|139|140|141|142|143|144|145|146|147|148|149|150|151|152|153|154|155|156|157|158|159|160|161|162|163|164|165|166|167|168|169|170|171|172|173|174|175|176|177|178|179|180|181|182|183|184|185|186|187|188|189|190|191|192|193|245|246|247|248|249|250|251|252|253|254|255 ->
      let _curr = _last in
      lexbuf.Lexing.lex_curr_pos <- _curr;
      lexbuf.Lexing.lex_last_pos <- _last;
      _last_action
    (* |'\n'|eof *)
    |10|256 ->
      (* *)
      lexbuf.Lexing.lex_curr_pos <- _curr;
      lexbuf.Lexing.lex_last_pos <- _last;
      6
    (* |'\240' *)
    | 240 ->
      __ocaml_lex_state103 lexbuf _last_action _buf _len _curr _last
    (* |'\194'|'\195'|'\196'|'\197'|'\198'|'\199'|'\200'|'\201'|'\202'|'\203'|'\204'|'\205'|'\206'|'\207'|'\208'|'\209'|'\210'|'\211'|'\212'|'\213'|'\214'|'\215'|'\216'|'\217'|'\218'|'\219'|'\220'|'\221'|'\222'|'\223' *)
    |194|195|196|197|198|199|200|201|202|203|204|205|206|207|208|209|210|211|212|213|214|215|216|217|218|219|220|221|222|223 ->
      __ocaml_lex_state107 lexbuf _last_action _buf _len _curr _last
    (* |'\\' *)
    | 92 ->
      __ocaml_lex_state100 lexbuf _last_action _buf _len _curr _last
    (* |'\241'|'\242'|'\243' *)
    |241|242|243 ->
      __ocaml_lex_state101 lexbuf _last_action _buf _len _curr _last
    (* |'\237' *)
    | 237 ->
      __ocaml_lex_state105 lexbuf _last_action _buf _len _curr _last
    (* |'\225'|'\226'|'\227'|'\228'|'\229'|'\230'|'\231'|'\232'|'\233'|'\234'|'\235'|'\236'|'\238'|'\239' *)
    |225|226|227|228|229|230|231|232|233|234|235|236|238|239 ->
      __ocaml_lex_state104 lexbuf _last_action _buf _len _curr _last
    (* |'\244' *)
    | 244 ->
      __ocaml_lex_state102 lexbuf _last_action _buf _len _curr _last
    (* |'\000'|'\001'|'\002'|'\003'|'\004'|'\005'|'\006'|'\007'|'\b'|'\t'|'\011'|'\012'|'\r'|'\014'|'\015'|'\016'|'\017'|'\018'|'\019'|'\020'|'\021'|'\022'|'\023'|'\024'|'\025'|'\026'|'\027'|'\028'|'\029'|'\030'|'\031'|'\127' *)
    |0|1|2|3|4|5|6|7|8|9|11|12|13|14|15|16|17|18|19|20|21|22|23|24|25|26|27|28|29|30|31|127 ->
      (* *)
      lexbuf.Lexing.lex_curr_pos <- _curr;
      lexbuf.Lexing.lex_last_pos <- _last;
      7
    (* |'"' *)
    | 34 ->
      __ocaml_lex_state99 lexbuf _last_action _buf _len _curr _last
    | _ ->
      __ocaml_lex_state108 lexbuf _last_action _buf _len _curr _last
  end

and __ocaml_lex_state123 lexbuf _last_action _buf _len _curr _last =
  let next_char, _buf, _len, _curr, _last =
    if _curr >= _len then
      __ocaml_lex_refill_buf lexbuf _buf _len _curr _last
    else
      Char.code (Bytes.unsafe_get _buf _curr),
      _buf, _len, (_curr + 1), _last
  in
  begin match next_char with
    (* |'_' *)
    | 95 ->
      let next_char, _buf, _len, _curr, _last =
        if _curr >= _len then
          __ocaml_lex_refill_buf lexbuf _buf _len _curr _last
        else
          Char.code (Bytes.unsafe_get _buf _curr),
          _buf, _len, (_curr + 1), _last
      in
      begin match next_char with
        (* |'0'|'1'|'2'|'3'|'4'|'5'|'6'|'7'|'8'|'9'|'A'|'B'|'C'|'D'|'E'|'F'|'a'|'b'|'c'|'d'|'e'|'f' *)
        |48|49|50|51|52|53|54|55|56|57|65|66|67|68|69|70|97|98|99|100|101|102 ->
          __ocaml_lex_state123 lexbuf _last_action _buf _len _curr _last
        | _ ->
          let _curr = _last in
          lexbuf.Lexing.lex_curr_pos <- _curr;
          lexbuf.Lexing.lex_last_pos <- _last;
          _last_action
      end
    (* |'}' *)
    | 125 ->
      __ocaml_lex_state108 lexbuf _last_action _buf _len _curr _last
    (* |'0'|'1'|'2'|'3'|'4'|'5'|'6'|'7'|'8'|'9'|'A'|'B'|'C'|'D'|'E'|'F'|'a'|'b'|'c'|'d'|'e'|'f' *)
    |48|49|50|51|52|53|54|55|56|57|65|66|67|68|69|70|97|98|99|100|101|102 ->
      __ocaml_lex_state123 lexbuf _last_action _buf _len _curr _last
    | _ ->
      let _curr = _last in
      lexbuf.Lexing.lex_curr_pos <- _curr;
      lexbuf.Lexing.lex_last_pos <- _last;
      _last_action
  end

and __ocaml_lex_state131 lexbuf _last_action _buf _len _curr _last =
  (* *)
  let _last = _curr in
  let _last_action = 10 in
  let next_char, _buf, _len, _curr, _last =
    if _curr >= _len then
      __ocaml_lex_refill_buf lexbuf _buf _len _curr _last
    else
      Char.code (Bytes.unsafe_get _buf _curr),
      _buf, _len, (_curr + 1), _last
  in
  begin match next_char with
    (* |'0'|'1'|'2'|'3'|'4'|'5'|'6'|'7'|'8'|'9' *)
    |48|49|50|51|52|53|54|55|56|57 ->
      __ocaml_lex_state131 lexbuf 10 (* = last_action *) _buf _len _curr _last
    (* |'"' *)
    | 34 ->
      __ocaml_lex_state29 lexbuf 10 (* = last_action *) _buf _len _curr _last
    (* |'_' *)
    | 95 ->
      __ocaml_lex_state134 lexbuf 10 (* = last_action *) _buf _len _curr _last
    (* |'!'|'#'|'$'|'%'|'&'|'\''|'*'|'+'|'-'|'.'|'/'|':'|'<'|'='|'>'|'?'|'@'|'A'|'B'|'C'|'D'|'E'|'F'|'G'|'H'|'I'|'J'|'K'|'L'|'M'|'N'|'O'|'P'|'Q'|'R'|'S'|'T'|'U'|'V'|'W'|'X'|'Y'|'Z'|'\\'|'^'|'`'|'a'|'b'|'c'|'d'|'e'|'f'|'g'|'h'|'i'|'j'|'k'|'l'|'m'|'n'|'o'|'p'|'q'|'r'|'s'|'t'|'u'|'v'|'w'|'x'|'y'|'z'|'|'|'~' *)
    |33|35|36|37|38|39|42|43|45|46|47|58|60|61|62|63|64|65|66|67|68|69|70|71|72|73|74|75|76|77|78|79|80|81|82|83|84|85|86|87|88|89|90|92|94|96|97|98|99|100|101|102|103|104|105|106|107|108|109|110|111|112|113|114|115|116|117|118|119|120|121|122|124|126 ->
      __ocaml_lex_state11 lexbuf 10 (* = last_action *) _buf _len _curr _last
    | _ ->
      let _curr = _last in
      lexbuf.Lexing.lex_curr_pos <- _curr;
      lexbuf.Lexing.lex_last_pos <- _last;
      10 (* = last_action *)
  end

and __ocaml_lex_state134 lexbuf _last_action _buf _len _curr _last =
  (* *)
  let _last = _curr in
  let _last_action = 20 in
  let next_char, _buf, _len, _curr, _last =
    if _curr >= _len then
      __ocaml_lex_refill_buf lexbuf _buf _len _curr _last
    else
      Char.code (Bytes.unsafe_get _buf _curr),
      _buf, _len, (_curr + 1), _last
  in
  begin match next_char with
    (* |'0'|'1'|'2'|'3'|'4'|'5'|'6'|'7'|'8'|'9' *)
    |48|49|50|51|52|53|54|55|56|57 ->
      __ocaml_lex_state131 lexbuf 20 (* = last_action *) _buf _len _curr _last
    (* |'"' *)
    | 34 ->
      __ocaml_lex_state29 lexbuf 20 (* = last_action *) _buf _len _curr _last
    (* |'!'|'#'|'$'|'%'|'&'|'\''|'*'|'+'|'-'|'.'|'/'|':'|'<'|'='|'>'|'?'|'@'|'A'|'B'|'C'|'D'|'E'|'F'|'G'|'H'|'I'|'J'|'K'|'L'|'M'|'N'|'O'|'P'|'Q'|'R'|'S'|'T'|'U'|'V'|'W'|'X'|'Y'|'Z'|'\\'|'^'|'_'|'`'|'a'|'b'|'c'|'d'|'e'|'f'|'g'|'h'|'i'|'j'|'k'|'l'|'m'|'n'|'o'|'p'|'q'|'r'|'s'|'t'|'u'|'v'|'w'|'x'|'y'|'z'|'|'|'~' *)
    |33|35|36|37|38|39|42|43|45|46|47|58|60|61|62|63|64|65|66|67|68|69|70|71|72|73|74|75|76|77|78|79|80|81|82|83|84|85|86|87|88|89|90|92|94|95|96|97|98|99|100|101|102|103|104|105|106|107|108|109|110|111|112|113|114|115|116|117|118|119|120|121|122|124|126 ->
      __ocaml_lex_state11 lexbuf 20 (* = last_action *) _buf _len _curr _last
    | _ ->
      let _curr = _last in
      lexbuf.Lexing.lex_curr_pos <- _curr;
      lexbuf.Lexing.lex_last_pos <- _last;
      20 (* = last_action *)
  end

and __ocaml_lex_state135 lexbuf _last_action _buf _len _curr _last =
  (* *)
  let _last = _curr in
  let _last_action = 10 in
  let next_char, _buf, _len, _curr, _last =
    if _curr >= _len then
      __ocaml_lex_refill_buf lexbuf _buf _len _curr _last
    else
      Char.code (Bytes.unsafe_get _buf _curr),
      _buf, _len, (_curr + 1), _last
  in
  begin match next_char with
    (* |'_' *)
    | 95 ->
      (* *)
      let _last = _curr in
      let _last_action = 20 in
      let next_char, _buf, _len, _curr, _last =
        if _curr >= _len then
          __ocaml_lex_refill_buf lexbuf _buf _len _curr _last
        else
          Char.code (Bytes.unsafe_get _buf _curr),
          _buf, _len, (_curr + 1), _last
      in
      begin match next_char with
        (* |'0'|'1'|'2'|'3'|'4'|'5'|'6'|'7'|'8'|'9'|'A'|'B'|'C'|'D'|'E'|'F'|'a'|'b'|'c'|'d'|'e'|'f' *)
        |48|49|50|51|52|53|54|55|56|57|65|66|67|68|69|70|97|98|99|100|101|102 ->
          __ocaml_lex_state135 lexbuf 20 (* = last_action *) _buf _len _curr _last
        (* |'"' *)
        | 34 ->
          __ocaml_lex_state29 lexbuf 20 (* = last_action *) _buf _len _curr _last
        (* |'!'|'#'|'$'|'%'|'&'|'\''|'*'|'+'|'-'|'.'|'/'|':'|'<'|'='|'>'|'?'|'@'|'G'|'H'|'I'|'J'|'K'|'L'|'M'|'N'|'O'|'P'|'Q'|'R'|'S'|'T'|'U'|'V'|'W'|'X'|'Y'|'Z'|'\\'|'^'|'_'|'`'|'g'|'h'|'i'|'j'|'k'|'l'|'m'|'n'|'o'|'p'|'q'|'r'|'s'|'t'|'u'|'v'|'w'|'x'|'y'|'z'|'|'|'~' *)
        |33|35|36|37|38|39|42|43|45|46|47|58|60|61|62|63|64|71|72|73|74|75|76|77|78|79|80|81|82|83|84|85|86|87|88|89|90|92|94|95|96|103|104|105|106|107|108|109|110|111|112|113|114|115|116|117|118|119|120|121|122|124|126 ->
          __ocaml_lex_state11 lexbuf 20 (* = last_action *) _buf _len _curr _last
        | _ ->
          let _curr = _last in
          lexbuf.Lexing.lex_curr_pos <- _curr;
          lexbuf.Lexing.lex_last_pos <- _last;
          20 (* = last_action *)
      end
    (* |'0'|'1'|'2'|'3'|'4'|'5'|'6'|'7'|'8'|'9'|'A'|'B'|'C'|'D'|'E'|'F'|'a'|'b'|'c'|'d'|'e'|'f' *)
    |48|49|50|51|52|53|54|55|56|57|65|66|67|68|69|70|97|98|99|100|101|102 ->
      __ocaml_lex_state135 lexbuf 10 (* = last_action *) _buf _len _curr _last
    (* |'"' *)
    | 34 ->
      __ocaml_lex_state29 lexbuf 10 (* = last_action *) _buf _len _curr _last
    (* |'!'|'#'|'$'|'%'|'&'|'\''|'*'|'+'|'-'|'.'|'/'|':'|'<'|'='|'>'|'?'|'@'|'G'|'H'|'I'|'J'|'K'|'L'|'M'|'N'|'O'|'P'|'Q'|'R'|'S'|'T'|'U'|'V'|'W'|'X'|'Y'|'Z'|'\\'|'^'|'`'|'g'|'h'|'i'|'j'|'k'|'l'|'m'|'n'|'o'|'p'|'q'|'r'|'s'|'t'|'u'|'v'|'w'|'x'|'y'|'z'|'|'|'~' *)
    |33|35|36|37|38|39|42|43|45|46|47|58|60|61|62|63|64|71|72|73|74|75|76|77|78|79|80|81|82|83|84|85|86|87|88|89|90|92|94|96|103|104|105|106|107|108|109|110|111|112|113|114|115|116|117|118|119|120|121|122|124|126 ->
      __ocaml_lex_state11 lexbuf 10 (* = last_action *) _buf _len _curr _last
    | _ ->
      let _curr = _last in
      lexbuf.Lexing.lex_curr_pos <- _curr;
      lexbuf.Lexing.lex_last_pos <- _last;
      10 (* = last_action *)
  end

and __ocaml_lex_state142 lexbuf _last_action _buf _len _curr _last =
  (* *)
  let _last = _curr in
  let _last_action = 11 in
  let next_char, _buf, _len, _curr, _last =
    if _curr >= _len then
      __ocaml_lex_refill_buf lexbuf _buf _len _curr _last
    else
      Char.code (Bytes.unsafe_get _buf _curr),
      _buf, _len, (_curr + 1), _last
  in
  begin match next_char with
    (* |'"' *)
    | 34 ->
      __ocaml_lex_state29 lexbuf 11 (* = last_action *) _buf _len _curr _last
    (* |'0'|'1'|'2'|'3'|'4'|'5'|'6'|'7'|'8'|'9' *)
    |48|49|50|51|52|53|54|55|56|57 ->
      __ocaml_lex_state142 lexbuf 11 (* = last_action *) _buf _len _curr _last
    (* |'!'|'#'|'$'|'%'|'&'|'\''|'*'|'+'|'-'|'.'|'/'|':'|'<'|'='|'>'|'?'|'@'|'A'|'B'|'C'|'D'|'E'|'F'|'G'|'H'|'I'|'J'|'K'|'L'|'M'|'N'|'O'|'P'|'Q'|'R'|'S'|'T'|'U'|'V'|'W'|'X'|'Y'|'Z'|'\\'|'^'|'`'|'a'|'b'|'c'|'d'|'e'|'f'|'g'|'h'|'i'|'j'|'k'|'l'|'m'|'n'|'o'|'p'|'q'|'r'|'s'|'t'|'u'|'v'|'w'|'x'|'y'|'z'|'|'|'~' *)
    |33|35|36|37|38|39|42|43|45|46|47|58|60|61|62|63|64|65|66|67|68|69|70|71|72|73|74|75|76|77|78|79|80|81|82|83|84|85|86|87|88|89|90|92|94|96|97|98|99|100|101|102|103|104|105|106|107|108|109|110|111|112|113|114|115|116|117|118|119|120|121|122|124|126 ->
      __ocaml_lex_state11 lexbuf 11 (* = last_action *) _buf _len _curr _last
    (* |'_' *)
    | 95 ->
      __ocaml_lex_state145 lexbuf 11 (* = last_action *) _buf _len _curr _last
    | _ ->
      let _curr = _last in
      lexbuf.Lexing.lex_curr_pos <- _curr;
      lexbuf.Lexing.lex_last_pos <- _last;
      11 (* = last_action *)
  end

and __ocaml_lex_state145 lexbuf _last_action _buf _len _curr _last =
  (* *)
  let _last = _curr in
  let _last_action = 20 in
  let next_char, _buf, _len, _curr, _last =
    if _curr >= _len then
      __ocaml_lex_refill_buf lexbuf _buf _len _curr _last
    else
      Char.code (Bytes.unsafe_get _buf _curr),
      _buf, _len, (_curr + 1), _last
  in
  begin match next_char with
    (* |'"' *)
    | 34 ->
      __ocaml_lex_state29 lexbuf 20 (* = last_action *) _buf _len _curr _last
    (* |'0'|'1'|'2'|'3'|'4'|'5'|'6'|'7'|'8'|'9' *)
    |48|49|50|51|52|53|54|55|56|57 ->
      __ocaml_lex_state142 lexbuf 20 (* = last_action *) _buf _len _curr _last
    (* |'!'|'#'|'$'|'%'|'&'|'\''|'*'|'+'|'-'|'.'|'/'|':'|'<'|'='|'>'|'?'|'@'|'A'|'B'|'C'|'D'|'E'|'F'|'G'|'H'|'I'|'J'|'K'|'L'|'M'|'N'|'O'|'P'|'Q'|'R'|'S'|'T'|'U'|'V'|'W'|'X'|'Y'|'Z'|'\\'|'^'|'_'|'`'|'a'|'b'|'c'|'d'|'e'|'f'|'g'|'h'|'i'|'j'|'k'|'l'|'m'|'n'|'o'|'p'|'q'|'r'|'s'|'t'|'u'|'v'|'w'|'x'|'y'|'z'|'|'|'~' *)
    |33|35|36|37|38|39|42|43|45|46|47|58|60|61|62|63|64|65|66|67|68|69|70|71|72|73|74|75|76|77|78|79|80|81|82|83|84|85|86|87|88|89|90|92|94|95|96|97|98|99|100|101|102|103|104|105|106|107|108|109|110|111|112|113|114|115|116|117|118|119|120|121|122|124|126 ->
      __ocaml_lex_state11 lexbuf 20 (* = last_action *) _buf _len _curr _last
    | _ ->
      let _curr = _last in
      lexbuf.Lexing.lex_curr_pos <- _curr;
      lexbuf.Lexing.lex_last_pos <- _last;
      20 (* = last_action *)
  end

and __ocaml_lex_state146 lexbuf _last_action _buf _len _curr _last =
  (* *)
  let _last = _curr in
  let _last_action = 11 in
  let next_char, _buf, _len, _curr, _last =
    if _curr >= _len then
      __ocaml_lex_refill_buf lexbuf _buf _len _curr _last
    else
      Char.code (Bytes.unsafe_get _buf _curr),
      _buf, _len, (_curr + 1), _last
  in
  begin match next_char with
    (* |'_' *)
    | 95 ->
      (* *)
      let _last = _curr in
      let _last_action = 20 in
      let next_char, _buf, _len, _curr, _last =
        if _curr >= _len then
          __ocaml_lex_refill_buf lexbuf _buf _len _curr _last
        else
          Char.code (Bytes.unsafe_get _buf _curr),
          _buf, _len, (_curr + 1), _last
      in
      begin match next_char with
        (* |'"' *)
        | 34 ->
          __ocaml_lex_state29 lexbuf 20 (* = last_action *) _buf _len _curr _last
        (* |'!'|'#'|'$'|'%'|'&'|'\''|'*'|'+'|'-'|'.'|'/'|':'|'<'|'='|'>'|'?'|'@'|'G'|'H'|'I'|'J'|'K'|'L'|'M'|'N'|'O'|'P'|'Q'|'R'|'S'|'T'|'U'|'V'|'W'|'X'|'Y'|'Z'|'\\'|'^'|'_'|'`'|'g'|'h'|'i'|'j'|'k'|'l'|'m'|'n'|'o'|'p'|'q'|'r'|'s'|'t'|'u'|'v'|'w'|'x'|'y'|'z'|'|'|'~' *)
        |33|35|36|37|38|39|42|43|45|46|47|58|60|61|62|63|64|71|72|73|74|75|76|77|78|79|80|81|82|83|84|85|86|87|88|89|90|92|94|95|96|103|104|105|106|107|108|109|110|111|112|113|114|115|116|117|118|119|120|121|122|124|126 ->
          __ocaml_lex_state11 lexbuf 20 (* = last_action *) _buf _len _curr _last
        (* |'0'|'1'|'2'|'3'|'4'|'5'|'6'|'7'|'8'|'9'|'A'|'B'|'C'|'D'|'E'|'F'|'a'|'b'|'c'|'d'|'e'|'f' *)
        |48|49|50|51|52|53|54|55|56|57|65|66|67|68|69|70|97|98|99|100|101|102 ->
          __ocaml_lex_state146 lexbuf 20 (* = last_action *) _buf _len _curr _last
        | _ ->
          let _curr = _last in
          lexbuf.Lexing.lex_curr_pos <- _curr;
          lexbuf.Lexing.lex_last_pos <- _last;
          20 (* = last_action *)
      end
    (* |'"' *)
    | 34 ->
      __ocaml_lex_state29 lexbuf 11 (* = last_action *) _buf _len _curr _last
    (* |'!'|'#'|'$'|'%'|'&'|'\''|'*'|'+'|'-'|'.'|'/'|':'|'<'|'='|'>'|'?'|'@'|'G'|'H'|'I'|'J'|'K'|'L'|'M'|'N'|'O'|'P'|'Q'|'R'|'S'|'T'|'U'|'V'|'W'|'X'|'Y'|'Z'|'\\'|'^'|'`'|'g'|'h'|'i'|'j'|'k'|'l'|'m'|'n'|'o'|'p'|'q'|'r'|'s'|'t'|'u'|'v'|'w'|'x'|'y'|'z'|'|'|'~' *)
    |33|35|36|37|38|39|42|43|45|46|47|58|60|61|62|63|64|71|72|73|74|75|76|77|78|79|80|81|82|83|84|85|86|87|88|89|90|92|94|96|103|104|105|106|107|108|109|110|111|112|113|114|115|116|117|118|119|120|121|122|124|126 ->
      __ocaml_lex_state11 lexbuf 11 (* = last_action *) _buf _len _curr _last
    (* |'0'|'1'|'2'|'3'|'4'|'5'|'6'|'7'|'8'|'9'|'A'|'B'|'C'|'D'|'E'|'F'|'a'|'b'|'c'|'d'|'e'|'f' *)
    |48|49|50|51|52|53|54|55|56|57|65|66|67|68|69|70|97|98|99|100|101|102 ->
      __ocaml_lex_state146 lexbuf 11 (* = last_action *) _buf _len _curr _last
    | _ ->
      let _curr = _last in
      lexbuf.Lexing.lex_curr_pos <- _curr;
      lexbuf.Lexing.lex_last_pos <- _last;
      11 (* = last_action *)
  end

and __ocaml_lex_state148 lexbuf _last_action _buf _len _curr _last =
  (* *)
  let _last = _curr in
  let _last_action = 12 in
  let next_char, _buf, _len, _curr, _last =
    if _curr >= _len then
      __ocaml_lex_refill_buf lexbuf _buf _len _curr _last
    else
      Char.code (Bytes.unsafe_get _buf _curr),
      _buf, _len, (_curr + 1), _last
  in
  begin match next_char with
    (* |'!'|'#'|'$'|'%'|'&'|'\''|'*'|'+'|'-'|'.'|'/'|'0'|'1'|'2'|'3'|'4'|'5'|'6'|'7'|'8'|'9'|':'|'<'|'='|'>'|'?'|'@'|'A'|'B'|'C'|'D'|'E'|'F'|'G'|'H'|'I'|'J'|'K'|'L'|'M'|'N'|'O'|'P'|'Q'|'R'|'S'|'T'|'U'|'V'|'W'|'X'|'Y'|'Z'|'\\'|'^'|'_'|'`'|'a'|'b'|'c'|'d'|'e'|'f'|'g'|'h'|'i'|'j'|'k'|'l'|'m'|'n'|'o'|'p'|'q'|'r'|'s'|'t'|'u'|'v'|'w'|'x'|'y'|'z'|'|'|'~' *)
    |33|35|36|37|38|39|42|43|45|46|47|48|49|50|51|52|53|54|55|56|57|58|60|61|62|63|64|65|66|67|68|69|70|71|72|73|74|75|76|77|78|79|80|81|82|83|84|85|86|87|88|89|90|92|94|95|96|97|98|99|100|101|102|103|104|105|106|107|108|109|110|111|112|113|114|115|116|117|118|119|120|121|122|124|126 ->
      __ocaml_lex_state148 lexbuf 12 (* = last_action *) _buf _len _curr _last
    (* |'"' *)
    | 34 ->
      __ocaml_lex_state29 lexbuf 12 (* = last_action *) _buf _len _curr _last
    | _ ->
      let _curr = _last in
      lexbuf.Lexing.lex_curr_pos <- _curr;
      lexbuf.Lexing.lex_last_pos <- _last;
      12 (* = last_action *)
  end

and __ocaml_lex_state149 lexbuf _last_action _buf _len _curr _last =
  (* *)
  let _last = _curr in
  let _last_action = 15 in
  let next_char, _buf, _len, _curr, _last =
    if _curr >= _len then
      __ocaml_lex_refill_buf lexbuf _buf _len _curr _last
    else
      Char.code (Bytes.unsafe_get _buf _curr),
      _buf, _len, (_curr + 1), _last
  in
  begin match next_char with
    (* |'\194'|'\195'|'\196'|'\197'|'\198'|'\199'|'\200'|'\201'|'\202'|'\203'|'\204'|'\205'|'\206'|'\207'|'\208'|'\209'|'\210'|'\211'|'\212'|'\213'|'\214'|'\215'|'\216'|'\217'|'\218'|'\219'|'\220'|'\221'|'\222'|'\223' *)
    |194|195|196|197|198|199|200|201|202|203|204|205|206|207|208|209|210|211|212|213|214|215|216|217|218|219|220|221|222|223 ->
      let next_char, _buf, _len, _curr, _last =
        if _curr >= _len then
          __ocaml_lex_refill_buf lexbuf _buf _len _curr _last
        else
          Char.code (Bytes.unsafe_get _buf _curr),
          _buf, _len, (_curr + 1), _last
      in
      begin match next_char with
        (* |'\128'|'\129'|'\130'|'\131'|'\132'|'\133'|'\134'|'\135'|'\136'|'\137'|'\138'|'\139'|'\140'|'\141'|'\142'|'\143'|'\144'|'\145'|'\146'|'\147'|'\148'|'\149'|'\150'|'\151'|'\152'|'\153'|'\154'|'\155'|'\156'|'\157'|'\158'|'\159'|'\160'|'\161'|'\162'|'\163'|'\164'|'\165'|'\166'|'\167'|'\168'|'\169'|'\170'|'\171'|'\172'|'\173'|'\174'|'\175'|'\176'|'\177'|'\178'|'\179'|'\180'|'\181'|'\182'|'\183'|'\184'|'\185'|'\186'|'\187'|'\188'|'\189'|'\190'|'\191' *)
        |128|129|130|131|132|133|134|135|136|137|138|139|140|141|142|143|144|145|146|147|148|149|150|151|152|153|154|155|156|157|158|159|160|161|162|163|164|165|166|167|168|169|170|171|172|173|174|175|176|177|178|179|180|181|182|183|184|185|186|187|188|189|190|191 ->
          __ocaml_lex_state149 lexbuf 15 (* = last_action *) _buf _len _curr _last
        | _ ->
          let _curr = _last in
          lexbuf.Lexing.lex_curr_pos <- _curr;
          lexbuf.Lexing.lex_last_pos <- _last;
          15 (* = last_action *)
      end
    (* |'\128'|'\129'|'\130'|'\131'|'\132'|'\133'|'\134'|'\135'|'\136'|'\137'|'\138'|'\139'|'\140'|'\141'|'\142'|'\143'|'\144'|'\145'|'\146'|'\147'|'\148'|'\149'|'\150'|'\151'|'\152'|'\153'|'\154'|'\155'|'\156'|'\157'|'\158'|'\159'|'\160'|'\161'|'\162'|'\163'|'\164'|'\165'|'\166'|'\167'|'\168'|'\169'|'\170'|'\171'|'\172'|'\173'|'\174'|'\175'|'\176'|'\177'|'\178'|'\179'|'\180'|'\181'|'\182'|'\183'|'\184'|'\185'|'\186'|'\187'|'\188'|'\189'|'\190'|'\191'|'\192'|'\193'|'\245'|'\246'|'\247'|'\248'|'\249'|'\250'|'\251'|'\252'|'\253'|'\254'|'\255' *)
    |128|129|130|131|132|133|134|135|136|137|138|139|140|141|142|143|144|145|146|147|148|149|150|151|152|153|154|155|156|157|158|159|160|161|162|163|164|165|166|167|168|169|170|171|172|173|174|175|176|177|178|179|180|181|182|183|184|185|186|187|188|189|190|191|192|193|245|246|247|248|249|250|251|252|253|254|255 ->
      let _curr = _last in
      lexbuf.Lexing.lex_curr_pos <- _curr;
      lexbuf.Lexing.lex_last_pos <- _last;
      15 (* = last_action *)
    (* |'\225'|'\226'|'\227'|'\228'|'\229'|'\230'|'\231'|'\232'|'\233'|'\234'|'\235'|'\236'|'\238'|'\239' *)
    |225|226|227|228|229|230|231|232|233|234|235|236|238|239 ->
      let next_char, _buf, _len, _curr, _last =
        if _curr >= _len then
          __ocaml_lex_refill_buf lexbuf _buf _len _curr _last
        else
          Char.code (Bytes.unsafe_get _buf _curr),
          _buf, _len, (_curr + 1), _last
      in
      begin match next_char with
        (* |'\128'|'\129'|'\130'|'\131'|'\132'|'\133'|'\134'|'\135'|'\136'|'\137'|'\138'|'\139'|'\140'|'\141'|'\142'|'\143'|'\144'|'\145'|'\146'|'\147'|'\148'|'\149'|'\150'|'\151'|'\152'|'\153'|'\154'|'\155'|'\156'|'\157'|'\158'|'\159'|'\160'|'\161'|'\162'|'\163'|'\164'|'\165'|'\166'|'\167'|'\168'|'\169'|'\170'|'\171'|'\172'|'\173'|'\174'|'\175'|'\176'|'\177'|'\178'|'\179'|'\180'|'\181'|'\182'|'\183'|'\184'|'\185'|'\186'|'\187'|'\188'|'\189'|'\190'|'\191' *)
        |128|129|130|131|132|133|134|135|136|137|138|139|140|141|142|143|144|145|146|147|148|149|150|151|152|153|154|155|156|157|158|159|160|161|162|163|164|165|166|167|168|169|170|171|172|173|174|175|176|177|178|179|180|181|182|183|184|185|186|187|188|189|190|191 ->
          let next_char, _buf, _len, _curr, _last =
            if _curr >= _len then
              __ocaml_lex_refill_buf lexbuf _buf _len _curr _last
            else
              Char.code (Bytes.unsafe_get _buf _curr),
              _buf, _len, (_curr + 1), _last
          in
          begin match next_char with
            (* |'\128'|'\129'|'\130'|'\131'|'\132'|'\133'|'\134'|'\135'|'\136'|'\137'|'\138'|'\139'|'\140'|'\141'|'\142'|'\143'|'\144'|'\145'|'\146'|'\147'|'\148'|'\149'|'\150'|'\151'|'\152'|'\153'|'\154'|'\155'|'\156'|'\157'|'\158'|'\159'|'\160'|'\161'|'\162'|'\163'|'\164'|'\165'|'\166'|'\167'|'\168'|'\169'|'\170'|'\171'|'\172'|'\173'|'\174'|'\175'|'\176'|'\177'|'\178'|'\179'|'\180'|'\181'|'\182'|'\183'|'\184'|'\185'|'\186'|'\187'|'\188'|'\189'|'\190'|'\191' *)
            |128|129|130|131|132|133|134|135|136|137|138|139|140|141|142|143|144|145|146|147|148|149|150|151|152|153|154|155|156|157|158|159|160|161|162|163|164|165|166|167|168|169|170|171|172|173|174|175|176|177|178|179|180|181|182|183|184|185|186|187|188|189|190|191 ->
              __ocaml_lex_state149 lexbuf 15 (* = last_action *) _buf _len _curr _last
            | _ ->
              let _curr = _last in
              lexbuf.Lexing.lex_curr_pos <- _curr;
              lexbuf.Lexing.lex_last_pos <- _last;
              15 (* = last_action *)
          end
        | _ ->
          let _curr = _last in
          lexbuf.Lexing.lex_curr_pos <- _curr;
          lexbuf.Lexing.lex_last_pos <- _last;
          15 (* = last_action *)
      end
    (* |'\244' *)
    | 244 ->
      let next_char, _buf, _len, _curr, _last =
        if _curr >= _len then
          __ocaml_lex_refill_buf lexbuf _buf _len _curr _last
        else
          Char.code (Bytes.unsafe_get _buf _curr),
          _buf, _len, (_curr + 1), _last
      in
      begin match next_char with
        (* |'\128'|'\129'|'\130'|'\131'|'\132'|'\133'|'\134'|'\135'|'\136'|'\137'|'\138'|'\139'|'\140'|'\141'|'\142'|'\143' *)
        |128|129|130|131|132|133|134|135|136|137|138|139|140|141|142|143 ->
          let next_char, _buf, _len, _curr, _last =
            if _curr >= _len then
              __ocaml_lex_refill_buf lexbuf _buf _len _curr _last
            else
              Char.code (Bytes.unsafe_get _buf _curr),
              _buf, _len, (_curr + 1), _last
          in
          begin match next_char with
            (* |'\128'|'\129'|'\130'|'\131'|'\132'|'\133'|'\134'|'\135'|'\136'|'\137'|'\138'|'\139'|'\140'|'\141'|'\142'|'\143'|'\144'|'\145'|'\146'|'\147'|'\148'|'\149'|'\150'|'\151'|'\152'|'\153'|'\154'|'\155'|'\156'|'\157'|'\158'|'\159'|'\160'|'\161'|'\162'|'\163'|'\164'|'\165'|'\166'|'\167'|'\168'|'\169'|'\170'|'\171'|'\172'|'\173'|'\174'|'\175'|'\176'|'\177'|'\178'|'\179'|'\180'|'\181'|'\182'|'\183'|'\184'|'\185'|'\186'|'\187'|'\188'|'\189'|'\190'|'\191' *)
            |128|129|130|131|132|133|134|135|136|137|138|139|140|141|142|143|144|145|146|147|148|149|150|151|152|153|154|155|156|157|158|159|160|161|162|163|164|165|166|167|168|169|170|171|172|173|174|175|176|177|178|179|180|181|182|183|184|185|186|187|188|189|190|191 ->
              let next_char, _buf, _len, _curr, _last =
                if _curr >= _len then
                  __ocaml_lex_refill_buf lexbuf _buf _len _curr _last
                else
                  Char.code (Bytes.unsafe_get _buf _curr),
                  _buf, _len, (_curr + 1), _last
              in
              begin match next_char with
                (* |'\128'|'\129'|'\130'|'\131'|'\132'|'\133'|'\134'|'\135'|'\136'|'\137'|'\138'|'\139'|'\140'|'\141'|'\142'|'\143'|'\144'|'\145'|'\146'|'\147'|'\148'|'\149'|'\150'|'\151'|'\152'|'\153'|'\154'|'\155'|'\156'|'\157'|'\158'|'\159'|'\160'|'\161'|'\162'|'\163'|'\164'|'\165'|'\166'|'\167'|'\168'|'\169'|'\170'|'\171'|'\172'|'\173'|'\174'|'\175'|'\176'|'\177'|'\178'|'\179'|'\180'|'\181'|'\182'|'\183'|'\184'|'\185'|'\186'|'\187'|'\188'|'\189'|'\190'|'\191' *)
                |128|129|130|131|132|133|134|135|136|137|138|139|140|141|142|143|144|145|146|147|148|149|150|151|152|153|154|155|156|157|158|159|160|161|162|163|164|165|166|167|168|169|170|171|172|173|174|175|176|177|178|179|180|181|182|183|184|185|186|187|188|189|190|191 ->
                  __ocaml_lex_state149 lexbuf 15 (* = last_action *) _buf _len _curr _last
                | _ ->
                  let _curr = _last in
                  lexbuf.Lexing.lex_curr_pos <- _curr;
                  lexbuf.Lexing.lex_last_pos <- _last;
                  15 (* = last_action *)
              end
            | _ ->
              let _curr = _last in
              lexbuf.Lexing.lex_curr_pos <- _curr;
              lexbuf.Lexing.lex_last_pos <- _last;
              15 (* = last_action *)
          end
        | _ ->
          let _curr = _last in
          lexbuf.Lexing.lex_curr_pos <- _curr;
          lexbuf.Lexing.lex_last_pos <- _last;
          15 (* = last_action *)
      end
    (* |'\241'|'\242'|'\243' *)
    |241|242|243 ->
      let next_char, _buf, _len, _curr, _last =
        if _curr >= _len then
          __ocaml_lex_refill_buf lexbuf _buf _len _curr _last
        else
          Char.code (Bytes.unsafe_get _buf _curr),
          _buf, _len, (_curr + 1), _last
      in
      begin match next_char with
        (* |'\128'|'\129'|'\130'|'\131'|'\132'|'\133'|'\134'|'\135'|'\136'|'\137'|'\138'|'\139'|'\140'|'\141'|'\142'|'\143'|'\144'|'\145'|'\146'|'\147'|'\148'|'\149'|'\150'|'\151'|'\152'|'\153'|'\154'|'\155'|'\156'|'\157'|'\158'|'\159'|'\160'|'\161'|'\162'|'\163'|'\164'|'\165'|'\166'|'\167'|'\168'|'\169'|'\170'|'\171'|'\172'|'\173'|'\174'|'\175'|'\176'|'\177'|'\178'|'\179'|'\180'|'\181'|'\182'|'\183'|'\184'|'\185'|'\186'|'\187'|'\188'|'\189'|'\190'|'\191' *)
        |128|129|130|131|132|133|134|135|136|137|138|139|140|141|142|143|144|145|146|147|148|149|150|151|152|153|154|155|156|157|158|159|160|161|162|163|164|165|166|167|168|169|170|171|172|173|174|175|176|177|178|179|180|181|182|183|184|185|186|187|188|189|190|191 ->
          let next_char, _buf, _len, _curr, _last =
            if _curr >= _len then
              __ocaml_lex_refill_buf lexbuf _buf _len _curr _last
            else
              Char.code (Bytes.unsafe_get _buf _curr),
              _buf, _len, (_curr + 1), _last
          in
          begin match next_char with
            (* |'\128'|'\129'|'\130'|'\131'|'\132'|'\133'|'\134'|'\135'|'\136'|'\137'|'\138'|'\139'|'\140'|'\141'|'\142'|'\143'|'\144'|'\145'|'\146'|'\147'|'\148'|'\149'|'\150'|'\151'|'\152'|'\153'|'\154'|'\155'|'\156'|'\157'|'\158'|'\159'|'\160'|'\161'|'\162'|'\163'|'\164'|'\165'|'\166'|'\167'|'\168'|'\169'|'\170'|'\171'|'\172'|'\173'|'\174'|'\175'|'\176'|'\177'|'\178'|'\179'|'\180'|'\181'|'\182'|'\183'|'\184'|'\185'|'\186'|'\187'|'\188'|'\189'|'\190'|'\191' *)
            |128|129|130|131|132|133|134|135|136|137|138|139|140|141|142|143|144|145|146|147|148|149|150|151|152|153|154|155|156|157|158|159|160|161|162|163|164|165|166|167|168|169|170|171|172|173|174|175|176|177|178|179|180|181|182|183|184|185|186|187|188|189|190|191 ->
              let next_char, _buf, _len, _curr, _last =
                if _curr >= _len then
                  __ocaml_lex_refill_buf lexbuf _buf _len _curr _last
                else
                  Char.code (Bytes.unsafe_get _buf _curr),
                  _buf, _len, (_curr + 1), _last
              in
              begin match next_char with
                (* |'\128'|'\129'|'\130'|'\131'|'\132'|'\133'|'\134'|'\135'|'\136'|'\137'|'\138'|'\139'|'\140'|'\141'|'\142'|'\143'|'\144'|'\145'|'\146'|'\147'|'\148'|'\149'|'\150'|'\151'|'\152'|'\153'|'\154'|'\155'|'\156'|'\157'|'\158'|'\159'|'\160'|'\161'|'\162'|'\163'|'\164'|'\165'|'\166'|'\167'|'\168'|'\169'|'\170'|'\171'|'\172'|'\173'|'\174'|'\175'|'\176'|'\177'|'\178'|'\179'|'\180'|'\181'|'\182'|'\183'|'\184'|'\185'|'\186'|'\187'|'\188'|'\189'|'\190'|'\191' *)
                |128|129|130|131|132|133|134|135|136|137|138|139|140|141|142|143|144|145|146|147|148|149|150|151|152|153|154|155|156|157|158|159|160|161|162|163|164|165|166|167|168|169|170|171|172|173|174|175|176|177|178|179|180|181|182|183|184|185|186|187|188|189|190|191 ->
                  __ocaml_lex_state149 lexbuf 15 (* = last_action *) _buf _len _curr _last
                | _ ->
                  let _curr = _last in
                  lexbuf.Lexing.lex_curr_pos <- _curr;
                  lexbuf.Lexing.lex_last_pos <- _last;
                  15 (* = last_action *)
              end
            | _ ->
              let _curr = _last in
              lexbuf.Lexing.lex_curr_pos <- _curr;
              lexbuf.Lexing.lex_last_pos <- _last;
              15 (* = last_action *)
          end
        | _ ->
          let _curr = _last in
          lexbuf.Lexing.lex_curr_pos <- _curr;
          lexbuf.Lexing.lex_last_pos <- _last;
          15 (* = last_action *)
      end
    (* |eof *)
    | 256 ->
      (* *)
      lexbuf.Lexing.lex_curr_pos <- _curr;
      lexbuf.Lexing.lex_last_pos <- _last;
      13
    (* |'\224' *)
    | 224 ->
      let next_char, _buf, _len, _curr, _last =
        if _curr >= _len then
          __ocaml_lex_refill_buf lexbuf _buf _len _curr _last
        else
          Char.code (Bytes.unsafe_get _buf _curr),
          _buf, _len, (_curr + 1), _last
      in
      begin match next_char with
        (* |'\160'|'\161'|'\162'|'\163'|'\164'|'\165'|'\166'|'\167'|'\168'|'\169'|'\170'|'\171'|'\172'|'\173'|'\174'|'\175'|'\176'|'\177'|'\178'|'\179'|'\180'|'\181'|'\182'|'\183'|'\184'|'\185'|'\186'|'\187'|'\188'|'\189'|'\190'|'\191' *)
        |160|161|162|163|164|165|166|167|168|169|170|171|172|173|174|175|176|177|178|179|180|181|182|183|184|185|186|187|188|189|190|191 ->
          let next_char, _buf, _len, _curr, _last =
            if _curr >= _len then
              __ocaml_lex_refill_buf lexbuf _buf _len _curr _last
            else
              Char.code (Bytes.unsafe_get _buf _curr),
              _buf, _len, (_curr + 1), _last
          in
          begin match next_char with
            (* |'\128'|'\129'|'\130'|'\131'|'\132'|'\133'|'\134'|'\135'|'\136'|'\137'|'\138'|'\139'|'\140'|'\141'|'\142'|'\143'|'\144'|'\145'|'\146'|'\147'|'\148'|'\149'|'\150'|'\151'|'\152'|'\153'|'\154'|'\155'|'\156'|'\157'|'\158'|'\159'|'\160'|'\161'|'\162'|'\163'|'\164'|'\165'|'\166'|'\167'|'\168'|'\169'|'\170'|'\171'|'\172'|'\173'|'\174'|'\175'|'\176'|'\177'|'\178'|'\179'|'\180'|'\181'|'\182'|'\183'|'\184'|'\185'|'\186'|'\187'|'\188'|'\189'|'\190'|'\191' *)
            |128|129|130|131|132|133|134|135|136|137|138|139|140|141|142|143|144|145|146|147|148|149|150|151|152|153|154|155|156|157|158|159|160|161|162|163|164|165|166|167|168|169|170|171|172|173|174|175|176|177|178|179|180|181|182|183|184|185|186|187|188|189|190|191 ->
              __ocaml_lex_state149 lexbuf 15 (* = last_action *) _buf _len _curr _last
            | _ ->
              let _curr = _last in
              lexbuf.Lexing.lex_curr_pos <- _curr;
              lexbuf.Lexing.lex_last_pos <- _last;
              15 (* = last_action *)
          end
        | _ ->
          let _curr = _last in
          lexbuf.Lexing.lex_curr_pos <- _curr;
          lexbuf.Lexing.lex_last_pos <- _last;
          15 (* = last_action *)
      end
    (* |'\237' *)
    | 237 ->
      let next_char, _buf, _len, _curr, _last =
        if _curr >= _len then
          __ocaml_lex_refill_buf lexbuf _buf _len _curr _last
        else
          Char.code (Bytes.unsafe_get _buf _curr),
          _buf, _len, (_curr + 1), _last
      in
      begin match next_char with
        (* |'\128'|'\129'|'\130'|'\131'|'\132'|'\133'|'\134'|'\135'|'\136'|'\137'|'\138'|'\139'|'\140'|'\141'|'\142'|'\143'|'\144'|'\145'|'\146'|'\147'|'\148'|'\149'|'\150'|'\151'|'\152'|'\153'|'\154'|'\155'|'\156'|'\157'|'\158'|'\159' *)
        |128|129|130|131|132|133|134|135|136|137|138|139|140|141|142|143|144|145|146|147|148|149|150|151|152|153|154|155|156|157|158|159 ->
          let next_char, _buf, _len, _curr, _last =
            if _curr >= _len then
              __ocaml_lex_refill_buf lexbuf _buf _len _curr _last
            else
              Char.code (Bytes.unsafe_get _buf _curr),
              _buf, _len, (_curr + 1), _last
          in
          begin match next_char with
            (* |'\128'|'\129'|'\130'|'\131'|'\132'|'\133'|'\134'|'\135'|'\136'|'\137'|'\138'|'\139'|'\140'|'\141'|'\142'|'\143'|'\144'|'\145'|'\146'|'\147'|'\148'|'\149'|'\150'|'\151'|'\152'|'\153'|'\154'|'\155'|'\156'|'\157'|'\158'|'\159'|'\160'|'\161'|'\162'|'\163'|'\164'|'\165'|'\166'|'\167'|'\168'|'\169'|'\170'|'\171'|'\172'|'\173'|'\174'|'\175'|'\176'|'\177'|'\178'|'\179'|'\180'|'\181'|'\182'|'\183'|'\184'|'\185'|'\186'|'\187'|'\188'|'\189'|'\190'|'\191' *)
            |128|129|130|131|132|133|134|135|136|137|138|139|140|141|142|143|144|145|146|147|148|149|150|151|152|153|154|155|156|157|158|159|160|161|162|163|164|165|166|167|168|169|170|171|172|173|174|175|176|177|178|179|180|181|182|183|184|185|186|187|188|189|190|191 ->
              __ocaml_lex_state149 lexbuf 15 (* = last_action *) _buf _len _curr _last
            | _ ->
              let _curr = _last in
              lexbuf.Lexing.lex_curr_pos <- _curr;
              lexbuf.Lexing.lex_last_pos <- _last;
              15 (* = last_action *)
          end
        | _ ->
          let _curr = _last in
          lexbuf.Lexing.lex_curr_pos <- _curr;
          lexbuf.Lexing.lex_last_pos <- _last;
          15 (* = last_action *)
      end
    (* |'\n' *)
    | 10 ->
      (* *)
      lexbuf.Lexing.lex_curr_pos <- _curr;
      lexbuf.Lexing.lex_last_pos <- _last;
      14
    (* |'\240' *)
    | 240 ->
      let next_char, _buf, _len, _curr, _last =
        if _curr >= _len then
          __ocaml_lex_refill_buf lexbuf _buf _len _curr _last
        else
          Char.code (Bytes.unsafe_get _buf _curr),
          _buf, _len, (_curr + 1), _last
      in
      begin match next_char with
        (* |'\144'|'\145'|'\146'|'\147'|'\148'|'\149'|'\150'|'\151'|'\152'|'\153'|'\154'|'\155'|'\156'|'\157'|'\158'|'\159'|'\160'|'\161'|'\162'|'\163'|'\164'|'\165'|'\166'|'\167'|'\168'|'\169'|'\170'|'\171'|'\172'|'\173'|'\174'|'\175'|'\176'|'\177'|'\178'|'\179'|'\180'|'\181'|'\182'|'\183'|'\184'|'\185'|'\186'|'\187'|'\188'|'\189'|'\190'|'\191' *)
        |144|145|146|147|148|149|150|151|152|153|154|155|156|157|158|159|160|161|162|163|164|165|166|167|168|169|170|171|172|173|174|175|176|177|178|179|180|181|182|183|184|185|186|187|188|189|190|191 ->
          let next_char, _buf, _len, _curr, _last =
            if _curr >= _len then
              __ocaml_lex_refill_buf lexbuf _buf _len _curr _last
            else
              Char.code (Bytes.unsafe_get _buf _curr),
              _buf, _len, (_curr + 1), _last
          in
          begin match next_char with
            (* |'\128'|'\129'|'\130'|'\131'|'\132'|'\133'|'\134'|'\135'|'\136'|'\137'|'\138'|'\139'|'\140'|'\141'|'\142'|'\143'|'\144'|'\145'|'\146'|'\147'|'\148'|'\149'|'\150'|'\151'|'\152'|'\153'|'\154'|'\155'|'\156'|'\157'|'\158'|'\159'|'\160'|'\161'|'\162'|'\163'|'\164'|'\165'|'\166'|'\167'|'\168'|'\169'|'\170'|'\171'|'\172'|'\173'|'\174'|'\175'|'\176'|'\177'|'\178'|'\179'|'\180'|'\181'|'\182'|'\183'|'\184'|'\185'|'\186'|'\187'|'\188'|'\189'|'\190'|'\191' *)
            |128|129|130|131|132|133|134|135|136|137|138|139|140|141|142|143|144|145|146|147|148|149|150|151|152|153|154|155|156|157|158|159|160|161|162|163|164|165|166|167|168|169|170|171|172|173|174|175|176|177|178|179|180|181|182|183|184|185|186|187|188|189|190|191 ->
              let next_char, _buf, _len, _curr, _last =
                if _curr >= _len then
                  __ocaml_lex_refill_buf lexbuf _buf _len _curr _last
                else
                  Char.code (Bytes.unsafe_get _buf _curr),
                  _buf, _len, (_curr + 1), _last
              in
              begin match next_char with
                (* |'\128'|'\129'|'\130'|'\131'|'\132'|'\133'|'\134'|'\135'|'\136'|'\137'|'\138'|'\139'|'\140'|'\141'|'\142'|'\143'|'\144'|'\145'|'\146'|'\147'|'\148'|'\149'|'\150'|'\151'|'\152'|'\153'|'\154'|'\155'|'\156'|'\157'|'\158'|'\159'|'\160'|'\161'|'\162'|'\163'|'\164'|'\165'|'\166'|'\167'|'\168'|'\169'|'\170'|'\171'|'\172'|'\173'|'\174'|'\175'|'\176'|'\177'|'\178'|'\179'|'\180'|'\181'|'\182'|'\183'|'\184'|'\185'|'\186'|'\187'|'\188'|'\189'|'\190'|'\191' *)
                |128|129|130|131|132|133|134|135|136|137|138|139|140|141|142|143|144|145|146|147|148|149|150|151|152|153|154|155|156|157|158|159|160|161|162|163|164|165|166|167|168|169|170|171|172|173|174|175|176|177|178|179|180|181|182|183|184|185|186|187|188|189|190|191 ->
                  __ocaml_lex_state149 lexbuf 15 (* = last_action *) _buf _len _curr _last
                | _ ->
                  let _curr = _last in
                  lexbuf.Lexing.lex_curr_pos <- _curr;
                  lexbuf.Lexing.lex_last_pos <- _last;
                  15 (* = last_action *)
              end
            | _ ->
              let _curr = _last in
              lexbuf.Lexing.lex_curr_pos <- _curr;
              lexbuf.Lexing.lex_last_pos <- _last;
              15 (* = last_action *)
          end
        | _ ->
          let _curr = _last in
          lexbuf.Lexing.lex_curr_pos <- _curr;
          lexbuf.Lexing.lex_last_pos <- _last;
          15 (* = last_action *)
      end
    | _ ->
      __ocaml_lex_state149 lexbuf 15 (* = last_action *) _buf _len _curr _last
  end


let rec token lexbuf =
  let __ocaml_lex_result =
    let _curr = lexbuf.Lexing.lex_curr_pos in
    let _last = _curr in
    let _len = lexbuf.Lexing.lex_buffer_len in
    let _buf = lexbuf.Lexing.lex_buffer in
    let _last_action = -1 in
    lexbuf.Lexing.lex_start_pos <- _curr;
    let next_char, _buf, _len, _curr, _last =
      if _curr >= _len then
        __ocaml_lex_refill_buf lexbuf _buf _len _curr _last
      else
        Char.code (Bytes.unsafe_get _buf _curr),
        _buf, _len, (_curr + 1), _last
    in
    begin match next_char with
      (* |'\241'|'\242'|'\243' *)
      |241|242|243 ->
        (* *)
        let _last = _curr in
        let _last_action = 23 in
        let next_char, _buf, _len, _curr, _last =
          if _curr >= _len then
            __ocaml_lex_refill_buf lexbuf _buf _len _curr _last
          else
            Char.code (Bytes.unsafe_get _buf _curr),
            _buf, _len, (_curr + 1), _last
        in
        begin match next_char with
          (* |'\128'|'\129'|'\130'|'\131'|'\132'|'\133'|'\134'|'\135'|'\136'|'\137'|'\138'|'\139'|'\140'|'\141'|'\142'|'\143'|'\144'|'\145'|'\146'|'\147'|'\148'|'\149'|'\150'|'\151'|'\152'|'\153'|'\154'|'\155'|'\156'|'\157'|'\158'|'\159'|'\160'|'\161'|'\162'|'\163'|'\164'|'\165'|'\166'|'\167'|'\168'|'\169'|'\170'|'\171'|'\172'|'\173'|'\174'|'\175'|'\176'|'\177'|'\178'|'\179'|'\180'|'\181'|'\182'|'\183'|'\184'|'\185'|'\186'|'\187'|'\188'|'\189'|'\190'|'\191' *)
          |128|129|130|131|132|133|134|135|136|137|138|139|140|141|142|143|144|145|146|147|148|149|150|151|152|153|154|155|156|157|158|159|160|161|162|163|164|165|166|167|168|169|170|171|172|173|174|175|176|177|178|179|180|181|182|183|184|185|186|187|188|189|190|191 ->
            let next_char, _buf, _len, _curr, _last =
              if _curr >= _len then
                __ocaml_lex_refill_buf lexbuf _buf _len _curr _last
              else
                Char.code (Bytes.unsafe_get _buf _curr),
                _buf, _len, (_curr + 1), _last
            in
            begin match next_char with
              (* |'\128'|'\129'|'\130'|'\131'|'\132'|'\133'|'\134'|'\135'|'\136'|'\137'|'\138'|'\139'|'\140'|'\141'|'\142'|'\143'|'\144'|'\145'|'\146'|'\147'|'\148'|'\149'|'\150'|'\151'|'\152'|'\153'|'\154'|'\155'|'\156'|'\157'|'\158'|'\159'|'\160'|'\161'|'\162'|'\163'|'\164'|'\165'|'\166'|'\167'|'\168'|'\169'|'\170'|'\171'|'\172'|'\173'|'\174'|'\175'|'\176'|'\177'|'\178'|'\179'|'\180'|'\181'|'\182'|'\183'|'\184'|'\185'|'\186'|'\187'|'\188'|'\189'|'\190'|'\191' *)
              |128|129|130|131|132|133|134|135|136|137|138|139|140|141|142|143|144|145|146|147|148|149|150|151|152|153|154|155|156|157|158|159|160|161|162|163|164|165|166|167|168|169|170|171|172|173|174|175|176|177|178|179|180|181|182|183|184|185|186|187|188|189|190|191 ->
                let next_char, _buf, _len, _curr, _last =
                  if _curr >= _len then
                    __ocaml_lex_refill_buf lexbuf _buf _len _curr _last
                  else
                    Char.code (Bytes.unsafe_get _buf _curr),
                    _buf, _len, (_curr + 1), _last
                in
                begin match next_char with
                  (* |'\128'|'\129'|'\130'|'\131'|'\132'|'\133'|'\134'|'\135'|'\136'|'\137'|'\138'|'\139'|'\140'|'\141'|'\142'|'\143'|'\144'|'\145'|'\146'|'\147'|'\148'|'\149'|'\150'|'\151'|'\152'|'\153'|'\154'|'\155'|'\156'|'\157'|'\158'|'\159'|'\160'|'\161'|'\162'|'\163'|'\164'|'\165'|'\166'|'\167'|'\168'|'\169'|'\170'|'\171'|'\172'|'\173'|'\174'|'\175'|'\176'|'\177'|'\178'|'\179'|'\180'|'\181'|'\182'|'\183'|'\184'|'\185'|'\186'|'\187'|'\188'|'\189'|'\190'|'\191' *)
                  |128|129|130|131|132|133|134|135|136|137|138|139|140|141|142|143|144|145|146|147|148|149|150|151|152|153|154|155|156|157|158|159|160|161|162|163|164|165|166|167|168|169|170|171|172|173|174|175|176|177|178|179|180|181|182|183|184|185|186|187|188|189|190|191 ->
                    (* *)
                    lexbuf.Lexing.lex_curr_pos <- _curr;
                    lexbuf.Lexing.lex_last_pos <- _last;
                    22
                  | _ ->
                    let _curr = _last in
                    lexbuf.Lexing.lex_curr_pos <- _curr;
                    lexbuf.Lexing.lex_last_pos <- _last;
                    23 (* = last_action *)
                end
              | _ ->
                let _curr = _last in
                lexbuf.Lexing.lex_curr_pos <- _curr;
                lexbuf.Lexing.lex_last_pos <- _last;
                23 (* = last_action *)
            end
          | _ ->
            let _curr = _last in
            lexbuf.Lexing.lex_curr_pos <- _curr;
            lexbuf.Lexing.lex_last_pos <- _last;
            23 (* = last_action *)
        end
      (* |eof *)
      | 256 ->
        (* *)
        lexbuf.Lexing.lex_curr_pos <- _curr;
        lexbuf.Lexing.lex_last_pos <- _last;
        19
      (* |'\t'|'\r'|' ' *)
      |9|13|32 ->
        (* *)
        lexbuf.Lexing.lex_curr_pos <- _curr;
        lexbuf.Lexing.lex_last_pos <- _last;
        17
      (* |','|'['|']'|'{'|'}' *)
      |44|91|93|123|125 ->
        (* *)
        lexbuf.Lexing.lex_curr_pos <- _curr;
        lexbuf.Lexing.lex_last_pos <- _last;
        20
      (* |'n' *)
      | 110 ->
        (* *)
        let _last = _curr in
        let _last_action = 20 in
        let next_char, _buf, _len, _curr, _last =
          if _curr >= _len then
            __ocaml_lex_refill_buf lexbuf _buf _len _curr _last
          else
            Char.code (Bytes.unsafe_get _buf _curr),
            _buf, _len, (_curr + 1), _last
        in
        begin match next_char with
          (* |'a' *)
          | 97 ->
            (* *)
            let _last = _curr in
            let _last_action = 9 in
            let next_char, _buf, _len, _curr, _last =
              if _curr >= _len then
                __ocaml_lex_refill_buf lexbuf _buf _len _curr _last
              else
                Char.code (Bytes.unsafe_get _buf _curr),
                _buf, _len, (_curr + 1), _last
            in
            begin match next_char with
              (* |'"' *)
              | 34 ->
                __ocaml_lex_state29 lexbuf 9 (* = last_action *) _buf _len _curr _last
              (* |'.'|'0'|'1'|'2'|'3'|'4'|'5'|'6'|'7'|'8'|'9'|':'|'A'|'B'|'C'|'D'|'E'|'F'|'G'|'H'|'I'|'J'|'K'|'L'|'M'|'N'|'O'|'P'|'Q'|'R'|'S'|'T'|'U'|'V'|'W'|'X'|'Y'|'Z'|'_'|'a'|'b'|'c'|'d'|'e'|'f'|'g'|'h'|'i'|'j'|'k'|'l'|'m'|'o'|'p'|'q'|'r'|'s'|'t'|'u'|'v'|'w'|'x'|'y'|'z' *)
              |46|48|49|50|51|52|53|54|55|56|57|58|65|66|67|68|69|70|71|72|73|74|75|76|77|78|79|80|81|82|83|84|85|86|87|88|89|90|95|97|98|99|100|101|102|103|104|105|106|107|108|109|111|112|113|114|115|116|117|118|119|120|121|122 ->
                __ocaml_lex_state87 lexbuf 9 (* = last_action *) _buf _len _curr _last
              (* |'!'|'#'|'$'|'%'|'&'|'\''|'*'|'+'|'-'|'/'|'<'|'='|'>'|'?'|'@'|'\\'|'^'|'`'|'|'|'~' *)
              |33|35|36|37|38|39|42|43|45|47|60|61|62|63|64|92|94|96|124|126 ->
                __ocaml_lex_state11 lexbuf 9 (* = last_action *) _buf _len _curr _last
              (* |'n' *)
              | 110 ->
                (* *)
                let _last = _curr in
                let _last_action = 4 in
                let next_char, _buf, _len, _curr, _last =
                  if _curr >= _len then
                    __ocaml_lex_refill_buf lexbuf _buf _len _curr _last
                  else
                    Char.code (Bytes.unsafe_get _buf _curr),
                    _buf, _len, (_curr + 1), _last
                in
                begin match next_char with
                  (* |'"' *)
                  | 34 ->
                    __ocaml_lex_state29 lexbuf 4 (* = last_action *) _buf _len _curr _last
                  (* |'.'|'0'|'1'|'2'|'3'|'4'|'5'|'6'|'7'|'8'|'9'|'A'|'B'|'C'|'D'|'E'|'F'|'G'|'H'|'I'|'J'|'K'|'L'|'M'|'N'|'O'|'P'|'Q'|'R'|'S'|'T'|'U'|'V'|'W'|'X'|'Y'|'Z'|'_'|'a'|'b'|'c'|'d'|'e'|'f'|'g'|'h'|'i'|'j'|'k'|'l'|'m'|'n'|'o'|'p'|'q'|'r'|'s'|'t'|'u'|'v'|'w'|'x'|'y'|'z' *)
                  |46|48|49|50|51|52|53|54|55|56|57|65|66|67|68|69|70|71|72|73|74|75|76|77|78|79|80|81|82|83|84|85|86|87|88|89|90|95|97|98|99|100|101|102|103|104|105|106|107|108|109|110|111|112|113|114|115|116|117|118|119|120|121|122 ->
                    __ocaml_lex_state87 lexbuf 4 (* = last_action *) _buf _len _curr _last
                  (* |'!'|'#'|'$'|'%'|'&'|'\''|'*'|'+'|'-'|'/'|'<'|'='|'>'|'?'|'@'|'\\'|'^'|'`'|'|'|'~' *)
                  |33|35|36|37|38|39|42|43|45|47|60|61|62|63|64|92|94|96|124|126 ->
                    __ocaml_lex_state11 lexbuf 4 (* = last_action *) _buf _len _curr _last
                  (* |':' *)
                  | 58 ->
                    (* *)
                    let _last = _curr in
                    let _last_action = 9 in
                    let next_char, _buf, _len, _curr, _last =
                      if _curr >= _len then
                        __ocaml_lex_refill_buf lexbuf _buf _len _curr _last
                      else
                        Char.code (Bytes.unsafe_get _buf _curr),
                        _buf, _len, (_curr + 1), _last
                    in
                    begin match next_char with
                      (* |'"' *)
                      | 34 ->
                        __ocaml_lex_state29 lexbuf 9 (* = last_action *) _buf _len _curr _last
                      (* |'0' *)
                      | 48 ->
                        (* *)
                        let _last = _curr in
                        (* let _last_action = 9 in*)
                        let next_char, _buf, _len, _curr, _last =
                          if _curr >= _len then
                            __ocaml_lex_refill_buf lexbuf _buf _len _curr _last
                          else
                            Char.code (Bytes.unsafe_get _buf _curr),
                            _buf, _len, (_curr + 1), _last
                        in
                        begin match next_char with
                          (* |'x' *)
                          | 120 ->
                            (* *)
                            let _last = _curr in
                            (* let _last_action = 9 in*)
                            let next_char, _buf, _len, _curr, _last =
                              if _curr >= _len then
                                __ocaml_lex_refill_buf lexbuf _buf _len _curr _last
                              else
                                Char.code (Bytes.unsafe_get _buf _curr),
                                _buf, _len, (_curr + 1), _last
                            in
                            begin match next_char with
                              (* |'0'|'1'|'2'|'3'|'4'|'5'|'6'|'7'|'8'|'9'|'A'|'B'|'C'|'D'|'E'|'F'|'a'|'b'|'c'|'d'|'e'|'f' *)
                              |48|49|50|51|52|53|54|55|56|57|65|66|67|68|69|70|97|98|99|100|101|102 ->
                                __ocaml_lex_state95 lexbuf 9 (* = last_action *) _buf _len _curr _last
                              (* |'"' *)
                              | 34 ->
                                __ocaml_lex_state29 lexbuf 9 (* = last_action *) _buf _len _curr _last
                              (* |'.'|':'|'G'|'H'|'I'|'J'|'K'|'L'|'M'|'N'|'O'|'P'|'Q'|'R'|'S'|'T'|'U'|'V'|'W'|'X'|'Y'|'Z'|'_'|'g'|'h'|'i'|'j'|'k'|'l'|'m'|'n'|'o'|'p'|'q'|'r'|'s'|'t'|'u'|'v'|'w'|'x'|'y'|'z' *)
                              |46|58|71|72|73|74|75|76|77|78|79|80|81|82|83|84|85|86|87|88|89|90|95|103|104|105|106|107|108|109|110|111|112|113|114|115|116|117|118|119|120|121|122 ->
                                __ocaml_lex_state87 lexbuf 9 (* = last_action *) _buf _len _curr _last
                              (* |'!'|'#'|'$'|'%'|'&'|'\''|'*'|'+'|'-'|'/'|'<'|'='|'>'|'?'|'@'|'\\'|'^'|'`'|'|'|'~' *)
                              |33|35|36|37|38|39|42|43|45|47|60|61|62|63|64|92|94|96|124|126 ->
                                __ocaml_lex_state11 lexbuf 9 (* = last_action *) _buf _len _curr _last
                              | _ ->
                                let _curr = _last in
                                lexbuf.Lexing.lex_curr_pos <- _curr;
                                lexbuf.Lexing.lex_last_pos <- _last;
                                9 (* = last_action *)
                            end
                          (* |'"' *)
                          | 34 ->
                            __ocaml_lex_state29 lexbuf 9 (* = last_action *) _buf _len _curr _last
                          (* |'.'|'0'|'1'|'2'|'3'|'4'|'5'|'6'|'7'|'8'|'9'|':'|'A'|'B'|'C'|'D'|'E'|'F'|'G'|'H'|'I'|'J'|'K'|'L'|'M'|'N'|'O'|'P'|'Q'|'R'|'S'|'T'|'U'|'V'|'W'|'X'|'Y'|'Z'|'_'|'a'|'b'|'c'|'d'|'e'|'f'|'g'|'h'|'i'|'j'|'k'|'l'|'m'|'n'|'o'|'p'|'q'|'r'|'s'|'t'|'u'|'v'|'w'|'y'|'z' *)
                          |46|48|49|50|51|52|53|54|55|56|57|58|65|66|67|68|69|70|71|72|73|74|75|76|77|78|79|80|81|82|83|84|85|86|87|88|89|90|95|97|98|99|100|101|102|103|104|105|106|107|108|109|110|111|112|113|114|115|116|117|118|119|121|122 ->
                            __ocaml_lex_state87 lexbuf 9 (* = last_action *) _buf _len _curr _last
                          (* |'!'|'#'|'$'|'%'|'&'|'\''|'*'|'+'|'-'|'/'|'<'|'='|'>'|'?'|'@'|'\\'|'^'|'`'|'|'|'~' *)
                          |33|35|36|37|38|39|42|43|45|47|60|61|62|63|64|92|94|96|124|126 ->
                            __ocaml_lex_state11 lexbuf 9 (* = last_action *) _buf _len _curr _last
                          | _ ->
                            let _curr = _last in
                            lexbuf.Lexing.lex_curr_pos <- _curr;
                            lexbuf.Lexing.lex_last_pos <- _last;
                            9 (* = last_action *)
                        end
                      (* |'.'|'1'|'2'|'3'|'4'|'5'|'6'|'7'|'8'|'9'|':'|'A'|'B'|'C'|'D'|'E'|'F'|'G'|'H'|'I'|'J'|'K'|'L'|'M'|'N'|'O'|'P'|'Q'|'R'|'S'|'T'|'U'|'V'|'W'|'X'|'Y'|'Z'|'_'|'a'|'b'|'c'|'d'|'e'|'f'|'g'|'h'|'i'|'j'|'k'|'l'|'m'|'n'|'o'|'p'|'q'|'r'|'s'|'t'|'u'|'v'|'w'|'x'|'y'|'z' *)
                      |46|49|50|51|52|53|54|55|56|57|58|65|66|67|68|69|70|71|72|73|74|75|76|77|78|79|80|81|82|83|84|85|86|87|88|89|90|95|97|98|99|100|101|102|103|104|105|106|107|108|109|110|111|112|113|114|115|116|117|118|119|120|121|122 ->
                        __ocaml_lex_state87 lexbuf 9 (* = last_action *) _buf _len _curr _last
                      (* |'!'|'#'|'$'|'%'|'&'|'\''|'*'|'+'|'-'|'/'|'<'|'='|'>'|'?'|'@'|'\\'|'^'|'`'|'|'|'~' *)
                      |33|35|36|37|38|39|42|43|45|47|60|61|62|63|64|92|94|96|124|126 ->
                        __ocaml_lex_state11 lexbuf 9 (* = last_action *) _buf _len _curr _last
                      | _ ->
                        let _curr = _last in
                        lexbuf.Lexing.lex_curr_pos <- _curr;
                        lexbuf.Lexing.lex_last_pos <- _last;
                        9 (* = last_action *)
                    end
                  | _ ->
                    let _curr = _last in
                    lexbuf.Lexing.lex_curr_pos <- _curr;
                    lexbuf.Lexing.lex_last_pos <- _last;
                    4 (* = last_action *)
                end
              | _ ->
                let _curr = _last in
                lexbuf.Lexing.lex_curr_pos <- _curr;
                lexbuf.Lexing.lex_last_pos <- _last;
                9 (* = last_action *)
            end
          (* |'"' *)
          | 34 ->
            __ocaml_lex_state29 lexbuf 20 (* = last_action *) _buf _len _curr _last
          (* |'.'|'0'|'1'|'2'|'3'|'4'|'5'|'6'|'7'|'8'|'9'|':'|'A'|'B'|'C'|'D'|'E'|'F'|'G'|'H'|'I'|'J'|'K'|'L'|'M'|'N'|'O'|'P'|'Q'|'R'|'S'|'T'|'U'|'V'|'W'|'X'|'Y'|'Z'|'_'|'b'|'c'|'d'|'e'|'f'|'g'|'h'|'i'|'j'|'k'|'l'|'m'|'n'|'o'|'p'|'q'|'r'|'s'|'t'|'u'|'v'|'w'|'x'|'y'|'z' *)
          |46|48|49|50|51|52|53|54|55|56|57|58|65|66|67|68|69|70|71|72|73|74|75|76|77|78|79|80|81|82|83|84|85|86|87|88|89|90|95|98|99|100|101|102|103|104|105|106|107|108|109|110|111|112|113|114|115|116|117|118|119|120|121|122 ->
            __ocaml_lex_state87 lexbuf 20 (* = last_action *) _buf _len _curr _last
          (* |'!'|'#'|'$'|'%'|'&'|'\''|'*'|'+'|'-'|'/'|'<'|'='|'>'|'?'|'@'|'\\'|'^'|'`'|'|'|'~' *)
          |33|35|36|37|38|39|42|43|45|47|60|61|62|63|64|92|94|96|124|126 ->
            __ocaml_lex_state11 lexbuf 20 (* = last_action *) _buf _len _curr _last
          | _ ->
            let _curr = _last in
            lexbuf.Lexing.lex_curr_pos <- _curr;
            lexbuf.Lexing.lex_last_pos <- _last;
            20 (* = last_action *)
        end
      (* |'0' *)
      | 48 ->
        (* *)
        let _last = _curr in
        let _last_action = 2 in
        let next_char, _buf, _len, _curr, _last =
          if _curr >= _len then
            __ocaml_lex_refill_buf lexbuf _buf _len _curr _last
          else
            Char.code (Bytes.unsafe_get _buf _curr),
            _buf, _len, (_curr + 1), _last
        in
        begin match next_char with
          (* |'E'|'e' *)
          |69|101 ->
            __ocaml_lex_state30 lexbuf 2 (* = last_action *) _buf _len _curr _last
          (* |'0'|'1'|'2'|'3'|'4'|'5'|'6'|'7'|'8'|'9' *)
          |48|49|50|51|52|53|54|55|56|57 ->
            __ocaml_lex_state24 lexbuf 2 (* = last_action *) _buf _len _curr _last
          (* |'.' *)
          | 46 ->
            __ocaml_lex_state31 lexbuf 2 (* = last_action *) _buf _len _curr _last
          (* |'"' *)
          | 34 ->
            __ocaml_lex_state29 lexbuf 2 (* = last_action *) _buf _len _curr _last
          (* |'_' *)
          | 95 ->
            __ocaml_lex_state33 lexbuf 2 (* = last_action *) _buf _len _curr _last
          (* |'!'|'#'|'$'|'%'|'&'|'\''|'*'|'+'|'-'|'/'|':'|'<'|'='|'>'|'?'|'@'|'A'|'B'|'C'|'D'|'F'|'G'|'H'|'I'|'J'|'K'|'L'|'M'|'N'|'O'|'P'|'Q'|'R'|'S'|'T'|'U'|'V'|'W'|'X'|'Y'|'Z'|'\\'|'^'|'`'|'a'|'b'|'c'|'d'|'f'|'g'|'h'|'i'|'j'|'k'|'l'|'m'|'n'|'o'|'p'|'q'|'r'|'s'|'t'|'u'|'v'|'w'|'y'|'z'|'|'|'~' *)
          |33|35|36|37|38|39|42|43|45|47|58|60|61|62|63|64|65|66|67|68|70|71|72|73|74|75|76|77|78|79|80|81|82|83|84|85|86|87|88|89|90|92|94|96|97|98|99|100|102|103|104|105|106|107|108|109|110|111|112|113|114|115|116|117|118|119|121|122|124|126 ->
            __ocaml_lex_state11 lexbuf 2 (* = last_action *) _buf _len _curr _last
          (* |'x' *)
          | 120 ->
            (* *)
            let _last = _curr in
            let _last_action = 20 in
            let next_char, _buf, _len, _curr, _last =
              if _curr >= _len then
                __ocaml_lex_refill_buf lexbuf _buf _len _curr _last
              else
                Char.code (Bytes.unsafe_get _buf _curr),
                _buf, _len, (_curr + 1), _last
            in
            begin match next_char with
              (* |'0'|'1'|'2'|'3'|'4'|'5'|'6'|'7'|'8'|'9'|'A'|'B'|'C'|'D'|'E'|'F'|'a'|'b'|'c'|'d'|'e'|'f' *)
              |48|49|50|51|52|53|54|55|56|57|65|66|67|68|69|70|97|98|99|100|101|102 ->
                __ocaml_lex_state34 lexbuf 20 (* = last_action *) _buf _len _curr _last
              (* |'"' *)
              | 34 ->
                __ocaml_lex_state29 lexbuf 20 (* = last_action *) _buf _len _curr _last
              (* |'!'|'#'|'$'|'%'|'&'|'\''|'*'|'+'|'-'|'.'|'/'|':'|'<'|'='|'>'|'?'|'@'|'G'|'H'|'I'|'J'|'K'|'L'|'M'|'N'|'O'|'P'|'Q'|'R'|'S'|'T'|'U'|'V'|'W'|'X'|'Y'|'Z'|'\\'|'^'|'_'|'`'|'g'|'h'|'i'|'j'|'k'|'l'|'m'|'n'|'o'|'p'|'q'|'r'|'s'|'t'|'u'|'v'|'w'|'x'|'y'|'z'|'|'|'~' *)
              |33|35|36|37|38|39|42|43|45|46|47|58|60|61|62|63|64|71|72|73|74|75|76|77|78|79|80|81|82|83|84|85|86|87|88|89|90|92|94|95|96|103|104|105|106|107|108|109|110|111|112|113|114|115|116|117|118|119|120|121|122|124|126 ->
                __ocaml_lex_state11 lexbuf 20 (* = last_action *) _buf _len _curr _last
              | _ ->
                let _curr = _last in
                lexbuf.Lexing.lex_curr_pos <- _curr;
                lexbuf.Lexing.lex_last_pos <- _last;
                20 (* = last_action *)
            end
          | _ ->
            let _curr = _last in
            lexbuf.Lexing.lex_curr_pos <- _curr;
            lexbuf.Lexing.lex_last_pos <- _last;
            2 (* = last_action *)
        end
      (* |'$' *)
      | 36 ->
        (* *)
        let _last = _curr in
        let _last_action = 20 in
        let next_char, _buf, _len, _curr, _last =
          if _curr >= _len then
            __ocaml_lex_refill_buf lexbuf _buf _len _curr _last
          else
            Char.code (Bytes.unsafe_get _buf _curr),
            _buf, _len, (_curr + 1), _last
        in
        begin match next_char with
          (* |'!'|'#'|'$'|'%'|'&'|'\''|'*'|'+'|'-'|'.'|'/'|'0'|'1'|'2'|'3'|'4'|'5'|'6'|'7'|'8'|'9'|':'|'<'|'='|'>'|'?'|'@'|'A'|'B'|'C'|'D'|'E'|'F'|'G'|'H'|'I'|'J'|'K'|'L'|'M'|'N'|'O'|'P'|'Q'|'R'|'S'|'T'|'U'|'V'|'W'|'X'|'Y'|'Z'|'\\'|'^'|'_'|'`'|'a'|'b'|'c'|'d'|'e'|'f'|'g'|'h'|'i'|'j'|'k'|'l'|'m'|'n'|'o'|'p'|'q'|'r'|'s'|'t'|'u'|'v'|'w'|'x'|'y'|'z'|'|'|'~' *)
          |33|35|36|37|38|39|42|43|45|46|47|48|49|50|51|52|53|54|55|56|57|58|60|61|62|63|64|65|66|67|68|69|70|71|72|73|74|75|76|77|78|79|80|81|82|83|84|85|86|87|88|89|90|92|94|95|96|97|98|99|100|101|102|103|104|105|106|107|108|109|110|111|112|113|114|115|116|117|118|119|120|121|122|124|126 ->
            __ocaml_lex_state148 lexbuf 20 (* = last_action *) _buf _len _curr _last
          (* |'"' *)
          | 34 ->
            __ocaml_lex_state29 lexbuf 20 (* = last_action *) _buf _len _curr _last
          | _ ->
            let _curr = _last in
            lexbuf.Lexing.lex_curr_pos <- _curr;
            lexbuf.Lexing.lex_last_pos <- _last;
            20 (* = last_action *)
        end
      (* |'\224' *)
      | 224 ->
        (* *)
        let _last = _curr in
        let _last_action = 23 in
        let next_char, _buf, _len, _curr, _last =
          if _curr >= _len then
            __ocaml_lex_refill_buf lexbuf _buf _len _curr _last
          else
            Char.code (Bytes.unsafe_get _buf _curr),
            _buf, _len, (_curr + 1), _last
        in
        begin match next_char with
          (* |'\160'|'\161'|'\162'|'\163'|'\164'|'\165'|'\166'|'\167'|'\168'|'\169'|'\170'|'\171'|'\172'|'\173'|'\174'|'\175'|'\176'|'\177'|'\178'|'\179'|'\180'|'\181'|'\182'|'\183'|'\184'|'\185'|'\186'|'\187'|'\188'|'\189'|'\190'|'\191' *)
          |160|161|162|163|164|165|166|167|168|169|170|171|172|173|174|175|176|177|178|179|180|181|182|183|184|185|186|187|188|189|190|191 ->
            let next_char, _buf, _len, _curr, _last =
              if _curr >= _len then
                __ocaml_lex_refill_buf lexbuf _buf _len _curr _last
              else
                Char.code (Bytes.unsafe_get _buf _curr),
                _buf, _len, (_curr + 1), _last
            in
            begin match next_char with
              (* |'\128'|'\129'|'\130'|'\131'|'\132'|'\133'|'\134'|'\135'|'\136'|'\137'|'\138'|'\139'|'\140'|'\141'|'\142'|'\143'|'\144'|'\145'|'\146'|'\147'|'\148'|'\149'|'\150'|'\151'|'\152'|'\153'|'\154'|'\155'|'\156'|'\157'|'\158'|'\159'|'\160'|'\161'|'\162'|'\163'|'\164'|'\165'|'\166'|'\167'|'\168'|'\169'|'\170'|'\171'|'\172'|'\173'|'\174'|'\175'|'\176'|'\177'|'\178'|'\179'|'\180'|'\181'|'\182'|'\183'|'\184'|'\185'|'\186'|'\187'|'\188'|'\189'|'\190'|'\191' *)
              |128|129|130|131|132|133|134|135|136|137|138|139|140|141|142|143|144|145|146|147|148|149|150|151|152|153|154|155|156|157|158|159|160|161|162|163|164|165|166|167|168|169|170|171|172|173|174|175|176|177|178|179|180|181|182|183|184|185|186|187|188|189|190|191 ->
                (* *)
                lexbuf.Lexing.lex_curr_pos <- _curr;
                lexbuf.Lexing.lex_last_pos <- _last;
                22
              | _ ->
                let _curr = _last in
                lexbuf.Lexing.lex_curr_pos <- _curr;
                lexbuf.Lexing.lex_last_pos <- _last;
                23 (* = last_action *)
            end
          | _ ->
            let _curr = _last in
            lexbuf.Lexing.lex_curr_pos <- _curr;
            lexbuf.Lexing.lex_last_pos <- _last;
            23 (* = last_action *)
        end
      (* |'o' *)
      | 111 ->
        (* *)
        let _last = _curr in
        let _last_action = 20 in
        let next_char, _buf, _len, _curr, _last =
          if _curr >= _len then
            __ocaml_lex_refill_buf lexbuf _buf _len _curr _last
          else
            Char.code (Bytes.unsafe_get _buf _curr),
            _buf, _len, (_curr + 1), _last
        in
        begin match next_char with
          (* |'"' *)
          | 34 ->
            __ocaml_lex_state29 lexbuf 20 (* = last_action *) _buf _len _curr _last
          (* |'f' *)
          | 102 ->
            (* *)
            let _last = _curr in
            let _last_action = 9 in
            let next_char, _buf, _len, _curr, _last =
              if _curr >= _len then
                __ocaml_lex_refill_buf lexbuf _buf _len _curr _last
              else
                Char.code (Bytes.unsafe_get _buf _curr),
                _buf, _len, (_curr + 1), _last
            in
            begin match next_char with
              (* |'f' *)
              | 102 ->
                (* *)
                let _last = _curr in
                (* let _last_action = 9 in*)
                let next_char, _buf, _len, _curr, _last =
                  if _curr >= _len then
                    __ocaml_lex_refill_buf lexbuf _buf _len _curr _last
                  else
                    Char.code (Bytes.unsafe_get _buf _curr),
                    _buf, _len, (_curr + 1), _last
                in
                begin match next_char with
                  (* |'"' *)
                  | 34 ->
                    __ocaml_lex_state29 lexbuf 9 (* = last_action *) _buf _len _curr _last
                  (* |'.'|'0'|'1'|'2'|'3'|'4'|'5'|'6'|'7'|'8'|'9'|':'|'A'|'B'|'C'|'D'|'E'|'F'|'G'|'H'|'I'|'J'|'K'|'L'|'M'|'N'|'O'|'P'|'Q'|'R'|'S'|'T'|'U'|'V'|'W'|'X'|'Y'|'Z'|'_'|'a'|'b'|'c'|'d'|'e'|'f'|'g'|'h'|'i'|'j'|'k'|'l'|'m'|'n'|'o'|'p'|'q'|'r'|'t'|'u'|'v'|'w'|'x'|'y'|'z' *)
                  |46|48|49|50|51|52|53|54|55|56|57|58|65|66|67|68|69|70|71|72|73|74|75|76|77|78|79|80|81|82|83|84|85|86|87|88|89|90|95|97|98|99|100|101|102|103|104|105|106|107|108|109|110|111|112|113|114|116|117|118|119|120|121|122 ->
                    __ocaml_lex_state87 lexbuf 9 (* = last_action *) _buf _len _curr _last
                  (* |'!'|'#'|'$'|'%'|'&'|'\''|'*'|'+'|'-'|'/'|'<'|'='|'>'|'?'|'@'|'\\'|'^'|'`'|'|'|'~' *)
                  |33|35|36|37|38|39|42|43|45|47|60|61|62|63|64|92|94|96|124|126 ->
                    __ocaml_lex_state11 lexbuf 9 (* = last_action *) _buf _len _curr _last
                  (* |'s' *)
                  | 115 ->
                    (* *)
                    let _last = _curr in
                    (* let _last_action = 9 in*)
                    let next_char, _buf, _len, _curr, _last =
                      if _curr >= _len then
                        __ocaml_lex_refill_buf lexbuf _buf _len _curr _last
                      else
                        Char.code (Bytes.unsafe_get _buf _curr),
                        _buf, _len, (_curr + 1), _last
                    in
                    begin match next_char with
                      (* |'e' *)
                      | 101 ->
                        (* *)
                        let _last = _curr in
                        (* let _last_action = 9 in*)
                        let next_char, _buf, _len, _curr, _last =
                          if _curr >= _len then
                            __ocaml_lex_refill_buf lexbuf _buf _len _curr _last
                          else
                            Char.code (Bytes.unsafe_get _buf _curr),
                            _buf, _len, (_curr + 1), _last
                        in
                        begin match next_char with
                          (* |'"' *)
                          | 34 ->
                            __ocaml_lex_state29 lexbuf 9 (* = last_action *) _buf _len _curr _last
                          (* |'t' *)
                          | 116 ->
                            (* *)
                            let _last = _curr in
                            (* let _last_action = 9 in*)
                            let next_char, _buf, _len, _curr, _last =
                              if _curr >= _len then
                                __ocaml_lex_refill_buf lexbuf _buf _len _curr _last
                              else
                                Char.code (Bytes.unsafe_get _buf _curr),
                                _buf, _len, (_curr + 1), _last
                            in
                            begin match next_char with
                              (* |'=' *)
                              | 61 ->
                                (* *)
                                let _last = _curr in
                                let _last_action = 20 in
                                let next_char, _buf, _len, _curr, _last =
                                  if _curr >= _len then
                                    __ocaml_lex_refill_buf lexbuf _buf _len _curr _last
                                  else
                                    Char.code (Bytes.unsafe_get _buf _curr),
                                    _buf, _len, (_curr + 1), _last
                                in
                                begin match next_char with
                                  (* |'1'|'2'|'3'|'4'|'5'|'6'|'7'|'8'|'9' *)
                                  |49|50|51|52|53|54|55|56|57 ->
                                    __ocaml_lex_state131 lexbuf 20 (* = last_action *) _buf _len _curr _last
                                  (* |'"' *)
                                  | 34 ->
                                    __ocaml_lex_state29 lexbuf 20 (* = last_action *) _buf _len _curr _last
                                  (* |'0' *)
                                  | 48 ->
                                    (* *)
                                    let _last = _curr in
                                    let _last_action = 10 in
                                    let next_char, _buf, _len, _curr, _last =
                                      if _curr >= _len then
                                        __ocaml_lex_refill_buf lexbuf _buf _len _curr _last
                                      else
                                        Char.code (Bytes.unsafe_get _buf _curr),
                                        _buf, _len, (_curr + 1), _last
                                    in
                                    begin match next_char with
                                      (* |'0'|'1'|'2'|'3'|'4'|'5'|'6'|'7'|'8'|'9' *)
                                      |48|49|50|51|52|53|54|55|56|57 ->
                                        __ocaml_lex_state131 lexbuf 10 (* = last_action *) _buf _len _curr _last
                                      (* |'"' *)
                                      | 34 ->
                                        __ocaml_lex_state29 lexbuf 10 (* = last_action *) _buf _len _curr _last
                                      (* |'x' *)
                                      | 120 ->
                                        (* *)
                                        let _last = _curr in
                                        let _last_action = 20 in
                                        let next_char, _buf, _len, _curr, _last =
                                          if _curr >= _len then
                                            __ocaml_lex_refill_buf lexbuf _buf _len _curr _last
                                          else
                                            Char.code (Bytes.unsafe_get _buf _curr),
                                            _buf, _len, (_curr + 1), _last
                                        in
                                        begin match next_char with
                                          (* |'0'|'1'|'2'|'3'|'4'|'5'|'6'|'7'|'8'|'9'|'A'|'B'|'C'|'D'|'E'|'F'|'a'|'b'|'c'|'d'|'e'|'f' *)
                                          |48|49|50|51|52|53|54|55|56|57|65|66|67|68|69|70|97|98|99|100|101|102 ->
                                            __ocaml_lex_state135 lexbuf 20 (* = last_action *) _buf _len _curr _last
                                          (* |'"' *)
                                          | 34 ->
                                            __ocaml_lex_state29 lexbuf 20 (* = last_action *) _buf _len _curr _last
                                          (* |'!'|'#'|'$'|'%'|'&'|'\''|'*'|'+'|'-'|'.'|'/'|':'|'<'|'='|'>'|'?'|'@'|'G'|'H'|'I'|'J'|'K'|'L'|'M'|'N'|'O'|'P'|'Q'|'R'|'S'|'T'|'U'|'V'|'W'|'X'|'Y'|'Z'|'\\'|'^'|'_'|'`'|'g'|'h'|'i'|'j'|'k'|'l'|'m'|'n'|'o'|'p'|'q'|'r'|'s'|'t'|'u'|'v'|'w'|'x'|'y'|'z'|'|'|'~' *)
                                          |33|35|36|37|38|39|42|43|45|46|47|58|60|61|62|63|64|71|72|73|74|75|76|77|78|79|80|81|82|83|84|85|86|87|88|89|90|92|94|95|96|103|104|105|106|107|108|109|110|111|112|113|114|115|116|117|118|119|120|121|122|124|126 ->
                                            __ocaml_lex_state11 lexbuf 20 (* = last_action *) _buf _len _curr _last
                                          | _ ->
                                            let _curr = _last in
                                            lexbuf.Lexing.lex_curr_pos <- _curr;
                                            lexbuf.Lexing.lex_last_pos <- _last;
                                            20 (* = last_action *)
                                        end
                                      (* |'_' *)
                                      | 95 ->
                                        __ocaml_lex_state134 lexbuf 10 (* = last_action *) _buf _len _curr _last
                                      (* |'!'|'#'|'$'|'%'|'&'|'\''|'*'|'+'|'-'|'.'|'/'|':'|'<'|'='|'>'|'?'|'@'|'A'|'B'|'C'|'D'|'E'|'F'|'G'|'H'|'I'|'J'|'K'|'L'|'M'|'N'|'O'|'P'|'Q'|'R'|'S'|'T'|'U'|'V'|'W'|'X'|'Y'|'Z'|'\\'|'^'|'`'|'a'|'b'|'c'|'d'|'e'|'f'|'g'|'h'|'i'|'j'|'k'|'l'|'m'|'n'|'o'|'p'|'q'|'r'|'s'|'t'|'u'|'v'|'w'|'y'|'z'|'|'|'~' *)
                                      |33|35|36|37|38|39|42|43|45|46|47|58|60|61|62|63|64|65|66|67|68|69|70|71|72|73|74|75|76|77|78|79|80|81|82|83|84|85|86|87|88|89|90|92|94|96|97|98|99|100|101|102|103|104|105|106|107|108|109|110|111|112|113|114|115|116|117|118|119|121|122|124|126 ->
                                        __ocaml_lex_state11 lexbuf 10 (* = last_action *) _buf _len _curr _last
                                      | _ ->
                                        let _curr = _last in
                                        lexbuf.Lexing.lex_curr_pos <- _curr;
                                        lexbuf.Lexing.lex_last_pos <- _last;
                                        10 (* = last_action *)
                                    end
                                  (* |'!'|'#'|'$'|'%'|'&'|'\''|'*'|'+'|'-'|'.'|'/'|':'|'<'|'='|'>'|'?'|'@'|'A'|'B'|'C'|'D'|'E'|'F'|'G'|'H'|'I'|'J'|'K'|'L'|'M'|'N'|'O'|'P'|'Q'|'R'|'S'|'T'|'U'|'V'|'W'|'X'|'Y'|'Z'|'\\'|'^'|'_'|'`'|'a'|'b'|'c'|'d'|'e'|'f'|'g'|'h'|'i'|'j'|'k'|'l'|'m'|'n'|'o'|'p'|'q'|'r'|'s'|'t'|'u'|'v'|'w'|'x'|'y'|'z'|'|'|'~' *)
                                  |33|35|36|37|38|39|42|43|45|46|47|58|60|61|62|63|64|65|66|67|68|69|70|71|72|73|74|75|76|77|78|79|80|81|82|83|84|85|86|87|88|89|90|92|94|95|96|97|98|99|100|101|102|103|104|105|106|107|108|109|110|111|112|113|114|115|116|117|118|119|120|121|122|124|126 ->
                                    __ocaml_lex_state11 lexbuf 20 (* = last_action *) _buf _len _curr _last
                                  | _ ->
                                    let _curr = _last in
                                    lexbuf.Lexing.lex_curr_pos <- _curr;
                                    lexbuf.Lexing.lex_last_pos <- _last;
                                    20 (* = last_action *)
                                end
                              (* |'"' *)
                              | 34 ->
                                __ocaml_lex_state29 lexbuf 9 (* = last_action *) _buf _len _curr _last
                              (* |'.'|'0'|'1'|'2'|'3'|'4'|'5'|'6'|'7'|'8'|'9'|':'|'A'|'B'|'C'|'D'|'E'|'F'|'G'|'H'|'I'|'J'|'K'|'L'|'M'|'N'|'O'|'P'|'Q'|'R'|'S'|'T'|'U'|'V'|'W'|'X'|'Y'|'Z'|'_'|'a'|'b'|'c'|'d'|'e'|'f'|'g'|'h'|'i'|'j'|'k'|'l'|'m'|'n'|'o'|'p'|'q'|'r'|'s'|'t'|'u'|'v'|'w'|'x'|'y'|'z' *)
                              |46|48|49|50|51|52|53|54|55|56|57|58|65|66|67|68|69|70|71|72|73|74|75|76|77|78|79|80|81|82|83|84|85|86|87|88|89|90|95|97|98|99|100|101|102|103|104|105|106|107|108|109|110|111|112|113|114|115|116|117|118|119|120|121|122 ->
                                __ocaml_lex_state87 lexbuf 9 (* = last_action *) _buf _len _curr _last
                              (* |'!'|'#'|'$'|'%'|'&'|'\''|'*'|'+'|'-'|'/'|'<'|'>'|'?'|'@'|'\\'|'^'|'`'|'|'|'~' *)
                              |33|35|36|37|38|39|42|43|45|47|60|62|63|64|92|94|96|124|126 ->
                                __ocaml_lex_state11 lexbuf 9 (* = last_action *) _buf _len _curr _last
                              | _ ->
                                let _curr = _last in
                                lexbuf.Lexing.lex_curr_pos <- _curr;
                                lexbuf.Lexing.lex_last_pos <- _last;
                                9 (* = last_action *)
                            end
                          (* |'.'|'0'|'1'|'2'|'3'|'4'|'5'|'6'|'7'|'8'|'9'|':'|'A'|'B'|'C'|'D'|'E'|'F'|'G'|'H'|'I'|'J'|'K'|'L'|'M'|'N'|'O'|'P'|'Q'|'R'|'S'|'T'|'U'|'V'|'W'|'X'|'Y'|'Z'|'_'|'a'|'b'|'c'|'d'|'e'|'f'|'g'|'h'|'i'|'j'|'k'|'l'|'m'|'n'|'o'|'p'|'q'|'r'|'s'|'u'|'v'|'w'|'x'|'y'|'z' *)
                          |46|48|49|50|51|52|53|54|55|56|57|58|65|66|67|68|69|70|71|72|73|74|75|76|77|78|79|80|81|82|83|84|85|86|87|88|89|90|95|97|98|99|100|101|102|103|104|105|106|107|108|109|110|111|112|113|114|115|117|118|119|120|121|122 ->
                            __ocaml_lex_state87 lexbuf 9 (* = last_action *) _buf _len _curr _last
                          (* |'!'|'#'|'$'|'%'|'&'|'\''|'*'|'+'|'-'|'/'|'<'|'='|'>'|'?'|'@'|'\\'|'^'|'`'|'|'|'~' *)
                          |33|35|36|37|38|39|42|43|45|47|60|61|62|63|64|92|94|96|124|126 ->
                            __ocaml_lex_state11 lexbuf 9 (* = last_action *) _buf _len _curr _last
                          | _ ->
                            let _curr = _last in
                            lexbuf.Lexing.lex_curr_pos <- _curr;
                            lexbuf.Lexing.lex_last_pos <- _last;
                            9 (* = last_action *)
                        end
                      (* |'"' *)
                      | 34 ->
                        __ocaml_lex_state29 lexbuf 9 (* = last_action *) _buf _len _curr _last
                      (* |'.'|'0'|'1'|'2'|'3'|'4'|'5'|'6'|'7'|'8'|'9'|':'|'A'|'B'|'C'|'D'|'E'|'F'|'G'|'H'|'I'|'J'|'K'|'L'|'M'|'N'|'O'|'P'|'Q'|'R'|'S'|'T'|'U'|'V'|'W'|'X'|'Y'|'Z'|'_'|'a'|'b'|'c'|'d'|'f'|'g'|'h'|'i'|'j'|'k'|'l'|'m'|'n'|'o'|'p'|'q'|'r'|'s'|'t'|'u'|'v'|'w'|'x'|'y'|'z' *)
                      |46|48|49|50|51|52|53|54|55|56|57|58|65|66|67|68|69|70|71|72|73|74|75|76|77|78|79|80|81|82|83|84|85|86|87|88|89|90|95|97|98|99|100|102|103|104|105|106|107|108|109|110|111|112|113|114|115|116|117|118|119|120|121|122 ->
                        __ocaml_lex_state87 lexbuf 9 (* = last_action *) _buf _len _curr _last
                      (* |'!'|'#'|'$'|'%'|'&'|'\''|'*'|'+'|'-'|'/'|'<'|'='|'>'|'?'|'@'|'\\'|'^'|'`'|'|'|'~' *)
                      |33|35|36|37|38|39|42|43|45|47|60|61|62|63|64|92|94|96|124|126 ->
                        __ocaml_lex_state11 lexbuf 9 (* = last_action *) _buf _len _curr _last
                      | _ ->
                        let _curr = _last in
                        lexbuf.Lexing.lex_curr_pos <- _curr;
                        lexbuf.Lexing.lex_last_pos <- _last;
                        9 (* = last_action *)
                    end
                  | _ ->
                    let _curr = _last in
                    lexbuf.Lexing.lex_curr_pos <- _curr;
                    lexbuf.Lexing.lex_last_pos <- _last;
                    9 (* = last_action *)
                end
              (* |'"' *)
              | 34 ->
                __ocaml_lex_state29 lexbuf 9 (* = last_action *) _buf _len _curr _last
              (* |'.'|'0'|'1'|'2'|'3'|'4'|'5'|'6'|'7'|'8'|'9'|':'|'A'|'B'|'C'|'D'|'E'|'F'|'G'|'H'|'I'|'J'|'K'|'L'|'M'|'N'|'O'|'P'|'Q'|'R'|'S'|'T'|'U'|'V'|'W'|'X'|'Y'|'Z'|'_'|'a'|'b'|'c'|'d'|'e'|'g'|'h'|'i'|'j'|'k'|'l'|'m'|'n'|'o'|'p'|'q'|'r'|'s'|'t'|'u'|'v'|'w'|'x'|'y'|'z' *)
              |46|48|49|50|51|52|53|54|55|56|57|58|65|66|67|68|69|70|71|72|73|74|75|76|77|78|79|80|81|82|83|84|85|86|87|88|89|90|95|97|98|99|100|101|103|104|105|106|107|108|109|110|111|112|113|114|115|116|117|118|119|120|121|122 ->
                __ocaml_lex_state87 lexbuf 9 (* = last_action *) _buf _len _curr _last
              (* |'!'|'#'|'$'|'%'|'&'|'\''|'*'|'+'|'-'|'/'|'<'|'='|'>'|'?'|'@'|'\\'|'^'|'`'|'|'|'~' *)
              |33|35|36|37|38|39|42|43|45|47|60|61|62|63|64|92|94|96|124|126 ->
                __ocaml_lex_state11 lexbuf 9 (* = last_action *) _buf _len _curr _last
              | _ ->
                let _curr = _last in
                lexbuf.Lexing.lex_curr_pos <- _curr;
                lexbuf.Lexing.lex_last_pos <- _last;
                9 (* = last_action *)
            end
          (* |'.'|'0'|'1'|'2'|'3'|'4'|'5'|'6'|'7'|'8'|'9'|':'|'A'|'B'|'C'|'D'|'E'|'F'|'G'|'H'|'I'|'J'|'K'|'L'|'M'|'N'|'O'|'P'|'Q'|'R'|'S'|'T'|'U'|'V'|'W'|'X'|'Y'|'Z'|'_'|'a'|'b'|'c'|'d'|'e'|'g'|'h'|'i'|'j'|'k'|'l'|'m'|'n'|'o'|'p'|'q'|'r'|'s'|'t'|'u'|'v'|'w'|'x'|'y'|'z' *)
          |46|48|49|50|51|52|53|54|55|56|57|58|65|66|67|68|69|70|71|72|73|74|75|76|77|78|79|80|81|82|83|84|85|86|87|88|89|90|95|97|98|99|100|101|103|104|105|106|107|108|109|110|111|112|113|114|115|116|117|118|119|120|121|122 ->
            __ocaml_lex_state87 lexbuf 20 (* = last_action *) _buf _len _curr _last
          (* |'!'|'#'|'$'|'%'|'&'|'\''|'*'|'+'|'-'|'/'|'<'|'='|'>'|'?'|'@'|'\\'|'^'|'`'|'|'|'~' *)
          |33|35|36|37|38|39|42|43|45|47|60|61|62|63|64|92|94|96|124|126 ->
            __ocaml_lex_state11 lexbuf 20 (* = last_action *) _buf _len _curr _last
          | _ ->
            let _curr = _last in
            lexbuf.Lexing.lex_curr_pos <- _curr;
            lexbuf.Lexing.lex_last_pos <- _last;
            20 (* = last_action *)
        end
      (* |'a' *)
      | 97 ->
        (* *)
        let _last = _curr in
        let _last_action = 20 in
        let next_char, _buf, _len, _curr, _last =
          if _curr >= _len then
            __ocaml_lex_refill_buf lexbuf _buf _len _curr _last
          else
            Char.code (Bytes.unsafe_get _buf _curr),
            _buf, _len, (_curr + 1), _last
        in
        begin match next_char with
          (* |'l' *)
          | 108 ->
            (* *)
            let _last = _curr in
            let _last_action = 9 in
            let next_char, _buf, _len, _curr, _last =
              if _curr >= _len then
                __ocaml_lex_refill_buf lexbuf _buf _len _curr _last
              else
                Char.code (Bytes.unsafe_get _buf _curr),
                _buf, _len, (_curr + 1), _last
            in
            begin match next_char with
              (* |'"' *)
              | 34 ->
                __ocaml_lex_state29 lexbuf 9 (* = last_action *) _buf _len _curr _last
              (* |'.'|'0'|'1'|'2'|'3'|'4'|'5'|'6'|'7'|'8'|'9'|':'|'A'|'B'|'C'|'D'|'E'|'F'|'G'|'H'|'I'|'J'|'K'|'L'|'M'|'N'|'O'|'P'|'Q'|'R'|'S'|'T'|'U'|'V'|'W'|'X'|'Y'|'Z'|'_'|'a'|'b'|'c'|'d'|'e'|'f'|'g'|'h'|'j'|'k'|'l'|'m'|'n'|'o'|'p'|'q'|'r'|'s'|'t'|'u'|'v'|'w'|'x'|'y'|'z' *)
              |46|48|49|50|51|52|53|54|55|56|57|58|65|66|67|68|69|70|71|72|73|74|75|76|77|78|79|80|81|82|83|84|85|86|87|88|89|90|95|97|98|99|100|101|102|103|104|106|107|108|109|110|111|112|113|114|115|116|117|118|119|120|121|122 ->
                __ocaml_lex_state87 lexbuf 9 (* = last_action *) _buf _len _curr _last
              (* |'!'|'#'|'$'|'%'|'&'|'\''|'*'|'+'|'-'|'/'|'<'|'='|'>'|'?'|'@'|'\\'|'^'|'`'|'|'|'~' *)
              |33|35|36|37|38|39|42|43|45|47|60|61|62|63|64|92|94|96|124|126 ->
                __ocaml_lex_state11 lexbuf 9 (* = last_action *) _buf _len _curr _last
              (* |'i' *)
              | 105 ->
                (* *)
                let _last = _curr in
                (* let _last_action = 9 in*)
                let next_char, _buf, _len, _curr, _last =
                  if _curr >= _len then
                    __ocaml_lex_refill_buf lexbuf _buf _len _curr _last
                  else
                    Char.code (Bytes.unsafe_get _buf _curr),
                    _buf, _len, (_curr + 1), _last
                in
                begin match next_char with
                  (* |'"' *)
                  | 34 ->
                    __ocaml_lex_state29 lexbuf 9 (* = last_action *) _buf _len _curr _last
                  (* |'.'|'0'|'1'|'2'|'3'|'4'|'5'|'6'|'7'|'8'|'9'|':'|'A'|'B'|'C'|'D'|'E'|'F'|'G'|'H'|'I'|'J'|'K'|'L'|'M'|'N'|'O'|'P'|'Q'|'R'|'S'|'T'|'U'|'V'|'W'|'X'|'Y'|'Z'|'_'|'a'|'b'|'c'|'d'|'e'|'f'|'h'|'i'|'j'|'k'|'l'|'m'|'n'|'o'|'p'|'q'|'r'|'s'|'t'|'u'|'v'|'w'|'x'|'y'|'z' *)
                  |46|48|49|50|51|52|53|54|55|56|57|58|65|66|67|68|69|70|71|72|73|74|75|76|77|78|79|80|81|82|83|84|85|86|87|88|89|90|95|97|98|99|100|101|102|104|105|106|107|108|109|110|111|112|113|114|115|116|117|118|119|120|121|122 ->
                    __ocaml_lex_state87 lexbuf 9 (* = last_action *) _buf _len _curr _last
                  (* |'!'|'#'|'$'|'%'|'&'|'\''|'*'|'+'|'-'|'/'|'<'|'='|'>'|'?'|'@'|'\\'|'^'|'`'|'|'|'~' *)
                  |33|35|36|37|38|39|42|43|45|47|60|61|62|63|64|92|94|96|124|126 ->
                    __ocaml_lex_state11 lexbuf 9 (* = last_action *) _buf _len _curr _last
                  (* |'g' *)
                  | 103 ->
                    (* *)
                    let _last = _curr in
                    (* let _last_action = 9 in*)
                    let next_char, _buf, _len, _curr, _last =
                      if _curr >= _len then
                        __ocaml_lex_refill_buf lexbuf _buf _len _curr _last
                      else
                        Char.code (Bytes.unsafe_get _buf _curr),
                        _buf, _len, (_curr + 1), _last
                    in
                    begin match next_char with
                      (* |'"' *)
                      | 34 ->
                        __ocaml_lex_state29 lexbuf 9 (* = last_action *) _buf _len _curr _last
                      (* |'n' *)
                      | 110 ->
                        (* *)
                        let _last = _curr in
                        (* let _last_action = 9 in*)
                        let next_char, _buf, _len, _curr, _last =
                          if _curr >= _len then
                            __ocaml_lex_refill_buf lexbuf _buf _len _curr _last
                          else
                            Char.code (Bytes.unsafe_get _buf _curr),
                            _buf, _len, (_curr + 1), _last
                        in
                        begin match next_char with
                          (* |'"' *)
                          | 34 ->
                            __ocaml_lex_state29 lexbuf 9 (* = last_action *) _buf _len _curr _last
                          (* |'.'|'0'|'1'|'2'|'3'|'4'|'5'|'6'|'7'|'8'|'9'|':'|'A'|'B'|'C'|'D'|'E'|'F'|'G'|'H'|'I'|'J'|'K'|'L'|'M'|'N'|'O'|'P'|'Q'|'R'|'S'|'T'|'U'|'V'|'W'|'X'|'Y'|'Z'|'_'|'a'|'b'|'c'|'d'|'e'|'f'|'g'|'h'|'i'|'j'|'k'|'l'|'m'|'n'|'o'|'p'|'q'|'r'|'s'|'t'|'u'|'v'|'w'|'x'|'y'|'z' *)
                          |46|48|49|50|51|52|53|54|55|56|57|58|65|66|67|68|69|70|71|72|73|74|75|76|77|78|79|80|81|82|83|84|85|86|87|88|89|90|95|97|98|99|100|101|102|103|104|105|106|107|108|109|110|111|112|113|114|115|116|117|118|119|120|121|122 ->
                            __ocaml_lex_state87 lexbuf 9 (* = last_action *) _buf _len _curr _last
                          (* |'!'|'#'|'$'|'%'|'&'|'\''|'*'|'+'|'-'|'/'|'<'|'>'|'?'|'@'|'\\'|'^'|'`'|'|'|'~' *)
                          |33|35|36|37|38|39|42|43|45|47|60|62|63|64|92|94|96|124|126 ->
                            __ocaml_lex_state11 lexbuf 9 (* = last_action *) _buf _len _curr _last
                          (* |'=' *)
                          | 61 ->
                            (* *)
                            let _last = _curr in
                            let _last_action = 20 in
                            let next_char, _buf, _len, _curr, _last =
                              if _curr >= _len then
                                __ocaml_lex_refill_buf lexbuf _buf _len _curr _last
                              else
                                Char.code (Bytes.unsafe_get _buf _curr),
                                _buf, _len, (_curr + 1), _last
                            in
                            begin match next_char with
                              (* |'0' *)
                              | 48 ->
                                (* *)
                                let _last = _curr in
                                let _last_action = 11 in
                                let next_char, _buf, _len, _curr, _last =
                                  if _curr >= _len then
                                    __ocaml_lex_refill_buf lexbuf _buf _len _curr _last
                                  else
                                    Char.code (Bytes.unsafe_get _buf _curr),
                                    _buf, _len, (_curr + 1), _last
                                in
                                begin match next_char with
                                  (* |'x' *)
                                  | 120 ->
                                    (* *)
                                    let _last = _curr in
                                    let _last_action = 20 in
                                    let next_char, _buf, _len, _curr, _last =
                                      if _curr >= _len then
                                        __ocaml_lex_refill_buf lexbuf _buf _len _curr _last
                                      else
                                        Char.code (Bytes.unsafe_get _buf _curr),
                                        _buf, _len, (_curr + 1), _last
                                    in
                                    begin match next_char with
                                      (* |'"' *)
                                      | 34 ->
                                        __ocaml_lex_state29 lexbuf 20 (* = last_action *) _buf _len _curr _last
                                      (* |'!'|'#'|'$'|'%'|'&'|'\''|'*'|'+'|'-'|'.'|'/'|':'|'<'|'='|'>'|'?'|'@'|'G'|'H'|'I'|'J'|'K'|'L'|'M'|'N'|'O'|'P'|'Q'|'R'|'S'|'T'|'U'|'V'|'W'|'X'|'Y'|'Z'|'\\'|'^'|'_'|'`'|'g'|'h'|'i'|'j'|'k'|'l'|'m'|'n'|'o'|'p'|'q'|'r'|'s'|'t'|'u'|'v'|'w'|'x'|'y'|'z'|'|'|'~' *)
                                      |33|35|36|37|38|39|42|43|45|46|47|58|60|61|62|63|64|71|72|73|74|75|76|77|78|79|80|81|82|83|84|85|86|87|88|89|90|92|94|95|96|103|104|105|106|107|108|109|110|111|112|113|114|115|116|117|118|119|120|121|122|124|126 ->
                                        __ocaml_lex_state11 lexbuf 20 (* = last_action *) _buf _len _curr _last
                                      (* |'0'|'1'|'2'|'3'|'4'|'5'|'6'|'7'|'8'|'9'|'A'|'B'|'C'|'D'|'E'|'F'|'a'|'b'|'c'|'d'|'e'|'f' *)
                                      |48|49|50|51|52|53|54|55|56|57|65|66|67|68|69|70|97|98|99|100|101|102 ->
                                        __ocaml_lex_state146 lexbuf 20 (* = last_action *) _buf _len _curr _last
                                      | _ ->
                                        let _curr = _last in
                                        lexbuf.Lexing.lex_curr_pos <- _curr;
                                        lexbuf.Lexing.lex_last_pos <- _last;
                                        20 (* = last_action *)
                                    end
                                  (* |'"' *)
                                  | 34 ->
                                    __ocaml_lex_state29 lexbuf 11 (* = last_action *) _buf _len _curr _last
                                  (* |'0'|'1'|'2'|'3'|'4'|'5'|'6'|'7'|'8'|'9' *)
                                  |48|49|50|51|52|53|54|55|56|57 ->
                                    __ocaml_lex_state142 lexbuf 11 (* = last_action *) _buf _len _curr _last
                                  (* |'!'|'#'|'$'|'%'|'&'|'\''|'*'|'+'|'-'|'.'|'/'|':'|'<'|'='|'>'|'?'|'@'|'A'|'B'|'C'|'D'|'E'|'F'|'G'|'H'|'I'|'J'|'K'|'L'|'M'|'N'|'O'|'P'|'Q'|'R'|'S'|'T'|'U'|'V'|'W'|'X'|'Y'|'Z'|'\\'|'^'|'`'|'a'|'b'|'c'|'d'|'e'|'f'|'g'|'h'|'i'|'j'|'k'|'l'|'m'|'n'|'o'|'p'|'q'|'r'|'s'|'t'|'u'|'v'|'w'|'y'|'z'|'|'|'~' *)
                                  |33|35|36|37|38|39|42|43|45|46|47|58|60|61|62|63|64|65|66|67|68|69|70|71|72|73|74|75|76|77|78|79|80|81|82|83|84|85|86|87|88|89|90|92|94|96|97|98|99|100|101|102|103|104|105|106|107|108|109|110|111|112|113|114|115|116|117|118|119|121|122|124|126 ->
                                    __ocaml_lex_state11 lexbuf 11 (* = last_action *) _buf _len _curr _last
                                  (* |'_' *)
                                  | 95 ->
                                    __ocaml_lex_state145 lexbuf 11 (* = last_action *) _buf _len _curr _last
                                  | _ ->
                                    let _curr = _last in
                                    lexbuf.Lexing.lex_curr_pos <- _curr;
                                    lexbuf.Lexing.lex_last_pos <- _last;
                                    11 (* = last_action *)
                                end
                              (* |'"' *)
                              | 34 ->
                                __ocaml_lex_state29 lexbuf 20 (* = last_action *) _buf _len _curr _last
                              (* |'1'|'2'|'3'|'4'|'5'|'6'|'7'|'8'|'9' *)
                              |49|50|51|52|53|54|55|56|57 ->
                                __ocaml_lex_state142 lexbuf 20 (* = last_action *) _buf _len _curr _last
                              (* |'!'|'#'|'$'|'%'|'&'|'\''|'*'|'+'|'-'|'.'|'/'|':'|'<'|'='|'>'|'?'|'@'|'A'|'B'|'C'|'D'|'E'|'F'|'G'|'H'|'I'|'J'|'K'|'L'|'M'|'N'|'O'|'P'|'Q'|'R'|'S'|'T'|'U'|'V'|'W'|'X'|'Y'|'Z'|'\\'|'^'|'_'|'`'|'a'|'b'|'c'|'d'|'e'|'f'|'g'|'h'|'i'|'j'|'k'|'l'|'m'|'n'|'o'|'p'|'q'|'r'|'s'|'t'|'u'|'v'|'w'|'x'|'y'|'z'|'|'|'~' *)
                              |33|35|36|37|38|39|42|43|45|46|47|58|60|61|62|63|64|65|66|67|68|69|70|71|72|73|74|75|76|77|78|79|80|81|82|83|84|85|86|87|88|89|90|92|94|95|96|97|98|99|100|101|102|103|104|105|106|107|108|109|110|111|112|113|114|115|116|117|118|119|120|121|122|124|126 ->
                                __ocaml_lex_state11 lexbuf 20 (* = last_action *) _buf _len _curr _last
                              | _ ->
                                let _curr = _last in
                                lexbuf.Lexing.lex_curr_pos <- _curr;
                                lexbuf.Lexing.lex_last_pos <- _last;
                                20 (* = last_action *)
                            end
                          | _ ->
                            let _curr = _last in
                            lexbuf.Lexing.lex_curr_pos <- _curr;
                            lexbuf.Lexing.lex_last_pos <- _last;
                            9 (* = last_action *)
                        end
                      (* |'.'|'0'|'1'|'2'|'3'|'4'|'5'|'6'|'7'|'8'|'9'|':'|'A'|'B'|'C'|'D'|'E'|'F'|'G'|'H'|'I'|'J'|'K'|'L'|'M'|'N'|'O'|'P'|'Q'|'R'|'S'|'T'|'U'|'V'|'W'|'X'|'Y'|'Z'|'_'|'a'|'b'|'c'|'d'|'e'|'f'|'g'|'h'|'i'|'j'|'k'|'l'|'m'|'o'|'p'|'q'|'r'|'s'|'t'|'u'|'v'|'w'|'x'|'y'|'z' *)
                      |46|48|49|50|51|52|53|54|55|56|57|58|65|66|67|68|69|70|71|72|73|74|75|76|77|78|79|80|81|82|83|84|85|86|87|88|89|90|95|97|98|99|100|101|102|103|104|105|106|107|108|109|111|112|113|114|115|116|117|118|119|120|121|122 ->
                        __ocaml_lex_state87 lexbuf 9 (* = last_action *) _buf _len _curr _last
                      (* |'!'|'#'|'$'|'%'|'&'|'\''|'*'|'+'|'-'|'/'|'<'|'='|'>'|'?'|'@'|'\\'|'^'|'`'|'|'|'~' *)
                      |33|35|36|37|38|39|42|43|45|47|60|61|62|63|64|92|94|96|124|126 ->
                        __ocaml_lex_state11 lexbuf 9 (* = last_action *) _buf _len _curr _last
                      | _ ->
                        let _curr = _last in
                        lexbuf.Lexing.lex_curr_pos <- _curr;
                        lexbuf.Lexing.lex_last_pos <- _last;
                        9 (* = last_action *)
                    end
                  | _ ->
                    let _curr = _last in
                    lexbuf.Lexing.lex_curr_pos <- _curr;
                    lexbuf.Lexing.lex_last_pos <- _last;
                    9 (* = last_action *)
                end
              | _ ->
                let _curr = _last in
                lexbuf.Lexing.lex_curr_pos <- _curr;
                lexbuf.Lexing.lex_last_pos <- _last;
                9 (* = last_action *)
            end
          (* |'"' *)
          | 34 ->
            __ocaml_lex_state29 lexbuf 20 (* = last_action *) _buf _len _curr _last
          (* |'.'|'0'|'1'|'2'|'3'|'4'|'5'|'6'|'7'|'8'|'9'|':'|'A'|'B'|'C'|'D'|'E'|'F'|'G'|'H'|'I'|'J'|'K'|'L'|'M'|'N'|'O'|'P'|'Q'|'R'|'S'|'T'|'U'|'V'|'W'|'X'|'Y'|'Z'|'_'|'a'|'b'|'c'|'d'|'e'|'f'|'g'|'h'|'i'|'j'|'k'|'m'|'n'|'o'|'p'|'q'|'r'|'s'|'t'|'u'|'v'|'w'|'x'|'y'|'z' *)
          |46|48|49|50|51|52|53|54|55|56|57|58|65|66|67|68|69|70|71|72|73|74|75|76|77|78|79|80|81|82|83|84|85|86|87|88|89|90|95|97|98|99|100|101|102|103|104|105|106|107|109|110|111|112|113|114|115|116|117|118|119|120|121|122 ->
            __ocaml_lex_state87 lexbuf 20 (* = last_action *) _buf _len _curr _last
          (* |'!'|'#'|'$'|'%'|'&'|'\''|'*'|'+'|'-'|'/'|'<'|'='|'>'|'?'|'@'|'\\'|'^'|'`'|'|'|'~' *)
          |33|35|36|37|38|39|42|43|45|47|60|61|62|63|64|92|94|96|124|126 ->
            __ocaml_lex_state11 lexbuf 20 (* = last_action *) _buf _len _curr _last
          | _ ->
            let _curr = _last in
            lexbuf.Lexing.lex_curr_pos <- _curr;
            lexbuf.Lexing.lex_last_pos <- _last;
            20 (* = last_action *)
        end
      (* |'1'|'2'|'3'|'4'|'5'|'6'|'7'|'8'|'9' *)
      |49|50|51|52|53|54|55|56|57 ->
        __ocaml_lex_state24 lexbuf _last_action _buf _len _curr _last
      (* |'\225'|'\226'|'\227'|'\228'|'\229'|'\230'|'\231'|'\232'|'\233'|'\234'|'\235'|'\236'|'\238'|'\239' *)
      |225|226|227|228|229|230|231|232|233|234|235|236|238|239 ->
        (* *)
        let _last = _curr in
        let _last_action = 23 in
        let next_char, _buf, _len, _curr, _last =
          if _curr >= _len then
            __ocaml_lex_refill_buf lexbuf _buf _len _curr _last
          else
            Char.code (Bytes.unsafe_get _buf _curr),
            _buf, _len, (_curr + 1), _last
        in
        begin match next_char with
          (* |'\128'|'\129'|'\130'|'\131'|'\132'|'\133'|'\134'|'\135'|'\136'|'\137'|'\138'|'\139'|'\140'|'\141'|'\142'|'\143'|'\144'|'\145'|'\146'|'\147'|'\148'|'\149'|'\150'|'\151'|'\152'|'\153'|'\154'|'\155'|'\156'|'\157'|'\158'|'\159'|'\160'|'\161'|'\162'|'\163'|'\164'|'\165'|'\166'|'\167'|'\168'|'\169'|'\170'|'\171'|'\172'|'\173'|'\174'|'\175'|'\176'|'\177'|'\178'|'\179'|'\180'|'\181'|'\182'|'\183'|'\184'|'\185'|'\186'|'\187'|'\188'|'\189'|'\190'|'\191' *)
          |128|129|130|131|132|133|134|135|136|137|138|139|140|141|142|143|144|145|146|147|148|149|150|151|152|153|154|155|156|157|158|159|160|161|162|163|164|165|166|167|168|169|170|171|172|173|174|175|176|177|178|179|180|181|182|183|184|185|186|187|188|189|190|191 ->
            let next_char, _buf, _len, _curr, _last =
              if _curr >= _len then
                __ocaml_lex_refill_buf lexbuf _buf _len _curr _last
              else
                Char.code (Bytes.unsafe_get _buf _curr),
                _buf, _len, (_curr + 1), _last
            in
            begin match next_char with
              (* |'\128'|'\129'|'\130'|'\131'|'\132'|'\133'|'\134'|'\135'|'\136'|'\137'|'\138'|'\139'|'\140'|'\141'|'\142'|'\143'|'\144'|'\145'|'\146'|'\147'|'\148'|'\149'|'\150'|'\151'|'\152'|'\153'|'\154'|'\155'|'\156'|'\157'|'\158'|'\159'|'\160'|'\161'|'\162'|'\163'|'\164'|'\165'|'\166'|'\167'|'\168'|'\169'|'\170'|'\171'|'\172'|'\173'|'\174'|'\175'|'\176'|'\177'|'\178'|'\179'|'\180'|'\181'|'\182'|'\183'|'\184'|'\185'|'\186'|'\187'|'\188'|'\189'|'\190'|'\191' *)
              |128|129|130|131|132|133|134|135|136|137|138|139|140|141|142|143|144|145|146|147|148|149|150|151|152|153|154|155|156|157|158|159|160|161|162|163|164|165|166|167|168|169|170|171|172|173|174|175|176|177|178|179|180|181|182|183|184|185|186|187|188|189|190|191 ->
                (* *)
                lexbuf.Lexing.lex_curr_pos <- _curr;
                lexbuf.Lexing.lex_last_pos <- _last;
                22
              | _ ->
                let _curr = _last in
                lexbuf.Lexing.lex_curr_pos <- _curr;
                lexbuf.Lexing.lex_last_pos <- _last;
                23 (* = last_action *)
            end
          | _ ->
            let _curr = _last in
            lexbuf.Lexing.lex_curr_pos <- _curr;
            lexbuf.Lexing.lex_last_pos <- _last;
            23 (* = last_action *)
        end
      (* |'(' *)
      | 40 ->
        (* *)
        let _last = _curr in
        let _last_action = 0 in
        let next_char, _buf, _len, _curr, _last =
          if _curr >= _len then
            __ocaml_lex_refill_buf lexbuf _buf _len _curr _last
          else
            Char.code (Bytes.unsafe_get _buf _curr),
            _buf, _len, (_curr + 1), _last
        in
        begin match next_char with
          (* |';' *)
          | 59 ->
            (* *)
            lexbuf.Lexing.lex_curr_pos <- _curr;
            lexbuf.Lexing.lex_last_pos <- _last;
            16
          | _ ->
            let _curr = _last in
            lexbuf.Lexing.lex_curr_pos <- _curr;
            lexbuf.Lexing.lex_last_pos <- _last;
            0 (* = last_action *)
        end
      (* |'b'|'c'|'d'|'e'|'f'|'g'|'h'|'j'|'k'|'l'|'m'|'p'|'q'|'r'|'s'|'t'|'u'|'v'|'w'|'x'|'y'|'z' *)
      |98|99|100|101|102|103|104|106|107|108|109|112|113|114|115|116|117|118|119|120|121|122 ->
        (* *)
        let _last = _curr in
        let _last_action = 20 in
        let next_char, _buf, _len, _curr, _last =
          if _curr >= _len then
            __ocaml_lex_refill_buf lexbuf _buf _len _curr _last
          else
            Char.code (Bytes.unsafe_get _buf _curr),
            _buf, _len, (_curr + 1), _last
        in
        begin match next_char with
          (* |'"' *)
          | 34 ->
            __ocaml_lex_state29 lexbuf 20 (* = last_action *) _buf _len _curr _last
          (* |'.'|'0'|'1'|'2'|'3'|'4'|'5'|'6'|'7'|'8'|'9'|':'|'A'|'B'|'C'|'D'|'E'|'F'|'G'|'H'|'I'|'J'|'K'|'L'|'M'|'N'|'O'|'P'|'Q'|'R'|'S'|'T'|'U'|'V'|'W'|'X'|'Y'|'Z'|'_'|'a'|'b'|'c'|'d'|'e'|'f'|'g'|'h'|'i'|'j'|'k'|'l'|'m'|'n'|'o'|'p'|'q'|'r'|'s'|'t'|'u'|'v'|'w'|'x'|'y'|'z' *)
          |46|48|49|50|51|52|53|54|55|56|57|58|65|66|67|68|69|70|71|72|73|74|75|76|77|78|79|80|81|82|83|84|85|86|87|88|89|90|95|97|98|99|100|101|102|103|104|105|106|107|108|109|110|111|112|113|114|115|116|117|118|119|120|121|122 ->
            __ocaml_lex_state87 lexbuf 20 (* = last_action *) _buf _len _curr _last
          (* |'!'|'#'|'$'|'%'|'&'|'\''|'*'|'+'|'-'|'/'|'<'|'='|'>'|'?'|'@'|'\\'|'^'|'`'|'|'|'~' *)
          |33|35|36|37|38|39|42|43|45|47|60|61|62|63|64|92|94|96|124|126 ->
            __ocaml_lex_state11 lexbuf 20 (* = last_action *) _buf _len _curr _last
          | _ ->
            let _curr = _last in
            lexbuf.Lexing.lex_curr_pos <- _curr;
            lexbuf.Lexing.lex_last_pos <- _last;
            20 (* = last_action *)
        end
      (* |'+'|'-' *)
      |43|45 ->
        (* *)
        let _last = _curr in
        let _last_action = 20 in
        let next_char, _buf, _len, _curr, _last =
          if _curr >= _len then
            __ocaml_lex_refill_buf lexbuf _buf _len _curr _last
          else
            Char.code (Bytes.unsafe_get _buf _curr),
            _buf, _len, (_curr + 1), _last
        in
        begin match next_char with
          (* |'1'|'2'|'3'|'4'|'5'|'6'|'7'|'8'|'9' *)
          |49|50|51|52|53|54|55|56|57 ->
            __ocaml_lex_state72 lexbuf 20 (* = last_action *) _buf _len _curr _last
          (* |'n' *)
          | 110 ->
            (* *)
            let _last = _curr in
            (* let _last_action = 20 in*)
            let next_char, _buf, _len, _curr, _last =
              if _curr >= _len then
                __ocaml_lex_refill_buf lexbuf _buf _len _curr _last
              else
                Char.code (Bytes.unsafe_get _buf _curr),
                _buf, _len, (_curr + 1), _last
            in
            begin match next_char with
              (* |'"' *)
              | 34 ->
                __ocaml_lex_state29 lexbuf 20 (* = last_action *) _buf _len _curr _last
              (* |'a' *)
              | 97 ->
                (* *)
                let _last = _curr in
                (* let _last_action = 20 in*)
                let next_char, _buf, _len, _curr, _last =
                  if _curr >= _len then
                    __ocaml_lex_refill_buf lexbuf _buf _len _curr _last
                  else
                    Char.code (Bytes.unsafe_get _buf _curr),
                    _buf, _len, (_curr + 1), _last
                in
                begin match next_char with
                  (* |'"' *)
                  | 34 ->
                    __ocaml_lex_state29 lexbuf 20 (* = last_action *) _buf _len _curr _last
                  (* |'!'|'#'|'$'|'%'|'&'|'\''|'*'|'+'|'-'|'.'|'/'|'0'|'1'|'2'|'3'|'4'|'5'|'6'|'7'|'8'|'9'|':'|'<'|'='|'>'|'?'|'@'|'A'|'B'|'C'|'D'|'E'|'F'|'G'|'H'|'I'|'J'|'K'|'L'|'M'|'N'|'O'|'P'|'Q'|'R'|'S'|'T'|'U'|'V'|'W'|'X'|'Y'|'Z'|'\\'|'^'|'_'|'`'|'a'|'b'|'c'|'d'|'e'|'f'|'g'|'h'|'i'|'j'|'k'|'l'|'m'|'o'|'p'|'q'|'r'|'s'|'t'|'u'|'v'|'w'|'x'|'y'|'z'|'|'|'~' *)
                  |33|35|36|37|38|39|42|43|45|46|47|48|49|50|51|52|53|54|55|56|57|58|60|61|62|63|64|65|66|67|68|69|70|71|72|73|74|75|76|77|78|79|80|81|82|83|84|85|86|87|88|89|90|92|94|95|96|97|98|99|100|101|102|103|104|105|106|107|108|109|111|112|113|114|115|116|117|118|119|120|121|122|124|126 ->
                    __ocaml_lex_state11 lexbuf 20 (* = last_action *) _buf _len _curr _last
                  (* |'n' *)
                  | 110 ->
                    (* *)
                    let _last = _curr in
                    let _last_action = 4 in
                    let next_char, _buf, _len, _curr, _last =
                      if _curr >= _len then
                        __ocaml_lex_refill_buf lexbuf _buf _len _curr _last
                      else
                        Char.code (Bytes.unsafe_get _buf _curr),
                        _buf, _len, (_curr + 1), _last
                    in
                    begin match next_char with
                      (* |':' *)
                      | 58 ->
                        (* *)
                        let _last = _curr in
                        let _last_action = 20 in
                        let next_char, _buf, _len, _curr, _last =
                          if _curr >= _len then
                            __ocaml_lex_refill_buf lexbuf _buf _len _curr _last
                          else
                            Char.code (Bytes.unsafe_get _buf _curr),
                            _buf, _len, (_curr + 1), _last
                        in
                        begin match next_char with
                          (* |'"' *)
                          | 34 ->
                            __ocaml_lex_state29 lexbuf 20 (* = last_action *) _buf _len _curr _last
                          (* |'!'|'#'|'$'|'%'|'&'|'\''|'*'|'+'|'-'|'.'|'/'|'1'|'2'|'3'|'4'|'5'|'6'|'7'|'8'|'9'|':'|'<'|'='|'>'|'?'|'@'|'A'|'B'|'C'|'D'|'E'|'F'|'G'|'H'|'I'|'J'|'K'|'L'|'M'|'N'|'O'|'P'|'Q'|'R'|'S'|'T'|'U'|'V'|'W'|'X'|'Y'|'Z'|'\\'|'^'|'_'|'`'|'a'|'b'|'c'|'d'|'e'|'f'|'g'|'h'|'i'|'j'|'k'|'l'|'m'|'n'|'o'|'p'|'q'|'r'|'s'|'t'|'u'|'v'|'w'|'x'|'y'|'z'|'|'|'~' *)
                          |33|35|36|37|38|39|42|43|45|46|47|49|50|51|52|53|54|55|56|57|58|60|61|62|63|64|65|66|67|68|69|70|71|72|73|74|75|76|77|78|79|80|81|82|83|84|85|86|87|88|89|90|92|94|95|96|97|98|99|100|101|102|103|104|105|106|107|108|109|110|111|112|113|114|115|116|117|118|119|120|121|122|124|126 ->
                            __ocaml_lex_state11 lexbuf 20 (* = last_action *) _buf _len _curr _last
                          (* |'0' *)
                          | 48 ->
                            (* *)
                            let _last = _curr in
                            (* let _last_action = 20 in*)
                            let next_char, _buf, _len, _curr, _last =
                              if _curr >= _len then
                                __ocaml_lex_refill_buf lexbuf _buf _len _curr _last
                              else
                                Char.code (Bytes.unsafe_get _buf _curr),
                                _buf, _len, (_curr + 1), _last
                            in
                            begin match next_char with
                              (* |'x' *)
                              | 120 ->
                                (* *)
                                let _last = _curr in
                                (* let _last_action = 20 in*)
                                let next_char, _buf, _len, _curr, _last =
                                  if _curr >= _len then
                                    __ocaml_lex_refill_buf lexbuf _buf _len _curr _last
                                  else
                                    Char.code (Bytes.unsafe_get _buf _curr),
                                    _buf, _len, (_curr + 1), _last
                                in
                                begin match next_char with
                                  (* |'"' *)
                                  | 34 ->
                                    __ocaml_lex_state29 lexbuf 20 (* = last_action *) _buf _len _curr _last
                                  (* |'!'|'#'|'$'|'%'|'&'|'\''|'*'|'+'|'-'|'.'|'/'|':'|'<'|'='|'>'|'?'|'@'|'G'|'H'|'I'|'J'|'K'|'L'|'M'|'N'|'O'|'P'|'Q'|'R'|'S'|'T'|'U'|'V'|'W'|'X'|'Y'|'Z'|'\\'|'^'|'_'|'`'|'g'|'h'|'i'|'j'|'k'|'l'|'m'|'n'|'o'|'p'|'q'|'r'|'s'|'t'|'u'|'v'|'w'|'x'|'y'|'z'|'|'|'~' *)
                                  |33|35|36|37|38|39|42|43|45|46|47|58|60|61|62|63|64|71|72|73|74|75|76|77|78|79|80|81|82|83|84|85|86|87|88|89|90|92|94|95|96|103|104|105|106|107|108|109|110|111|112|113|114|115|116|117|118|119|120|121|122|124|126 ->
                                    __ocaml_lex_state11 lexbuf 20 (* = last_action *) _buf _len _curr _last
                                  (* |'0'|'1'|'2'|'3'|'4'|'5'|'6'|'7'|'8'|'9'|'A'|'B'|'C'|'D'|'E'|'F'|'a'|'b'|'c'|'d'|'e'|'f' *)
                                  |48|49|50|51|52|53|54|55|56|57|65|66|67|68|69|70|97|98|99|100|101|102 ->
                                    __ocaml_lex_state85 lexbuf 20 (* = last_action *) _buf _len _curr _last
                                  | _ ->
                                    let _curr = _last in
                                    lexbuf.Lexing.lex_curr_pos <- _curr;
                                    lexbuf.Lexing.lex_last_pos <- _last;
                                    20 (* = last_action *)
                                end
                              (* |'"' *)
                              | 34 ->
                                __ocaml_lex_state29 lexbuf 20 (* = last_action *) _buf _len _curr _last
                              (* |'!'|'#'|'$'|'%'|'&'|'\''|'*'|'+'|'-'|'.'|'/'|'0'|'1'|'2'|'3'|'4'|'5'|'6'|'7'|'8'|'9'|':'|'<'|'='|'>'|'?'|'@'|'A'|'B'|'C'|'D'|'E'|'F'|'G'|'H'|'I'|'J'|'K'|'L'|'M'|'N'|'O'|'P'|'Q'|'R'|'S'|'T'|'U'|'V'|'W'|'X'|'Y'|'Z'|'\\'|'^'|'_'|'`'|'a'|'b'|'c'|'d'|'e'|'f'|'g'|'h'|'i'|'j'|'k'|'l'|'m'|'n'|'o'|'p'|'q'|'r'|'s'|'t'|'u'|'v'|'w'|'y'|'z'|'|'|'~' *)
                              |33|35|36|37|38|39|42|43|45|46|47|48|49|50|51|52|53|54|55|56|57|58|60|61|62|63|64|65|66|67|68|69|70|71|72|73|74|75|76|77|78|79|80|81|82|83|84|85|86|87|88|89|90|92|94|95|96|97|98|99|100|101|102|103|104|105|106|107|108|109|110|111|112|113|114|115|116|117|118|119|121|122|124|126 ->
                                __ocaml_lex_state11 lexbuf 20 (* = last_action *) _buf _len _curr _last
                              | _ ->
                                let _curr = _last in
                                lexbuf.Lexing.lex_curr_pos <- _curr;
                                lexbuf.Lexing.lex_last_pos <- _last;
                                20 (* = last_action *)
                            end
                          | _ ->
                            let _curr = _last in
                            lexbuf.Lexing.lex_curr_pos <- _curr;
                            lexbuf.Lexing.lex_last_pos <- _last;
                            20 (* = last_action *)
                        end
                      (* |'"' *)
                      | 34 ->
                        __ocaml_lex_state29 lexbuf 4 (* = last_action *) _buf _len _curr _last
                      (* |'!'|'#'|'$'|'%'|'&'|'\''|'*'|'+'|'-'|'.'|'/'|'0'|'1'|'2'|'3'|'4'|'5'|'6'|'7'|'8'|'9'|'<'|'='|'>'|'?'|'@'|'A'|'B'|'C'|'D'|'E'|'F'|'G'|'H'|'I'|'J'|'K'|'L'|'M'|'N'|'O'|'P'|'Q'|'R'|'S'|'T'|'U'|'V'|'W'|'X'|'Y'|'Z'|'\\'|'^'|'_'|'`'|'a'|'b'|'c'|'d'|'e'|'f'|'g'|'h'|'i'|'j'|'k'|'l'|'m'|'n'|'o'|'p'|'q'|'r'|'s'|'t'|'u'|'v'|'w'|'x'|'y'|'z'|'|'|'~' *)
                      |33|35|36|37|38|39|42|43|45|46|47|48|49|50|51|52|53|54|55|56|57|60|61|62|63|64|65|66|67|68|69|70|71|72|73|74|75|76|77|78|79|80|81|82|83|84|85|86|87|88|89|90|92|94|95|96|97|98|99|100|101|102|103|104|105|106|107|108|109|110|111|112|113|114|115|116|117|118|119|120|121|122|124|126 ->
                        __ocaml_lex_state11 lexbuf 4 (* = last_action *) _buf _len _curr _last
                      | _ ->
                        let _curr = _last in
                        lexbuf.Lexing.lex_curr_pos <- _curr;
                        lexbuf.Lexing.lex_last_pos <- _last;
                        4 (* = last_action *)
                    end
                  | _ ->
                    let _curr = _last in
                    lexbuf.Lexing.lex_curr_pos <- _curr;
                    lexbuf.Lexing.lex_last_pos <- _last;
                    20 (* = last_action *)
                end
              (* |'!'|'#'|'$'|'%'|'&'|'\''|'*'|'+'|'-'|'.'|'/'|'0'|'1'|'2'|'3'|'4'|'5'|'6'|'7'|'8'|'9'|':'|'<'|'='|'>'|'?'|'@'|'A'|'B'|'C'|'D'|'E'|'F'|'G'|'H'|'I'|'J'|'K'|'L'|'M'|'N'|'O'|'P'|'Q'|'R'|'S'|'T'|'U'|'V'|'W'|'X'|'Y'|'Z'|'\\'|'^'|'_'|'`'|'b'|'c'|'d'|'e'|'f'|'g'|'h'|'i'|'j'|'k'|'l'|'m'|'n'|'o'|'p'|'q'|'r'|'s'|'t'|'u'|'v'|'w'|'x'|'y'|'z'|'|'|'~' *)
              |33|35|36|37|38|39|42|43|45|46|47|48|49|50|51|52|53|54|55|56|57|58|60|61|62|63|64|65|66|67|68|69|70|71|72|73|74|75|76|77|78|79|80|81|82|83|84|85|86|87|88|89|90|92|94|95|96|98|99|100|101|102|103|104|105|106|107|108|109|110|111|112|113|114|115|116|117|118|119|120|121|122|124|126 ->
                __ocaml_lex_state11 lexbuf 20 (* = last_action *) _buf _len _curr _last
              | _ ->
                let _curr = _last in
                lexbuf.Lexing.lex_curr_pos <- _curr;
                lexbuf.Lexing.lex_last_pos <- _last;
                20 (* = last_action *)
            end
          (* |'i' *)
          | 105 ->
            (* *)
            let _last = _curr in
            (* let _last_action = 20 in*)
            let next_char, _buf, _len, _curr, _last =
              if _curr >= _len then
                __ocaml_lex_refill_buf lexbuf _buf _len _curr _last
              else
                Char.code (Bytes.unsafe_get _buf _curr),
                _buf, _len, (_curr + 1), _last
            in
            begin match next_char with
              (* |'"' *)
              | 34 ->
                __ocaml_lex_state29 lexbuf 20 (* = last_action *) _buf _len _curr _last
              (* |'!'|'#'|'$'|'%'|'&'|'\''|'*'|'+'|'-'|'.'|'/'|'0'|'1'|'2'|'3'|'4'|'5'|'6'|'7'|'8'|'9'|':'|'<'|'='|'>'|'?'|'@'|'A'|'B'|'C'|'D'|'E'|'F'|'G'|'H'|'I'|'J'|'K'|'L'|'M'|'N'|'O'|'P'|'Q'|'R'|'S'|'T'|'U'|'V'|'W'|'X'|'Y'|'Z'|'\\'|'^'|'_'|'`'|'a'|'b'|'c'|'d'|'e'|'f'|'g'|'h'|'i'|'j'|'k'|'l'|'m'|'o'|'p'|'q'|'r'|'s'|'t'|'u'|'v'|'w'|'x'|'y'|'z'|'|'|'~' *)
              |33|35|36|37|38|39|42|43|45|46|47|48|49|50|51|52|53|54|55|56|57|58|60|61|62|63|64|65|66|67|68|69|70|71|72|73|74|75|76|77|78|79|80|81|82|83|84|85|86|87|88|89|90|92|94|95|96|97|98|99|100|101|102|103|104|105|106|107|108|109|111|112|113|114|115|116|117|118|119|120|121|122|124|126 ->
                __ocaml_lex_state11 lexbuf 20 (* = last_action *) _buf _len _curr _last
              (* |'n' *)
              | 110 ->
                (* *)
                let _last = _curr in
                (* let _last_action = 20 in*)
                let next_char, _buf, _len, _curr, _last =
                  if _curr >= _len then
                    __ocaml_lex_refill_buf lexbuf _buf _len _curr _last
                  else
                    Char.code (Bytes.unsafe_get _buf _curr),
                    _buf, _len, (_curr + 1), _last
                in
                begin match next_char with
                  (* |'f' *)
                  | 102 ->
                    (* *)
                    let _last = _curr in
                    let _last_action = 4 in
                    let next_char, _buf, _len, _curr, _last =
                      if _curr >= _len then
                        __ocaml_lex_refill_buf lexbuf _buf _len _curr _last
                      else
                        Char.code (Bytes.unsafe_get _buf _curr),
                        _buf, _len, (_curr + 1), _last
                    in
                    begin match next_char with
                      (* |'"' *)
                      | 34 ->
                        __ocaml_lex_state29 lexbuf 4 (* = last_action *) _buf _len _curr _last
                      (* |'!'|'#'|'$'|'%'|'&'|'\''|'*'|'+'|'-'|'.'|'/'|'0'|'1'|'2'|'3'|'4'|'5'|'6'|'7'|'8'|'9'|':'|'<'|'='|'>'|'?'|'@'|'A'|'B'|'C'|'D'|'E'|'F'|'G'|'H'|'I'|'J'|'K'|'L'|'M'|'N'|'O'|'P'|'Q'|'R'|'S'|'T'|'U'|'V'|'W'|'X'|'Y'|'Z'|'\\'|'^'|'_'|'`'|'a'|'b'|'c'|'d'|'e'|'f'|'g'|'h'|'i'|'j'|'k'|'l'|'m'|'n'|'o'|'p'|'q'|'r'|'s'|'t'|'u'|'v'|'w'|'x'|'y'|'z'|'|'|'~' *)
                      |33|35|36|37|38|39|42|43|45|46|47|48|49|50|51|52|53|54|55|56|57|58|60|61|62|63|64|65|66|67|68|69|70|71|72|73|74|75|76|77|78|79|80|81|82|83|84|85|86|87|88|89|90|92|94|95|96|97|98|99|100|101|102|103|104|105|106|107|108|109|110|111|112|113|114|115|116|117|118|119|120|121|122|124|126 ->
                        __ocaml_lex_state11 lexbuf 4 (* = last_action *) _buf _len _curr _last
                      | _ ->
                        let _curr = _last in
                        lexbuf.Lexing.lex_curr_pos <- _curr;
                        lexbuf.Lexing.lex_last_pos <- _last;
                        4 (* = last_action *)
                    end
                  (* |'"' *)
                  | 34 ->
                    __ocaml_lex_state29 lexbuf 20 (* = last_action *) _buf _len _curr _last
                  (* |'!'|'#'|'$'|'%'|'&'|'\''|'*'|'+'|'-'|'.'|'/'|'0'|'1'|'2'|'3'|'4'|'5'|'6'|'7'|'8'|'9'|':'|'<'|'='|'>'|'?'|'@'|'A'|'B'|'C'|'D'|'E'|'F'|'G'|'H'|'I'|'J'|'K'|'L'|'M'|'N'|'O'|'P'|'Q'|'R'|'S'|'T'|'U'|'V'|'W'|'X'|'Y'|'Z'|'\\'|'^'|'_'|'`'|'a'|'b'|'c'|'d'|'e'|'g'|'h'|'i'|'j'|'k'|'l'|'m'|'n'|'o'|'p'|'q'|'r'|'s'|'t'|'u'|'v'|'w'|'x'|'y'|'z'|'|'|'~' *)
                  |33|35|36|37|38|39|42|43|45|46|47|48|49|50|51|52|53|54|55|56|57|58|60|61|62|63|64|65|66|67|68|69|70|71|72|73|74|75|76|77|78|79|80|81|82|83|84|85|86|87|88|89|90|92|94|95|96|97|98|99|100|101|103|104|105|106|107|108|109|110|111|112|113|114|115|116|117|118|119|120|121|122|124|126 ->
                    __ocaml_lex_state11 lexbuf 20 (* = last_action *) _buf _len _curr _last
                  | _ ->
                    let _curr = _last in
                    lexbuf.Lexing.lex_curr_pos <- _curr;
                    lexbuf.Lexing.lex_last_pos <- _last;
                    20 (* = last_action *)
                end
              | _ ->
                let _curr = _last in
                lexbuf.Lexing.lex_curr_pos <- _curr;
                lexbuf.Lexing.lex_last_pos <- _last;
                20 (* = last_action *)
            end
          (* |'"' *)
          | 34 ->
            __ocaml_lex_state29 lexbuf 20 (* = last_action *) _buf _len _curr _last
          (* |'!'|'#'|'$'|'%'|'&'|'\''|'*'|'+'|'-'|'.'|'/'|':'|'<'|'='|'>'|'?'|'@'|'A'|'B'|'C'|'D'|'E'|'F'|'G'|'H'|'I'|'J'|'K'|'L'|'M'|'N'|'O'|'P'|'Q'|'R'|'S'|'T'|'U'|'V'|'W'|'X'|'Y'|'Z'|'\\'|'^'|'_'|'`'|'a'|'b'|'c'|'d'|'e'|'f'|'g'|'h'|'j'|'k'|'l'|'m'|'o'|'p'|'q'|'r'|'s'|'t'|'u'|'v'|'w'|'x'|'y'|'z'|'|'|'~' *)
          |33|35|36|37|38|39|42|43|45|46|47|58|60|61|62|63|64|65|66|67|68|69|70|71|72|73|74|75|76|77|78|79|80|81|82|83|84|85|86|87|88|89|90|92|94|95|96|97|98|99|100|101|102|103|104|106|107|108|109|111|112|113|114|115|116|117|118|119|120|121|122|124|126 ->
            __ocaml_lex_state11 lexbuf 20 (* = last_action *) _buf _len _curr _last
          (* |'0' *)
          | 48 ->
            (* *)
            let _last = _curr in
            let _last_action = 3 in
            let next_char, _buf, _len, _curr, _last =
              if _curr >= _len then
                __ocaml_lex_refill_buf lexbuf _buf _len _curr _last
              else
                Char.code (Bytes.unsafe_get _buf _curr),
                _buf, _len, (_curr + 1), _last
            in
            begin match next_char with
              (* |'0'|'1'|'2'|'3'|'4'|'5'|'6'|'7'|'8'|'9' *)
              |48|49|50|51|52|53|54|55|56|57 ->
                __ocaml_lex_state72 lexbuf 3 (* = last_action *) _buf _len _curr _last
              (* |'E'|'e' *)
              |69|101 ->
                __ocaml_lex_state30 lexbuf 3 (* = last_action *) _buf _len _curr _last
              (* |'x' *)
              | 120 ->
                (* *)
                let _last = _curr in
                let _last_action = 20 in
                let next_char, _buf, _len, _curr, _last =
                  if _curr >= _len then
                    __ocaml_lex_refill_buf lexbuf _buf _len _curr _last
                  else
                    Char.code (Bytes.unsafe_get _buf _curr),
                    _buf, _len, (_curr + 1), _last
                in
                begin match next_char with
                  (* |'0'|'1'|'2'|'3'|'4'|'5'|'6'|'7'|'8'|'9'|'A'|'B'|'C'|'D'|'E'|'F'|'a'|'b'|'c'|'d'|'e'|'f' *)
                  |48|49|50|51|52|53|54|55|56|57|65|66|67|68|69|70|97|98|99|100|101|102 ->
                    __ocaml_lex_state76 lexbuf 20 (* = last_action *) _buf _len _curr _last
                  (* |'"' *)
                  | 34 ->
                    __ocaml_lex_state29 lexbuf 20 (* = last_action *) _buf _len _curr _last
                  (* |'!'|'#'|'$'|'%'|'&'|'\''|'*'|'+'|'-'|'.'|'/'|':'|'<'|'='|'>'|'?'|'@'|'G'|'H'|'I'|'J'|'K'|'L'|'M'|'N'|'O'|'P'|'Q'|'R'|'S'|'T'|'U'|'V'|'W'|'X'|'Y'|'Z'|'\\'|'^'|'_'|'`'|'g'|'h'|'i'|'j'|'k'|'l'|'m'|'n'|'o'|'p'|'q'|'r'|'s'|'t'|'u'|'v'|'w'|'x'|'y'|'z'|'|'|'~' *)
                  |33|35|36|37|38|39|42|43|45|46|47|58|60|61|62|63|64|71|72|73|74|75|76|77|78|79|80|81|82|83|84|85|86|87|88|89|90|92|94|95|96|103|104|105|106|107|108|109|110|111|112|113|114|115|116|117|118|119|120|121|122|124|126 ->
                    __ocaml_lex_state11 lexbuf 20 (* = last_action *) _buf _len _curr _last
                  | _ ->
                    let _curr = _last in
                    lexbuf.Lexing.lex_curr_pos <- _curr;
                    lexbuf.Lexing.lex_last_pos <- _last;
                    20 (* = last_action *)
                end
              (* |'.' *)
              | 46 ->
                __ocaml_lex_state31 lexbuf 3 (* = last_action *) _buf _len _curr _last
              (* |'"' *)
              | 34 ->
                __ocaml_lex_state29 lexbuf 3 (* = last_action *) _buf _len _curr _last
              (* |'_' *)
              | 95 ->
                __ocaml_lex_state75 lexbuf 3 (* = last_action *) _buf _len _curr _last
              (* |'!'|'#'|'$'|'%'|'&'|'\''|'*'|'+'|'-'|'/'|':'|'<'|'='|'>'|'?'|'@'|'A'|'B'|'C'|'D'|'F'|'G'|'H'|'I'|'J'|'K'|'L'|'M'|'N'|'O'|'P'|'Q'|'R'|'S'|'T'|'U'|'V'|'W'|'X'|'Y'|'Z'|'\\'|'^'|'`'|'a'|'b'|'c'|'d'|'f'|'g'|'h'|'i'|'j'|'k'|'l'|'m'|'n'|'o'|'p'|'q'|'r'|'s'|'t'|'u'|'v'|'w'|'y'|'z'|'|'|'~' *)
              |33|35|36|37|38|39|42|43|45|47|58|60|61|62|63|64|65|66|67|68|70|71|72|73|74|75|76|77|78|79|80|81|82|83|84|85|86|87|88|89|90|92|94|96|97|98|99|100|102|103|104|105|106|107|108|109|110|111|112|113|114|115|116|117|118|119|121|122|124|126 ->
                __ocaml_lex_state11 lexbuf 3 (* = last_action *) _buf _len _curr _last
              | _ ->
                let _curr = _last in
                lexbuf.Lexing.lex_curr_pos <- _curr;
                lexbuf.Lexing.lex_last_pos <- _last;
                3 (* = last_action *)
            end
          | _ ->
            let _curr = _last in
            lexbuf.Lexing.lex_curr_pos <- _curr;
            lexbuf.Lexing.lex_last_pos <- _last;
            20 (* = last_action *)
        end
      (* |'\194'|'\195'|'\196'|'\197'|'\198'|'\199'|'\200'|'\201'|'\202'|'\203'|'\204'|'\205'|'\206'|'\207'|'\208'|'\209'|'\210'|'\211'|'\212'|'\213'|'\214'|'\215'|'\216'|'\217'|'\218'|'\219'|'\220'|'\221'|'\222'|'\223' *)
      |194|195|196|197|198|199|200|201|202|203|204|205|206|207|208|209|210|211|212|213|214|215|216|217|218|219|220|221|222|223 ->
        (* *)
        let _last = _curr in
        let _last_action = 23 in
        let next_char, _buf, _len, _curr, _last =
          if _curr >= _len then
            __ocaml_lex_refill_buf lexbuf _buf _len _curr _last
          else
            Char.code (Bytes.unsafe_get _buf _curr),
            _buf, _len, (_curr + 1), _last
        in
        begin match next_char with
          (* |'\128'|'\129'|'\130'|'\131'|'\132'|'\133'|'\134'|'\135'|'\136'|'\137'|'\138'|'\139'|'\140'|'\141'|'\142'|'\143'|'\144'|'\145'|'\146'|'\147'|'\148'|'\149'|'\150'|'\151'|'\152'|'\153'|'\154'|'\155'|'\156'|'\157'|'\158'|'\159'|'\160'|'\161'|'\162'|'\163'|'\164'|'\165'|'\166'|'\167'|'\168'|'\169'|'\170'|'\171'|'\172'|'\173'|'\174'|'\175'|'\176'|'\177'|'\178'|'\179'|'\180'|'\181'|'\182'|'\183'|'\184'|'\185'|'\186'|'\187'|'\188'|'\189'|'\190'|'\191' *)
          |128|129|130|131|132|133|134|135|136|137|138|139|140|141|142|143|144|145|146|147|148|149|150|151|152|153|154|155|156|157|158|159|160|161|162|163|164|165|166|167|168|169|170|171|172|173|174|175|176|177|178|179|180|181|182|183|184|185|186|187|188|189|190|191 ->
            (* *)
            lexbuf.Lexing.lex_curr_pos <- _curr;
            lexbuf.Lexing.lex_last_pos <- _last;
            22
          | _ ->
            let _curr = _last in
            lexbuf.Lexing.lex_curr_pos <- _curr;
            lexbuf.Lexing.lex_last_pos <- _last;
            23 (* = last_action *)
        end
      (* |';' *)
      | 59 ->
        (* *)
        let _last = _curr in
        let _last_action = 20 in
        let next_char, _buf, _len, _curr, _last =
          if _curr >= _len then
            __ocaml_lex_refill_buf lexbuf _buf _len _curr _last
          else
            Char.code (Bytes.unsafe_get _buf _curr),
            _buf, _len, (_curr + 1), _last
        in
        begin match next_char with
          (* |';' *)
          | 59 ->
            __ocaml_lex_state149 lexbuf 20 (* = last_action *) _buf _len _curr _last
          | _ ->
            let _curr = _last in
            lexbuf.Lexing.lex_curr_pos <- _curr;
            lexbuf.Lexing.lex_last_pos <- _last;
            20 (* = last_action *)
        end
      (* |'\240' *)
      | 240 ->
        (* *)
        let _last = _curr in
        let _last_action = 23 in
        let next_char, _buf, _len, _curr, _last =
          if _curr >= _len then
            __ocaml_lex_refill_buf lexbuf _buf _len _curr _last
          else
            Char.code (Bytes.unsafe_get _buf _curr),
            _buf, _len, (_curr + 1), _last
        in
        begin match next_char with
          (* |'\144'|'\145'|'\146'|'\147'|'\148'|'\149'|'\150'|'\151'|'\152'|'\153'|'\154'|'\155'|'\156'|'\157'|'\158'|'\159'|'\160'|'\161'|'\162'|'\163'|'\164'|'\165'|'\166'|'\167'|'\168'|'\169'|'\170'|'\171'|'\172'|'\173'|'\174'|'\175'|'\176'|'\177'|'\178'|'\179'|'\180'|'\181'|'\182'|'\183'|'\184'|'\185'|'\186'|'\187'|'\188'|'\189'|'\190'|'\191' *)
          |144|145|146|147|148|149|150|151|152|153|154|155|156|157|158|159|160|161|162|163|164|165|166|167|168|169|170|171|172|173|174|175|176|177|178|179|180|181|182|183|184|185|186|187|188|189|190|191 ->
            let next_char, _buf, _len, _curr, _last =
              if _curr >= _len then
                __ocaml_lex_refill_buf lexbuf _buf _len _curr _last
              else
                Char.code (Bytes.unsafe_get _buf _curr),
                _buf, _len, (_curr + 1), _last
            in
            begin match next_char with
              (* |'\128'|'\129'|'\130'|'\131'|'\132'|'\133'|'\134'|'\135'|'\136'|'\137'|'\138'|'\139'|'\140'|'\141'|'\142'|'\143'|'\144'|'\145'|'\146'|'\147'|'\148'|'\149'|'\150'|'\151'|'\152'|'\153'|'\154'|'\155'|'\156'|'\157'|'\158'|'\159'|'\160'|'\161'|'\162'|'\163'|'\164'|'\165'|'\166'|'\167'|'\168'|'\169'|'\170'|'\171'|'\172'|'\173'|'\174'|'\175'|'\176'|'\177'|'\178'|'\179'|'\180'|'\181'|'\182'|'\183'|'\184'|'\185'|'\186'|'\187'|'\188'|'\189'|'\190'|'\191' *)
              |128|129|130|131|132|133|134|135|136|137|138|139|140|141|142|143|144|145|146|147|148|149|150|151|152|153|154|155|156|157|158|159|160|161|162|163|164|165|166|167|168|169|170|171|172|173|174|175|176|177|178|179|180|181|182|183|184|185|186|187|188|189|190|191 ->
                let next_char, _buf, _len, _curr, _last =
                  if _curr >= _len then
                    __ocaml_lex_refill_buf lexbuf _buf _len _curr _last
                  else
                    Char.code (Bytes.unsafe_get _buf _curr),
                    _buf, _len, (_curr + 1), _last
                in
                begin match next_char with
                  (* |'\128'|'\129'|'\130'|'\131'|'\132'|'\133'|'\134'|'\135'|'\136'|'\137'|'\138'|'\139'|'\140'|'\141'|'\142'|'\143'|'\144'|'\145'|'\146'|'\147'|'\148'|'\149'|'\150'|'\151'|'\152'|'\153'|'\154'|'\155'|'\156'|'\157'|'\158'|'\159'|'\160'|'\161'|'\162'|'\163'|'\164'|'\165'|'\166'|'\167'|'\168'|'\169'|'\170'|'\171'|'\172'|'\173'|'\174'|'\175'|'\176'|'\177'|'\178'|'\179'|'\180'|'\181'|'\182'|'\183'|'\184'|'\185'|'\186'|'\187'|'\188'|'\189'|'\190'|'\191' *)
                  |128|129|130|131|132|133|134|135|136|137|138|139|140|141|142|143|144|145|146|147|148|149|150|151|152|153|154|155|156|157|158|159|160|161|162|163|164|165|166|167|168|169|170|171|172|173|174|175|176|177|178|179|180|181|182|183|184|185|186|187|188|189|190|191 ->
                    (* *)
                    lexbuf.Lexing.lex_curr_pos <- _curr;
                    lexbuf.Lexing.lex_last_pos <- _last;
                    22
                  | _ ->
                    let _curr = _last in
                    lexbuf.Lexing.lex_curr_pos <- _curr;
                    lexbuf.Lexing.lex_last_pos <- _last;
                    23 (* = last_action *)
                end
              | _ ->
                let _curr = _last in
                lexbuf.Lexing.lex_curr_pos <- _curr;
                lexbuf.Lexing.lex_last_pos <- _last;
                23 (* = last_action *)
            end
          | _ ->
            let _curr = _last in
            lexbuf.Lexing.lex_curr_pos <- _curr;
            lexbuf.Lexing.lex_last_pos <- _last;
            23 (* = last_action *)
        end
      (* |'\000'|'\001'|'\002'|'\003'|'\004'|'\005'|'\006'|'\007'|'\b'|'\011'|'\012'|'\014'|'\015'|'\016'|'\017'|'\018'|'\019'|'\020'|'\021'|'\022'|'\023'|'\024'|'\025'|'\026'|'\027'|'\028'|'\029'|'\030'|'\031' *)
      |0|1|2|3|4|5|6|7|8|11|12|14|15|16|17|18|19|20|21|22|23|24|25|26|27|28|29|30|31 ->
        (* *)
        lexbuf.Lexing.lex_curr_pos <- _curr;
        lexbuf.Lexing.lex_last_pos <- _last;
        21
      (* |'i' *)
      | 105 ->
        (* *)
        let _last = _curr in
        let _last_action = 20 in
        let next_char, _buf, _len, _curr, _last =
          if _curr >= _len then
            __ocaml_lex_refill_buf lexbuf _buf _len _curr _last
          else
            Char.code (Bytes.unsafe_get _buf _curr),
            _buf, _len, (_curr + 1), _last
        in
        begin match next_char with
          (* |'n' *)
          | 110 ->
            (* *)
            let _last = _curr in
            let _last_action = 9 in
            let next_char, _buf, _len, _curr, _last =
              if _curr >= _len then
                __ocaml_lex_refill_buf lexbuf _buf _len _curr _last
              else
                Char.code (Bytes.unsafe_get _buf _curr),
                _buf, _len, (_curr + 1), _last
            in
            begin match next_char with
              (* |'f' *)
              | 102 ->
                (* *)
                let _last = _curr in
                let _last_action = 4 in
                let next_char, _buf, _len, _curr, _last =
                  if _curr >= _len then
                    __ocaml_lex_refill_buf lexbuf _buf _len _curr _last
                  else
                    Char.code (Bytes.unsafe_get _buf _curr),
                    _buf, _len, (_curr + 1), _last
                in
                begin match next_char with
                  (* |'"' *)
                  | 34 ->
                    __ocaml_lex_state29 lexbuf 4 (* = last_action *) _buf _len _curr _last
                  (* |'.'|'0'|'1'|'2'|'3'|'4'|'5'|'6'|'7'|'8'|'9'|':'|'A'|'B'|'C'|'D'|'E'|'F'|'G'|'H'|'I'|'J'|'K'|'L'|'M'|'N'|'O'|'P'|'Q'|'R'|'S'|'T'|'U'|'V'|'W'|'X'|'Y'|'Z'|'_'|'a'|'b'|'c'|'d'|'e'|'f'|'g'|'h'|'i'|'j'|'k'|'l'|'m'|'n'|'o'|'p'|'q'|'r'|'s'|'t'|'u'|'v'|'w'|'x'|'y'|'z' *)
                  |46|48|49|50|51|52|53|54|55|56|57|58|65|66|67|68|69|70|71|72|73|74|75|76|77|78|79|80|81|82|83|84|85|86|87|88|89|90|95|97|98|99|100|101|102|103|104|105|106|107|108|109|110|111|112|113|114|115|116|117|118|119|120|121|122 ->
                    __ocaml_lex_state87 lexbuf 4 (* = last_action *) _buf _len _curr _last
                  (* |'!'|'#'|'$'|'%'|'&'|'\''|'*'|'+'|'-'|'/'|'<'|'='|'>'|'?'|'@'|'\\'|'^'|'`'|'|'|'~' *)
                  |33|35|36|37|38|39|42|43|45|47|60|61|62|63|64|92|94|96|124|126 ->
                    __ocaml_lex_state11 lexbuf 4 (* = last_action *) _buf _len _curr _last
                  | _ ->
                    let _curr = _last in
                    lexbuf.Lexing.lex_curr_pos <- _curr;
                    lexbuf.Lexing.lex_last_pos <- _last;
                    4 (* = last_action *)
                end
              (* |'"' *)
              | 34 ->
                __ocaml_lex_state29 lexbuf 9 (* = last_action *) _buf _len _curr _last
              (* |'.'|'0'|'1'|'2'|'3'|'4'|'5'|'6'|'7'|'8'|'9'|':'|'A'|'B'|'C'|'D'|'E'|'F'|'G'|'H'|'I'|'J'|'K'|'L'|'M'|'N'|'O'|'P'|'Q'|'R'|'S'|'T'|'U'|'V'|'W'|'X'|'Y'|'Z'|'_'|'a'|'b'|'c'|'d'|'e'|'g'|'h'|'i'|'j'|'k'|'l'|'m'|'n'|'o'|'p'|'q'|'r'|'s'|'t'|'u'|'v'|'w'|'x'|'y'|'z' *)
              |46|48|49|50|51|52|53|54|55|56|57|58|65|66|67|68|69|70|71|72|73|74|75|76|77|78|79|80|81|82|83|84|85|86|87|88|89|90|95|97|98|99|100|101|103|104|105|106|107|108|109|110|111|112|113|114|115|116|117|118|119|120|121|122 ->
                __ocaml_lex_state87 lexbuf 9 (* = last_action *) _buf _len _curr _last
              (* |'!'|'#'|'$'|'%'|'&'|'\''|'*'|'+'|'-'|'/'|'<'|'='|'>'|'?'|'@'|'\\'|'^'|'`'|'|'|'~' *)
              |33|35|36|37|38|39|42|43|45|47|60|61|62|63|64|92|94|96|124|126 ->
                __ocaml_lex_state11 lexbuf 9 (* = last_action *) _buf _len _curr _last
              | _ ->
                let _curr = _last in
                lexbuf.Lexing.lex_curr_pos <- _curr;
                lexbuf.Lexing.lex_last_pos <- _last;
                9 (* = last_action *)
            end
          (* |'"' *)
          | 34 ->
            __ocaml_lex_state29 lexbuf 20 (* = last_action *) _buf _len _curr _last
          (* |'.'|'0'|'1'|'2'|'3'|'4'|'5'|'6'|'7'|'8'|'9'|':'|'A'|'B'|'C'|'D'|'E'|'F'|'G'|'H'|'I'|'J'|'K'|'L'|'M'|'N'|'O'|'P'|'Q'|'R'|'S'|'T'|'U'|'V'|'W'|'X'|'Y'|'Z'|'_'|'a'|'b'|'c'|'d'|'e'|'f'|'g'|'h'|'i'|'j'|'k'|'l'|'m'|'o'|'p'|'q'|'r'|'s'|'t'|'u'|'v'|'w'|'x'|'y'|'z' *)
          |46|48|49|50|51|52|53|54|55|56|57|58|65|66|67|68|69|70|71|72|73|74|75|76|77|78|79|80|81|82|83|84|85|86|87|88|89|90|95|97|98|99|100|101|102|103|104|105|106|107|108|109|111|112|113|114|115|116|117|118|119|120|121|122 ->
            __ocaml_lex_state87 lexbuf 20 (* = last_action *) _buf _len _curr _last
          (* |'!'|'#'|'$'|'%'|'&'|'\''|'*'|'+'|'-'|'/'|'<'|'='|'>'|'?'|'@'|'\\'|'^'|'`'|'|'|'~' *)
          |33|35|36|37|38|39|42|43|45|47|60|61|62|63|64|92|94|96|124|126 ->
            __ocaml_lex_state11 lexbuf 20 (* = last_action *) _buf _len _curr _last
          | _ ->
            let _curr = _last in
            lexbuf.Lexing.lex_curr_pos <- _curr;
            lexbuf.Lexing.lex_last_pos <- _last;
            20 (* = last_action *)
        end
      (* |'!'|'#'|'%'|'&'|'\''|'*'|'.'|'/'|':'|'<'|'='|'>'|'?'|'@'|'A'|'B'|'C'|'D'|'E'|'F'|'G'|'H'|'I'|'J'|'K'|'L'|'M'|'N'|'O'|'P'|'Q'|'R'|'S'|'T'|'U'|'V'|'W'|'X'|'Y'|'Z'|'\\'|'^'|'_'|'`'|'|'|'~' *)
      |33|35|37|38|39|42|46|47|58|60|61|62|63|64|65|66|67|68|69|70|71|72|73|74|75|76|77|78|79|80|81|82|83|84|85|86|87|88|89|90|92|94|95|96|124|126 ->
        __ocaml_lex_state11 lexbuf _last_action _buf _len _curr _last
      (* |')' *)
      | 41 ->
        (* *)
        lexbuf.Lexing.lex_curr_pos <- _curr;
        lexbuf.Lexing.lex_last_pos <- _last;
        1
      (* |'\n' *)
      | 10 ->
        (* *)
        lexbuf.Lexing.lex_curr_pos <- _curr;
        lexbuf.Lexing.lex_last_pos <- _last;
        18
      (* |'"' *)
      | 34 ->
        (* *)
        let _last = _curr in
        let _last_action = 23 in
        let next_char, _buf, _len, _curr, _last =
          if _curr >= _len then
            __ocaml_lex_refill_buf lexbuf _buf _len _curr _last
          else
            Char.code (Bytes.unsafe_get _buf _curr),
            _buf, _len, (_curr + 1), _last
        in
        begin match next_char with
          (* |'\224' *)
          | 224 ->
            __ocaml_lex_state106 lexbuf 23 (* = last_action *) _buf _len _curr _last
          (* |'\128'|'\129'|'\130'|'\131'|'\132'|'\133'|'\134'|'\135'|'\136'|'\137'|'\138'|'\139'|'\140'|'\141'|'\142'|'\143'|'\144'|'\145'|'\146'|'\147'|'\148'|'\149'|'\150'|'\151'|'\152'|'\153'|'\154'|'\155'|'\156'|'\157'|'\158'|'\159'|'\160'|'\161'|'\162'|'\163'|'\164'|'\165'|'\166'|'\167'|'\168'|'\169'|'\170'|'\171'|'\172'|'\173'|'\174'|'\175'|'\176'|'\177'|'\178'|'\179'|'\180'|'\181'|'\182'|'\183'|'\184'|'\185'|'\186'|'\187'|'\188'|'\189'|'\190'|'\191'|'\192'|'\193'|'\245'|'\246'|'\247'|'\248'|'\249'|'\250'|'\251'|'\252'|'\253'|'\254'|'\255' *)
          |128|129|130|131|132|133|134|135|136|137|138|139|140|141|142|143|144|145|146|147|148|149|150|151|152|153|154|155|156|157|158|159|160|161|162|163|164|165|166|167|168|169|170|171|172|173|174|175|176|177|178|179|180|181|182|183|184|185|186|187|188|189|190|191|192|193|245|246|247|248|249|250|251|252|253|254|255 ->
            let _curr = _last in
            lexbuf.Lexing.lex_curr_pos <- _curr;
            lexbuf.Lexing.lex_last_pos <- _last;
            23 (* = last_action *)
          (* |'\n'|eof *)
          |10|256 ->
            (* *)
            lexbuf.Lexing.lex_curr_pos <- _curr;
            lexbuf.Lexing.lex_last_pos <- _last;
            6
          (* |'\240' *)
          | 240 ->
            __ocaml_lex_state103 lexbuf 23 (* = last_action *) _buf _len _curr _last
          (* |'\194'|'\195'|'\196'|'\197'|'\198'|'\199'|'\200'|'\201'|'\202'|'\203'|'\204'|'\205'|'\206'|'\207'|'\208'|'\209'|'\210'|'\211'|'\212'|'\213'|'\214'|'\215'|'\216'|'\217'|'\218'|'\219'|'\220'|'\221'|'\222'|'\223' *)
          |194|195|196|197|198|199|200|201|202|203|204|205|206|207|208|209|210|211|212|213|214|215|216|217|218|219|220|221|222|223 ->
            __ocaml_lex_state107 lexbuf 23 (* = last_action *) _buf _len _curr _last
          (* |'\\' *)
          | 92 ->
            __ocaml_lex_state100 lexbuf 23 (* = last_action *) _buf _len _curr _last
          (* |'\241'|'\242'|'\243' *)
          |241|242|243 ->
            __ocaml_lex_state101 lexbuf 23 (* = last_action *) _buf _len _curr _last
          (* |'\237' *)
          | 237 ->
            __ocaml_lex_state105 lexbuf 23 (* = last_action *) _buf _len _curr _last
          (* |'\225'|'\226'|'\227'|'\228'|'\229'|'\230'|'\231'|'\232'|'\233'|'\234'|'\235'|'\236'|'\238'|'\239' *)
          |225|226|227|228|229|230|231|232|233|234|235|236|238|239 ->
            __ocaml_lex_state104 lexbuf 23 (* = last_action *) _buf _len _curr _last
          (* |'\244' *)
          | 244 ->
            __ocaml_lex_state102 lexbuf 23 (* = last_action *) _buf _len _curr _last
          (* |'\000'|'\001'|'\002'|'\003'|'\004'|'\005'|'\006'|'\007'|'\b'|'\t'|'\011'|'\012'|'\r'|'\014'|'\015'|'\016'|'\017'|'\018'|'\019'|'\020'|'\021'|'\022'|'\023'|'\024'|'\025'|'\026'|'\027'|'\028'|'\029'|'\030'|'\031'|'\127' *)
          |0|1|2|3|4|5|6|7|8|9|11|12|13|14|15|16|17|18|19|20|21|22|23|24|25|26|27|28|29|30|31|127 ->
            (* *)
            lexbuf.Lexing.lex_curr_pos <- _curr;
            lexbuf.Lexing.lex_last_pos <- _last;
            7
          (* |'"' *)
          | 34 ->
            __ocaml_lex_state99 lexbuf 23 (* = last_action *) _buf _len _curr _last
          | _ ->
            __ocaml_lex_state108 lexbuf 23 (* = last_action *) _buf _len _curr _last
        end
      (* |'\244' *)
      | 244 ->
        (* *)
        let _last = _curr in
        let _last_action = 23 in
        let next_char, _buf, _len, _curr, _last =
          if _curr >= _len then
            __ocaml_lex_refill_buf lexbuf _buf _len _curr _last
          else
            Char.code (Bytes.unsafe_get _buf _curr),
            _buf, _len, (_curr + 1), _last
        in
        begin match next_char with
          (* |'\128'|'\129'|'\130'|'\131'|'\132'|'\133'|'\134'|'\135'|'\136'|'\137'|'\138'|'\139'|'\140'|'\141'|'\142'|'\143' *)
          |128|129|130|131|132|133|134|135|136|137|138|139|140|141|142|143 ->
            let next_char, _buf, _len, _curr, _last =
              if _curr >= _len then
                __ocaml_lex_refill_buf lexbuf _buf _len _curr _last
              else
                Char.code (Bytes.unsafe_get _buf _curr),
                _buf, _len, (_curr + 1), _last
            in
            begin match next_char with
              (* |'\128'|'\129'|'\130'|'\131'|'\132'|'\133'|'\134'|'\135'|'\136'|'\137'|'\138'|'\139'|'\140'|'\141'|'\142'|'\143'|'\144'|'\145'|'\146'|'\147'|'\148'|'\149'|'\150'|'\151'|'\152'|'\153'|'\154'|'\155'|'\156'|'\157'|'\158'|'\159'|'\160'|'\161'|'\162'|'\163'|'\164'|'\165'|'\166'|'\167'|'\168'|'\169'|'\170'|'\171'|'\172'|'\173'|'\174'|'\175'|'\176'|'\177'|'\178'|'\179'|'\180'|'\181'|'\182'|'\183'|'\184'|'\185'|'\186'|'\187'|'\188'|'\189'|'\190'|'\191' *)
              |128|129|130|131|132|133|134|135|136|137|138|139|140|141|142|143|144|145|146|147|148|149|150|151|152|153|154|155|156|157|158|159|160|161|162|163|164|165|166|167|168|169|170|171|172|173|174|175|176|177|178|179|180|181|182|183|184|185|186|187|188|189|190|191 ->
                let next_char, _buf, _len, _curr, _last =
                  if _curr >= _len then
                    __ocaml_lex_refill_buf lexbuf _buf _len _curr _last
                  else
                    Char.code (Bytes.unsafe_get _buf _curr),
                    _buf, _len, (_curr + 1), _last
                in
                begin match next_char with
                  (* |'\128'|'\129'|'\130'|'\131'|'\132'|'\133'|'\134'|'\135'|'\136'|'\137'|'\138'|'\139'|'\140'|'\141'|'\142'|'\143'|'\144'|'\145'|'\146'|'\147'|'\148'|'\149'|'\150'|'\151'|'\152'|'\153'|'\154'|'\155'|'\156'|'\157'|'\158'|'\159'|'\160'|'\161'|'\162'|'\163'|'\164'|'\165'|'\166'|'\167'|'\168'|'\169'|'\170'|'\171'|'\172'|'\173'|'\174'|'\175'|'\176'|'\177'|'\178'|'\179'|'\180'|'\181'|'\182'|'\183'|'\184'|'\185'|'\186'|'\187'|'\188'|'\189'|'\190'|'\191' *)
                  |128|129|130|131|132|133|134|135|136|137|138|139|140|141|142|143|144|145|146|147|148|149|150|151|152|153|154|155|156|157|158|159|160|161|162|163|164|165|166|167|168|169|170|171|172|173|174|175|176|177|178|179|180|181|182|183|184|185|186|187|188|189|190|191 ->
                    (* *)
                    lexbuf.Lexing.lex_curr_pos <- _curr;
                    lexbuf.Lexing.lex_last_pos <- _last;
                    22
                  | _ ->
                    let _curr = _last in
                    lexbuf.Lexing.lex_curr_pos <- _curr;
                    lexbuf.Lexing.lex_last_pos <- _last;
                    23 (* = last_action *)
                end
              | _ ->
                let _curr = _last in
                lexbuf.Lexing.lex_curr_pos <- _curr;
                lexbuf.Lexing.lex_last_pos <- _last;
                23 (* = last_action *)
            end
          | _ ->
            let _curr = _last in
            lexbuf.Lexing.lex_curr_pos <- _curr;
            lexbuf.Lexing.lex_last_pos <- _last;
            23 (* = last_action *)
        end
      (* |'\237' *)
      | 237 ->
        (* *)
        let _last = _curr in
        let _last_action = 23 in
        let next_char, _buf, _len, _curr, _last =
          if _curr >= _len then
            __ocaml_lex_refill_buf lexbuf _buf _len _curr _last
          else
            Char.code (Bytes.unsafe_get _buf _curr),
            _buf, _len, (_curr + 1), _last
        in
        begin match next_char with
          (* |'\128'|'\129'|'\130'|'\131'|'\132'|'\133'|'\134'|'\135'|'\136'|'\137'|'\138'|'\139'|'\140'|'\141'|'\142'|'\143'|'\144'|'\145'|'\146'|'\147'|'\148'|'\149'|'\150'|'\151'|'\152'|'\153'|'\154'|'\155'|'\156'|'\157'|'\158'|'\159' *)
          |128|129|130|131|132|133|134|135|136|137|138|139|140|141|142|143|144|145|146|147|148|149|150|151|152|153|154|155|156|157|158|159 ->
            let next_char, _buf, _len, _curr, _last =
              if _curr >= _len then
                __ocaml_lex_refill_buf lexbuf _buf _len _curr _last
              else
                Char.code (Bytes.unsafe_get _buf _curr),
                _buf, _len, (_curr + 1), _last
            in
            begin match next_char with
              (* |'\128'|'\129'|'\130'|'\131'|'\132'|'\133'|'\134'|'\135'|'\136'|'\137'|'\138'|'\139'|'\140'|'\141'|'\142'|'\143'|'\144'|'\145'|'\146'|'\147'|'\148'|'\149'|'\150'|'\151'|'\152'|'\153'|'\154'|'\155'|'\156'|'\157'|'\158'|'\159'|'\160'|'\161'|'\162'|'\163'|'\164'|'\165'|'\166'|'\167'|'\168'|'\169'|'\170'|'\171'|'\172'|'\173'|'\174'|'\175'|'\176'|'\177'|'\178'|'\179'|'\180'|'\181'|'\182'|'\183'|'\184'|'\185'|'\186'|'\187'|'\188'|'\189'|'\190'|'\191' *)
              |128|129|130|131|132|133|134|135|136|137|138|139|140|141|142|143|144|145|146|147|148|149|150|151|152|153|154|155|156|157|158|159|160|161|162|163|164|165|166|167|168|169|170|171|172|173|174|175|176|177|178|179|180|181|182|183|184|185|186|187|188|189|190|191 ->
                (* *)
                lexbuf.Lexing.lex_curr_pos <- _curr;
                lexbuf.Lexing.lex_last_pos <- _last;
                22
              | _ ->
                let _curr = _last in
                lexbuf.Lexing.lex_curr_pos <- _curr;
                lexbuf.Lexing.lex_last_pos <- _last;
                23 (* = last_action *)
            end
          | _ ->
            let _curr = _last in
            lexbuf.Lexing.lex_curr_pos <- _curr;
            lexbuf.Lexing.lex_last_pos <- _last;
            23 (* = last_action *)
        end
      | _ ->
        (* *)
        lexbuf.Lexing.lex_curr_pos <- _curr;
        lexbuf.Lexing.lex_last_pos <- _last;
        23
    end
  in
  begin
    let _curr_p = lexbuf.Lexing.lex_curr_p in
    if _curr_p != Lexing.dummy_pos then begin
      lexbuf.Lexing.lex_start_p <- _curr_p;
      lexbuf.Lexing.lex_curr_p <-
        {_curr_p with Lexing.pos_cnum =
         lexbuf.Lexing.lex_abs_pos+lexbuf.Lexing.lex_curr_pos}
    end
  end;
  match __ocaml_lex_result with
  | 0 ->
# 122 "text/lexer.mll"
        ( LPAR )
# 4108 "text/lexer.ml"

  | 1 ->
# 123 "text/lexer.mll"
        ( RPAR )
# 4113 "text/lexer.ml"

  | 2 ->
let
# 125 "text/lexer.mll"
           s
# 4119 "text/lexer.ml"
= Lexing.sub_lexeme lexbuf lexbuf.Lexing.lex_start_pos lexbuf.Lexing.lex_curr_pos in
# 125 "text/lexer.mll"
             ( NAT s )
# 4123 "text/lexer.ml"

  | 3 ->
let
# 126 "text/lexer.mll"
           s
# 4129 "text/lexer.ml"
= Lexing.sub_lexeme lexbuf lexbuf.Lexing.lex_start_pos lexbuf.Lexing.lex_curr_pos in
# 126 "text/lexer.mll"
             ( INT s )
# 4133 "text/lexer.ml"

  | 4 ->
let
# 127 "text/lexer.mll"
             s
# 4139 "text/lexer.ml"
= Lexing.sub_lexeme lexbuf lexbuf.Lexing.lex_start_pos lexbuf.Lexing.lex_curr_pos in
# 127 "text/lexer.mll"
               ( FLOAT s )
# 4143 "text/lexer.ml"

  | 5 ->
let
# 129 "text/lexer.mll"
              s
# 4149 "text/lexer.ml"
= Lexing.sub_lexeme lexbuf lexbuf.Lexing.lex_start_pos lexbuf.Lexing.lex_curr_pos in
# 129 "text/lexer.mll"
                ( STRING (string s) )
# 4153 "text/lexer.ml"

  | 6 ->
# 130 "text/lexer.mll"
                            ( error lexbuf "unclosed string literal" )
# 4158 "text/lexer.ml"

  | 7 ->
# 132 "text/lexer.mll"
    ( error lexbuf "illegal control character in string literal" )
# 4163 "text/lexer.ml"

  | 8 ->
# 134 "text/lexer.mll"
    ( error_nest (Lexing.lexeme_end_p lexbuf) lexbuf "illegal escape" )
# 4168 "text/lexer.ml"

  | 9 ->
let
# 136 "text/lexer.mll"
               s
# 4174 "text/lexer.ml"
= Lexing.sub_lexeme lexbuf lexbuf.Lexing.lex_start_pos lexbuf.Lexing.lex_curr_pos in
# 137 "text/lexer.mll"
    ( match s with
      | "i32" -> NUM_TYPE Types.I32Type
      | "i64" -> NUM_TYPE Types.I64Type
      | "f32" -> NUM_TYPE Types.F32Type
      | "f64" -> NUM_TYPE Types.F64Type
      | "v128" -> VEC_TYPE Types.V128Type
      | "i8x16" -> VEC_SHAPE (V128.I8x16 ())
      | "i16x8" -> VEC_SHAPE (V128.I16x8 ())
      | "i32x4" -> VEC_SHAPE (V128.I32x4 ())
      | "i64x2" -> VEC_SHAPE (V128.I64x2 ())
      | "f32x4" -> VEC_SHAPE (V128.F32x4 ())
      | "f64x2" -> VEC_SHAPE (V128.F64x2 ())

      | "extern" -> EXTERN
      | "externref" -> EXTERNREF
      | "funcref" -> FUNCREF
      | "mut" -> MUT

      | "nop" -> NOP
      | "unreachable" -> UNREACHABLE
      | "drop" -> DROP
      | "block" -> BLOCK
      | "loop" -> LOOP
      | "end" -> END
      | "br" -> BR
      | "br_if" -> BR_IF
      | "br_table" -> BR_TABLE
      | "return" -> RETURN
      | "if" -> IF
      | "then" -> THEN
      | "else" -> ELSE
      | "select" -> SELECT
      | "call" -> CALL
      | "call_indirect" -> CALL_INDIRECT

      | "local.get" -> LOCAL_GET
      | "local.set" -> LOCAL_SET
      | "local.tee" -> LOCAL_TEE
      | "global.get" -> GLOBAL_GET
      | "global.set" -> GLOBAL_SET

      | "table.get" -> TABLE_GET
      | "table.set" -> TABLE_SET
      | "table.size" -> TABLE_SIZE
      | "table.grow" -> TABLE_GROW
      | "table.fill" -> TABLE_FILL
      | "table.copy" -> TABLE_COPY
      | "table.init" -> TABLE_INIT
      | "elem.drop" -> ELEM_DROP

      | "memory.size" -> MEMORY_SIZE
      | "memory.grow" -> MEMORY_GROW
      | "memory.fill" -> MEMORY_FILL
      | "memory.copy" -> MEMORY_COPY
      | "memory.init" -> MEMORY_INIT
      | "data.drop" -> DATA_DROP

      | "i32.load" -> LOAD (fun a o -> i32_load (opt a 2) o)
      | "i64.load" -> LOAD (fun a o -> i64_load (opt a 3) o)
      | "f32.load" -> LOAD (fun a o -> f32_load (opt a 2) o)
      | "f64.load" -> LOAD (fun a o -> f64_load (opt a 3) o)
      | "i32.store" -> STORE (fun a o -> i32_store (opt a 2) o)
      | "i64.store" -> STORE (fun a o -> i64_store (opt a 3) o)
      | "f32.store" -> STORE (fun a o -> f32_store (opt a 2) o)
      | "f64.store" -> STORE (fun a o -> f64_store (opt a 3) o)

      | "i32.load8_u" -> LOAD (fun a o -> i32_load8_u (opt a 0) o)
      | "i32.load8_s" -> LOAD (fun a o -> i32_load8_s (opt a 0) o)
      | "i32.load16_u" -> LOAD (fun a o -> i32_load16_u (opt a 1) o)
      | "i32.load16_s" -> LOAD (fun a o -> i32_load16_s (opt a 1) o)
      | "i64.load8_u" -> LOAD (fun a o -> i64_load8_u (opt a 0) o)
      | "i64.load8_s" -> LOAD (fun a o -> i64_load8_s (opt a 0) o)
      | "i64.load16_u" -> LOAD (fun a o -> i64_load16_u (opt a 1) o)
      | "i64.load16_s" -> LOAD (fun a o -> i64_load16_s (opt a 1) o)
      | "i64.load32_u" -> LOAD (fun a o -> i64_load32_u (opt a 2) o)
      | "i64.load32_s" -> LOAD (fun a o -> i64_load32_s (opt a 2) o)

      | "i32.store8" -> LOAD (fun a o -> i32_store8 (opt a 0) o)
      | "i32.store16" -> LOAD (fun a o -> i32_store16 (opt a 1) o)
      | "i64.store8" -> LOAD (fun a o -> i64_store8 (opt a 0) o)
      | "i64.store16" -> LOAD (fun a o -> i64_store16 (opt a 1) o)
      | "i64.store32" -> LOAD (fun a o -> i64_store32 (opt a 2) o)

      | "v128.load" -> VEC_LOAD (fun a o -> v128_load (opt a 4) o)
      | "v128.store" -> VEC_STORE (fun a o -> v128_store (opt a 4) o)
      | "v128.load8x8_u" -> VEC_LOAD (fun a o -> v128_load8x8_u (opt a 3) o)
      | "v128.load8x8_s" -> VEC_LOAD (fun a o -> v128_load8x8_s (opt a 3) o)
      | "v128.load16x4_u" -> VEC_LOAD (fun a o -> v128_load16x4_u (opt a 3) o)
      | "v128.load16x4_s" -> VEC_LOAD (fun a o -> v128_load16x4_s (opt a 3) o)
      | "v128.load32x2_u" -> VEC_LOAD (fun a o -> v128_load32x2_u (opt a 3) o)
      | "v128.load32x2_s" -> VEC_LOAD (fun a o -> v128_load32x2_s (opt a 3) o)
      | "v128.load8_splat" ->
        VEC_LOAD (fun a o -> v128_load8_splat (opt a 0) o)
      | "v128.load16_splat" ->
        VEC_LOAD (fun a o -> v128_load16_splat (opt a 1) o)
      | "v128.load32_splat" ->
        VEC_LOAD (fun a o -> v128_load32_splat (opt a 2) o)
      | "v128.load64_splat" ->
        VEC_LOAD (fun a o -> v128_load64_splat (opt a 3) o)
      | "v128.load32_zero" ->
        VEC_LOAD (fun a o -> v128_load32_zero (opt a 2) o)
      | "v128.load64_zero" ->
        VEC_LOAD (fun a o -> v128_load64_zero (opt a 3) o)
      | "v128.load8_lane" ->
        VEC_LOAD_LANE (fun a o i -> v128_load8_lane (opt a 0) o i)
      | "v128.load16_lane" ->
        VEC_LOAD_LANE (fun a o i -> v128_load16_lane (opt a 1) o i)
      | "v128.load32_lane" ->
        VEC_LOAD_LANE (fun a o i -> v128_load32_lane (opt a 2) o i)
      | "v128.load64_lane" ->
        VEC_LOAD_LANE (fun a o i -> v128_load64_lane (opt a 3) o i)
      | "v128.store8_lane" ->
        VEC_STORE_LANE (fun a o i -> v128_store8_lane (opt a 0) o i)
      | "v128.store16_lane" ->
        VEC_STORE_LANE (fun a o i -> v128_store16_lane (opt a 1) o i)
      | "v128.store32_lane" ->
        VEC_STORE_LANE (fun a o i -> v128_store32_lane (opt a 2) o i)
      | "v128.store64_lane" ->
        VEC_STORE_LANE (fun a o i -> v128_store64_lane (opt a 3) o i)

      | "i32.const" ->
        CONST (fun s ->
          let n = I32.of_string s.it in i32_const (n @@ s.at), Values.I32 n)
      | "i64.const" ->
        CONST (fun s ->
          let n = I64.of_string s.it in i64_const (n @@ s.at), Values.I64 n)
      | "f32.const" ->
        CONST (fun s ->
          let n = F32.of_string s.it in f32_const (n @@ s.at), Values.F32 n)
      | "f64.const" ->
        CONST (fun s ->
          let n = F64.of_string s.it in f64_const (n @@ s.at), Values.F64 n)
      | "v128.const" ->
        VEC_CONST
          (fun shape ss at ->
            let v = V128.of_strings shape (List.map (fun s -> s.it) ss) in
            (v128_const (v @@ at), Values.V128 v))

      | "ref.null" -> REF_NULL
      | "ref.func" -> REF_FUNC
      | "ref.extern" -> REF_EXTERN
      | "ref.is_null" -> REF_IS_NULL

      | "i32.clz" -> UNARY i32_clz
      | "i32.ctz" -> UNARY i32_ctz
      | "i32.popcnt" -> UNARY i32_popcnt
      | "i32.extend8_s" -> UNARY i32_extend8_s
      | "i32.extend16_s" -> UNARY i32_extend16_s
      | "i64.clz" -> UNARY i64_clz
      | "i64.ctz" -> UNARY i64_ctz
      | "i64.popcnt" -> UNARY i64_popcnt
      | "i64.extend8_s" -> UNARY i64_extend8_s
      | "i64.extend16_s" -> UNARY i64_extend16_s
      | "i64.extend32_s" -> UNARY i64_extend32_s

      | "f32.neg" -> UNARY f32_neg
      | "f32.abs" -> UNARY f32_abs
      | "f32.sqrt" -> UNARY f32_sqrt
      | "f32.ceil" -> UNARY f32_ceil
      | "f32.floor" -> UNARY f32_floor
      | "f32.trunc" -> UNARY f32_trunc
      | "f32.nearest" -> UNARY f32_nearest
      | "f64.neg" -> UNARY f64_neg
      | "f64.abs" -> UNARY f64_abs
      | "f64.sqrt" -> UNARY f64_sqrt
      | "f64.ceil" -> UNARY f64_ceil
      | "f64.floor" -> UNARY f64_floor
      | "f64.trunc" -> UNARY f64_trunc
      | "f64.nearest" -> UNARY f64_nearest

      | "i32.add" -> BINARY i32_add
      | "i32.sub" -> BINARY i32_sub
      | "i32.mul" -> BINARY i32_mul
      | "i32.div_u" -> BINARY i32_div_u
      | "i32.div_s" -> BINARY i32_div_s
      | "i32.rem_u" -> BINARY i32_rem_u
      | "i32.rem_s" -> BINARY i32_rem_s
      | "i32.and" -> BINARY i32_and
      | "i32.or" -> BINARY i32_or
      | "i32.xor" -> BINARY i32_xor
      | "i32.shl" -> BINARY i32_shl
      | "i32.shr_u" -> BINARY i32_shr_u
      | "i32.shr_s" -> BINARY i32_shr_s
      | "i32.rotl" -> BINARY i32_rotl
      | "i32.rotr" -> BINARY i32_rotr
      | "i64.add" -> BINARY i64_add
      | "i64.sub" -> BINARY i64_sub
      | "i64.mul" -> BINARY i64_mul
      | "i64.div_u" -> BINARY i64_div_u
      | "i64.div_s" -> BINARY i64_div_s
      | "i64.rem_u" -> BINARY i64_rem_u
      | "i64.rem_s" -> BINARY i64_rem_s
      | "i64.and" -> BINARY i64_and
      | "i64.or" -> BINARY i64_or
      | "i64.xor" -> BINARY i64_xor
      | "i64.shl" -> BINARY i64_shl
      | "i64.shr_u" -> BINARY i64_shr_u
      | "i64.shr_s" -> BINARY i64_shr_s
      | "i64.rotl" -> BINARY i64_rotl
      | "i64.rotr" -> BINARY i64_rotr

      | "f32.add" -> BINARY f32_add
      | "f32.sub" -> BINARY f32_sub
      | "f32.mul" -> BINARY f32_mul
      | "f32.div" -> BINARY f32_div
      | "f32.min" -> BINARY f32_min
      | "f32.max" -> BINARY f32_max
      | "f32.copysign" -> BINARY f32_copysign
      | "f64.add" -> BINARY f64_add
      | "f64.sub" -> BINARY f64_sub
      | "f64.mul" -> BINARY f64_mul
      | "f64.div" -> BINARY f64_div
      | "f64.min" -> BINARY f64_min
      | "f64.max" -> BINARY f64_max
      | "f64.copysign" -> BINARY f64_copysign

      | "i32.eqz" -> TEST i32_eqz
      | "i64.eqz" -> TEST i64_eqz

      | "i32.eq" -> COMPARE i32_eq
      | "i32.ne" -> COMPARE i32_ne
      | "i32.lt_u" -> COMPARE i32_lt_u
      | "i32.lt_s" -> COMPARE i32_lt_s
      | "i32.le_u" -> COMPARE i32_le_u
      | "i32.le_s" -> COMPARE i32_le_s
      | "i32.gt_u" -> COMPARE i32_gt_u
      | "i32.gt_s" -> COMPARE i32_gt_s
      | "i32.ge_u" -> COMPARE i32_ge_u
      | "i32.ge_s" -> COMPARE i32_ge_s
      | "i64.eq" -> COMPARE i64_eq
      | "i64.ne" -> COMPARE i64_ne
      | "i64.lt_u" -> COMPARE i64_lt_u
      | "i64.lt_s" -> COMPARE i64_lt_s
      | "i64.le_u" -> COMPARE i64_le_u
      | "i64.le_s" -> COMPARE i64_le_s
      | "i64.gt_u" -> COMPARE i64_gt_u
      | "i64.gt_s" -> COMPARE i64_gt_s
      | "i64.ge_u" -> COMPARE i64_ge_u
      | "i64.ge_s" -> COMPARE i64_ge_s

      | "f32.eq" -> COMPARE f32_eq
      | "f32.ne" -> COMPARE f32_ne
      | "f32.lt" -> COMPARE f32_lt
      | "f32.le" -> COMPARE f32_le
      | "f32.gt" -> COMPARE f32_gt
      | "f32.ge" -> COMPARE f32_ge
      | "f64.eq" -> COMPARE f64_eq
      | "f64.ne" -> COMPARE f64_ne
      | "f64.lt" -> COMPARE f64_lt
      | "f64.le" -> COMPARE f64_le
      | "f64.gt" -> COMPARE f64_gt
      | "f64.ge" -> COMPARE f64_ge

      | "i32.wrap_i64" -> CONVERT i32_wrap_i64
      | "i64.extend_i32_s" -> CONVERT i64_extend_i32_s
      | "i64.extend_i32_u" -> CONVERT i64_extend_i32_u
      | "f32.demote_f64" -> CONVERT f32_demote_f64
      | "f64.promote_f32" -> CONVERT f64_promote_f32
      | "i32.trunc_f32_u" -> CONVERT i32_trunc_f32_u
      | "i32.trunc_f32_s" -> CONVERT i32_trunc_f32_s
      | "i64.trunc_f32_u" -> CONVERT i64_trunc_f32_u
      | "i64.trunc_f32_s" -> CONVERT i64_trunc_f32_s
      | "i32.trunc_f64_u" -> CONVERT i32_trunc_f64_u
      | "i32.trunc_f64_s" -> CONVERT i32_trunc_f64_s
      | "i64.trunc_f64_u" -> CONVERT i64_trunc_f64_u
      | "i64.trunc_f64_s" -> CONVERT i64_trunc_f64_s
      | "i32.trunc_sat_f32_u" -> CONVERT i32_trunc_sat_f32_u
      | "i32.trunc_sat_f32_s" -> CONVERT i32_trunc_sat_f32_s
      | "i64.trunc_sat_f32_u" -> CONVERT i64_trunc_sat_f32_u
      | "i64.trunc_sat_f32_s" -> CONVERT i64_trunc_sat_f32_s
      | "i32.trunc_sat_f64_u" -> CONVERT i32_trunc_sat_f64_u
      | "i32.trunc_sat_f64_s" -> CONVERT i32_trunc_sat_f64_s
      | "i64.trunc_sat_f64_u" -> CONVERT i64_trunc_sat_f64_u
      | "i64.trunc_sat_f64_s" -> CONVERT i64_trunc_sat_f64_s
      | "f32.convert_i32_u" -> CONVERT f32_convert_i32_u
      | "f32.convert_i32_s" -> CONVERT f32_convert_i32_s
      | "f64.convert_i32_u" -> CONVERT f64_convert_i32_u
      | "f64.convert_i32_s" -> CONVERT f64_convert_i32_s
      | "f32.convert_i64_u" -> CONVERT f32_convert_i64_u
      | "f32.convert_i64_s" -> CONVERT f32_convert_i64_s
      | "f64.convert_i64_u" -> CONVERT f64_convert_i64_u
      | "f64.convert_i64_s" -> CONVERT f64_convert_i64_s
      | "f32.reinterpret_i32" -> CONVERT f32_reinterpret_i32
      | "f64.reinterpret_i64" -> CONVERT f64_reinterpret_i64
      | "i32.reinterpret_f32" -> CONVERT i32_reinterpret_f32
      | "i64.reinterpret_f64" -> CONVERT i64_reinterpret_f64

      | "v128.not" -> VEC_UNARY v128_not
      | "v128.and" -> VEC_UNARY v128_and
      | "v128.andnot" -> VEC_UNARY v128_andnot
      | "v128.or" -> VEC_UNARY v128_or
      | "v128.xor" -> VEC_UNARY v128_xor
      | "v128.bitselect" -> VEC_TERNARY v128_bitselect
      | "v128.any_true" -> VEC_TEST v128_any_true

      | "i8x16.neg" -> VEC_UNARY i8x16_neg
      | "i16x8.neg" -> VEC_UNARY i16x8_neg
      | "i32x4.neg" -> VEC_UNARY i32x4_neg
      | "i64x2.neg" -> VEC_UNARY i64x2_neg
      | "i8x16.abs" -> VEC_UNARY i8x16_abs
      | "i16x8.abs" -> VEC_UNARY i16x8_abs
      | "i32x4.abs" -> VEC_UNARY i32x4_abs
      | "i64x2.abs" -> VEC_UNARY i64x2_abs
      | "i8x16.popcnt" -> VEC_UNARY i8x16_popcnt
      | "i8x16.avgr_u" -> VEC_UNARY i8x16_avgr_u
      | "i16x8.avgr_u" -> VEC_UNARY i16x8_avgr_u

      | "f32x4.neg" -> VEC_UNARY f32x4_neg
      | "f64x2.neg" -> VEC_UNARY f64x2_neg
      | "f32x4.abs" -> VEC_UNARY f32x4_abs
      | "f64x2.abs" -> VEC_UNARY f64x2_abs
      | "f32x4.sqrt" -> VEC_UNARY f32x4_sqrt
      | "f64x2.sqrt" -> VEC_UNARY f64x2_sqrt
      | "f32x4.ceil" -> VEC_UNARY f32x4_ceil
      | "f64x2.ceil" -> VEC_UNARY f64x2_ceil
      | "f32x4.floor" -> VEC_UNARY f32x4_floor
      | "f64x2.floor" -> VEC_UNARY f64x2_floor
      | "f32x4.trunc" -> VEC_UNARY f32x4_trunc
      | "f64x2.trunc" -> VEC_UNARY f64x2_trunc
      | "f32x4.nearest" -> VEC_UNARY f32x4_nearest
      | "f64x2.nearest" -> VEC_UNARY f64x2_nearest

      | "i32x4.trunc_sat_f32x4_u" -> VEC_UNARY i32x4_trunc_sat_f32x4_u
      | "i32x4.trunc_sat_f32x4_s" -> VEC_UNARY i32x4_trunc_sat_f32x4_s
      | "i32x4.trunc_sat_f64x2_u_zero" ->
        VEC_UNARY i32x4_trunc_sat_f64x2_u_zero
      | "i32x4.trunc_sat_f64x2_s_zero" ->
        VEC_UNARY i32x4_trunc_sat_f64x2_s_zero
      | "f64x2.promote_low_f32x4" -> VEC_UNARY f64x2_promote_low_f32x4
      | "f32x4.demote_f64x2_zero" -> VEC_UNARY f32x4_demote_f64x2_zero
      | "f32x4.convert_i32x4_u" -> VEC_UNARY f32x4_convert_i32x4_u
      | "f32x4.convert_i32x4_s" -> VEC_UNARY f32x4_convert_i32x4_s
      | "f64x2.convert_low_i32x4_u" -> VEC_UNARY f64x2_convert_low_i32x4_u
      | "f64x2.convert_low_i32x4_s" -> VEC_UNARY f64x2_convert_low_i32x4_s
      | "i16x8.extadd_pairwise_i8x16_u" ->
        VEC_UNARY i16x8_extadd_pairwise_i8x16_u
      | "i16x8.extadd_pairwise_i8x16_s" ->
        VEC_UNARY i16x8_extadd_pairwise_i8x16_s
      | "i32x4.extadd_pairwise_i16x8_u" ->
        VEC_UNARY i32x4_extadd_pairwise_i16x8_u
      | "i32x4.extadd_pairwise_i16x8_s" ->
        VEC_UNARY i32x4_extadd_pairwise_i16x8_s

      | "i8x16.eq" -> VEC_BINARY i8x16_eq
      | "i16x8.eq" -> VEC_BINARY i16x8_eq
      | "i32x4.eq" -> VEC_BINARY i32x4_eq
      | "i64x2.eq" -> VEC_BINARY i64x2_eq
      | "i8x16.ne" -> VEC_BINARY i8x16_ne
      | "i16x8.ne" -> VEC_BINARY i16x8_ne
      | "i32x4.ne" -> VEC_BINARY i32x4_ne
      | "i64x2.ne" -> VEC_BINARY i64x2_ne
      | "i8x16.lt_u" -> VEC_BINARY i8x16_lt_u
      | "i8x16.lt_s" -> VEC_BINARY i8x16_lt_s
      | "i16x8.lt_u" -> VEC_BINARY i16x8_lt_u
      | "i16x8.lt_s" -> VEC_BINARY i16x8_lt_s
      | "i32x4.lt_u" -> VEC_BINARY i32x4_lt_u
      | "i32x4.lt_s" -> VEC_BINARY i32x4_lt_s
      | "i64x2.lt_s" -> VEC_BINARY i64x2_lt_s
      | "i8x16.le_u" -> VEC_BINARY i8x16_le_u
      | "i8x16.le_s" -> VEC_BINARY i8x16_le_s
      | "i16x8.le_u" -> VEC_BINARY i16x8_le_u
      | "i16x8.le_s" -> VEC_BINARY i16x8_le_s
      | "i32x4.le_u" -> VEC_BINARY i32x4_le_u
      | "i32x4.le_s" -> VEC_BINARY i32x4_le_s
      | "i64x2.le_s" -> VEC_BINARY i64x2_le_s
      | "i8x16.gt_u" -> VEC_BINARY i8x16_gt_u
      | "i8x16.gt_s" -> VEC_BINARY i8x16_gt_s
      | "i16x8.gt_u" -> VEC_BINARY i16x8_gt_u
      | "i16x8.gt_s" -> VEC_BINARY i16x8_gt_s
      | "i32x4.gt_u" -> VEC_BINARY i32x4_gt_u
      | "i32x4.gt_s" -> VEC_BINARY i32x4_gt_s
      | "i64x2.gt_s" -> VEC_BINARY i64x2_gt_s
      | "i8x16.ge_u" -> VEC_BINARY i8x16_ge_u
      | "i8x16.ge_s" -> VEC_BINARY i8x16_ge_s
      | "i16x8.ge_u" -> VEC_BINARY i16x8_ge_u
      | "i16x8.ge_s" -> VEC_BINARY i16x8_ge_s
      | "i32x4.ge_u" -> VEC_BINARY i32x4_ge_u
      | "i32x4.ge_s" -> VEC_BINARY i32x4_ge_s
      | "i64x2.ge_s" -> VEC_BINARY i64x2_ge_s

      | "f32x4.eq" -> VEC_BINARY f32x4_eq
      | "f64x2.eq" -> VEC_BINARY f64x2_eq
      | "f32x4.ne" -> VEC_BINARY f32x4_ne
      | "f64x2.ne" -> VEC_BINARY f64x2_ne
      | "f32x4.lt" -> VEC_BINARY f32x4_lt
      | "f64x2.lt" -> VEC_BINARY f64x2_lt
      | "f32x4.le" -> VEC_BINARY f32x4_le
      | "f64x2.le" -> VEC_BINARY f64x2_le
      | "f32x4.gt" -> VEC_BINARY f32x4_gt
      | "f64x2.gt" -> VEC_BINARY f64x2_gt
      | "f32x4.ge" -> VEC_BINARY f32x4_ge
      | "f64x2.ge" -> VEC_BINARY f64x2_ge
      | "i8x16.swizzle" -> VEC_BINARY i8x16_swizzle

      | "i8x16.add" -> VEC_BINARY i8x16_add
      | "i16x8.add" -> VEC_BINARY i16x8_add
      | "i32x4.add" -> VEC_BINARY i32x4_add
      | "i64x2.add" -> VEC_BINARY i64x2_add
      | "i8x16.sub" -> VEC_BINARY i8x16_sub
      | "i16x8.sub" -> VEC_BINARY i16x8_sub
      | "i32x4.sub" -> VEC_BINARY i32x4_sub
      | "i64x2.sub" -> VEC_BINARY i64x2_sub
      | "i16x8.mul" -> VEC_BINARY i16x8_mul
      | "i32x4.mul" -> VEC_BINARY i32x4_mul
      | "i64x2.mul" -> VEC_BINARY i64x2_mul
      | "i8x16.add_sat_u" -> VEC_BINARY i8x16_add_sat_u
      | "i8x16.add_sat_s" -> VEC_BINARY i8x16_add_sat_s
      | "i16x8.add_sat_u" -> VEC_BINARY i16x8_add_sat_u
      | "i16x8.add_sat_s" -> VEC_BINARY i16x8_add_sat_s
      | "i8x16.sub_sat_u" -> VEC_BINARY i8x16_sub_sat_u
      | "i8x16.sub_sat_s" -> VEC_BINARY i8x16_sub_sat_s
      | "i16x8.sub_sat_u" -> VEC_BINARY i16x8_sub_sat_u
      | "i16x8.sub_sat_s" -> VEC_BINARY i16x8_sub_sat_s
      | "i32x4.dot_i16x8_s" -> VEC_BINARY i32x4_dot_i16x8_s

      | "i8x16.min_u" -> VEC_BINARY i8x16_min_u
      | "i16x8.min_u" -> VEC_BINARY i16x8_min_u
      | "i32x4.min_u" -> VEC_BINARY i32x4_min_u
      | "i8x16.min_s" -> VEC_BINARY i8x16_min_s
      | "i16x8.min_s" -> VEC_BINARY i16x8_min_s
      | "i32x4.min_s" -> VEC_BINARY i32x4_min_s
      | "i8x16.max_u" -> VEC_BINARY i8x16_max_u
      | "i16x8.max_u" -> VEC_BINARY i16x8_max_u
      | "i32x4.max_u" -> VEC_BINARY i32x4_max_u
      | "i8x16.max_s" -> VEC_BINARY i8x16_max_s
      | "i16x8.max_s" -> VEC_BINARY i16x8_max_s
      | "i32x4.max_s" -> VEC_BINARY i32x4_max_s

      | "f32x4.add" -> VEC_BINARY f32x4_add
      | "f64x2.add" -> VEC_BINARY f64x2_add
      | "f32x4.sub" -> VEC_BINARY f32x4_sub
      | "f64x2.sub" -> VEC_BINARY f64x2_sub
      | "f32x4.mul" -> VEC_BINARY f32x4_mul
      | "f64x2.mul" -> VEC_BINARY f64x2_mul
      | "f32x4.div" -> VEC_BINARY f32x4_div
      | "f64x2.div" -> VEC_BINARY f64x2_div

      | "f32x4.min" -> VEC_BINARY f32x4_min
      | "f64x2.min" -> VEC_BINARY f64x2_min
      | "f32x4.max" -> VEC_BINARY f32x4_max
      | "f64x2.max" -> VEC_BINARY f64x2_max
      | "f32x4.pmin" -> VEC_BINARY f32x4_pmin
      | "f64x2.pmin" -> VEC_BINARY f64x2_pmin
      | "f32x4.pmax" -> VEC_BINARY f32x4_pmax
      | "f64x2.pmax" -> VEC_BINARY f64x2_pmax

      | "i16x8.q15mulr_sat_s" -> VEC_BINARY i16x8_q15mulr_sat_s
      | "i8x16.narrow_i16x8_u" -> VEC_BINARY i8x16_narrow_i16x8_u
      | "i8x16.narrow_i16x8_s" -> VEC_BINARY i8x16_narrow_i16x8_s
      | "i16x8.narrow_i32x4_u" -> VEC_BINARY i16x8_narrow_i32x4_u
      | "i16x8.narrow_i32x4_s" -> VEC_BINARY i16x8_narrow_i32x4_s
      | "i16x8.extend_low_i8x16_u" -> VEC_UNARY i16x8_extend_low_i8x16_u
      | "i16x8.extend_low_i8x16_s" -> VEC_UNARY i16x8_extend_low_i8x16_s
      | "i16x8.extend_high_i8x16_u" -> VEC_UNARY i16x8_extend_high_i8x16_u
      | "i16x8.extend_high_i8x16_s" -> VEC_UNARY i16x8_extend_high_i8x16_s
      | "i32x4.extend_low_i16x8_u" -> VEC_UNARY i32x4_extend_low_i16x8_u
      | "i32x4.extend_low_i16x8_s" -> VEC_UNARY i32x4_extend_low_i16x8_s
      | "i32x4.extend_high_i16x8_u" -> VEC_UNARY i32x4_extend_high_i16x8_u
      | "i32x4.extend_high_i16x8_s" -> VEC_UNARY i32x4_extend_high_i16x8_s
      | "i64x2.extend_low_i32x4_u" -> VEC_UNARY i64x2_extend_low_i32x4_u
      | "i64x2.extend_low_i32x4_s" -> VEC_UNARY i64x2_extend_low_i32x4_s
      | "i64x2.extend_high_i32x4_u" -> VEC_UNARY i64x2_extend_high_i32x4_u
      | "i64x2.extend_high_i32x4_s" -> VEC_UNARY i64x2_extend_high_i32x4_s
      | "i16x8.extmul_low_i8x16_u" -> VEC_UNARY i16x8_extmul_low_i8x16_u
      | "i16x8.extmul_low_i8x16_s" -> VEC_UNARY i16x8_extmul_low_i8x16_s
      | "i16x8.extmul_high_i8x16_u" -> VEC_UNARY i16x8_extmul_high_i8x16_u
      | "i16x8.extmul_high_i8x16_s" -> VEC_UNARY i16x8_extmul_high_i8x16_s
      | "i32x4.extmul_low_i16x8_u" -> VEC_UNARY i32x4_extmul_low_i16x8_u
      | "i32x4.extmul_low_i16x8_s" -> VEC_UNARY i32x4_extmul_low_i16x8_s
      | "i32x4.extmul_high_i16x8_u" -> VEC_UNARY i32x4_extmul_high_i16x8_u
      | "i32x4.extmul_high_i16x8_s" -> VEC_UNARY i32x4_extmul_high_i16x8_s
      | "i64x2.extmul_low_i32x4_u" -> VEC_UNARY i64x2_extmul_low_i32x4_u
      | "i64x2.extmul_low_i32x4_s" -> VEC_UNARY i64x2_extmul_low_i32x4_s
      | "i64x2.extmul_high_i32x4_u" -> VEC_UNARY i64x2_extmul_high_i32x4_u
      | "i64x2.extmul_high_i32x4_s" -> VEC_UNARY i64x2_extmul_high_i32x4_s

      | "i8x16.all_true" -> VEC_TEST i8x16_all_true
      | "i16x8.all_true" -> VEC_TEST i16x8_all_true
      | "i32x4.all_true" -> VEC_TEST i32x4_all_true
      | "i64x2.all_true" -> VEC_TEST i64x2_all_true
      | "i8x16.bitmask" -> VEC_BITMASK i8x16_bitmask
      | "i16x8.bitmask" -> VEC_BITMASK i16x8_bitmask
      | "i32x4.bitmask" -> VEC_BITMASK i32x4_bitmask
      | "i64x2.bitmask" -> VEC_BITMASK i64x2_bitmask
      | "i8x16.shl" -> VEC_SHIFT i8x16_shl
      | "i16x8.shl" -> VEC_SHIFT i16x8_shl
      | "i32x4.shl" -> VEC_SHIFT i32x4_shl
      | "i64x2.shl" -> VEC_SHIFT i64x2_shl
      | "i8x16.shr_u" -> VEC_SHIFT i8x16_shr_u
      | "i8x16.shr_s" -> VEC_SHIFT i8x16_shr_s
      | "i16x8.shr_u" -> VEC_SHIFT i16x8_shr_u
      | "i16x8.shr_s" -> VEC_SHIFT i16x8_shr_s
      | "i32x4.shr_u" -> VEC_SHIFT i32x4_shr_u
      | "i32x4.shr_s" -> VEC_SHIFT i32x4_shr_s
      | "i64x2.shr_u" -> VEC_SHIFT i64x2_shr_u
      | "i64x2.shr_s" -> VEC_SHIFT i64x2_shr_s
      | "i8x16.shuffle" -> VEC_SHUFFLE

      | "i8x16.splat" -> VEC_SPLAT i8x16_splat
      | "i16x8.splat" -> VEC_SPLAT i16x8_splat
      | "i32x4.splat" -> VEC_SPLAT i32x4_splat
      | "i64x2.splat" -> VEC_SPLAT i64x2_splat
      | "f32x4.splat" -> VEC_SPLAT f32x4_splat
      | "f64x2.splat" -> VEC_SPLAT f64x2_splat
      | "i8x16.extract_lane_u" -> VEC_EXTRACT i8x16_extract_lane_u
      | "i8x16.extract_lane_s" -> VEC_EXTRACT i8x16_extract_lane_s
      | "i16x8.extract_lane_u" -> VEC_EXTRACT i16x8_extract_lane_u
      | "i16x8.extract_lane_s" -> VEC_EXTRACT i16x8_extract_lane_s
      | "i32x4.extract_lane" -> VEC_EXTRACT i32x4_extract_lane
      | "i64x2.extract_lane" -> VEC_EXTRACT i64x2_extract_lane
      | "f32x4.extract_lane" -> VEC_EXTRACT f32x4_extract_lane
      | "f64x2.extract_lane" -> VEC_EXTRACT f64x2_extract_lane
      | "i8x16.replace_lane" -> VEC_REPLACE i8x16_replace_lane
      | "i16x8.replace_lane" -> VEC_REPLACE i16x8_replace_lane
      | "i32x4.replace_lane" -> VEC_REPLACE i32x4_replace_lane
      | "i64x2.replace_lane" -> VEC_REPLACE i64x2_replace_lane
      | "f32x4.replace_lane" -> VEC_REPLACE f32x4_replace_lane
      | "f64x2.replace_lane" -> VEC_REPLACE f64x2_replace_lane

      | "type" -> TYPE
      | "func" -> FUNC
      | "param" -> PARAM
      | "result" -> RESULT
      | "start" -> START
      | "local" -> LOCAL
      | "global" -> GLOBAL
      | "table" -> TABLE
      | "memory" -> MEMORY
      | "elem" -> ELEM
      | "data" -> DATA
      | "declare" -> DECLARE
      | "offset" -> OFFSET
      | "item" -> ITEM
      | "import" -> IMPORT
      | "export" -> EXPORT

      | "module" -> MODULE
      | "binary" -> BIN
      | "quote" -> QUOTE

      | "script" -> SCRIPT
      | "register" -> REGISTER
      | "invoke" -> INVOKE
      | "get" -> GET
      | "assert_malformed" -> ASSERT_MALFORMED
      | "assert_invalid" -> ASSERT_INVALID
      | "assert_unlinkable" -> ASSERT_UNLINKABLE
      | "assert_return" -> ASSERT_RETURN
      | "assert_trap" -> ASSERT_TRAP
      | "assert_exhaustion" -> ASSERT_EXHAUSTION
      | "nan:canonical" -> NAN Script.CanonicalNan
      | "nan:arithmetic" -> NAN Script.ArithmeticNan
      | "input" -> INPUT
      | "output" -> OUTPUT

      | _ -> unknown lexbuf
    )
# 4734 "text/lexer.ml"

  | 10 ->
let
# 695 "text/lexer.mll"
                     s
# 4740 "text/lexer.ml"
= Lexing.sub_lexeme lexbuf (lexbuf.Lexing.lex_start_pos + 7) lexbuf.Lexing.lex_curr_pos in
# 695 "text/lexer.mll"
                        ( OFFSET_EQ_NAT s )
# 4744 "text/lexer.ml"

  | 11 ->
let
# 696 "text/lexer.mll"
                    s
# 4750 "text/lexer.ml"
= Lexing.sub_lexeme lexbuf (lexbuf.Lexing.lex_start_pos + 6) lexbuf.Lexing.lex_curr_pos in
# 696 "text/lexer.mll"
                       ( ALIGN_EQ_NAT s )
# 4754 "text/lexer.ml"

  | 12 ->
let
# 698 "text/lexer.mll"
          s
# 4760 "text/lexer.ml"
= Lexing.sub_lexeme lexbuf lexbuf.Lexing.lex_start_pos lexbuf.Lexing.lex_curr_pos in
# 698 "text/lexer.mll"
            ( VAR s )
# 4764 "text/lexer.ml"

  | 13 ->
# 700 "text/lexer.mll"
                       ( EOF )
# 4769 "text/lexer.ml"

  | 14 ->
# 701 "text/lexer.mll"
                        ( Lexing.new_line lexbuf; token lexbuf )
# 4774 "text/lexer.ml"

  | 15 ->
# 702 "text/lexer.mll"
                    ( token lexbuf (* causes error on following position *) )
# 4779 "text/lexer.ml"

  | 16 ->
# 703 "text/lexer.mll"
         ( comment (Lexing.lexeme_start_p lexbuf) lexbuf; token lexbuf )
# 4784 "text/lexer.ml"

  | 17 ->
# 704 "text/lexer.mll"
               ( token lexbuf )
# 4789 "text/lexer.ml"

  | 18 ->
# 705 "text/lexer.mll"
         ( Lexing.new_line lexbuf; token lexbuf )
# 4794 "text/lexer.ml"

  | 19 ->
# 706 "text/lexer.mll"
        ( EOF )
# 4799 "text/lexer.ml"

  | 20 ->
# 708 "text/lexer.mll"
             ( unknown lexbuf )
# 4804 "text/lexer.ml"

  | 21 ->
# 709 "text/lexer.mll"
            ( error lexbuf "misplaced control character" )
# 4809 "text/lexer.ml"

  | 22 ->
# 710 "text/lexer.mll"
            ( error lexbuf "misplaced unicode character" )
# 4814 "text/lexer.ml"

  | 23 ->
# 711 "text/lexer.mll"
      ( error lexbuf "malformed UTF-8 encoding" )
# 4819 "text/lexer.ml"

  | _ -> raise (Failure "lexing: empty token")


and comment start lexbuf =
  let __ocaml_lex_result =
    let _curr = lexbuf.Lexing.lex_curr_pos in
    let _last = _curr in
    let _len = lexbuf.Lexing.lex_buffer_len in
    let _buf = lexbuf.Lexing.lex_buffer in
    let _last_action = -1 in
    lexbuf.Lexing.lex_start_pos <- _curr;
    let next_char, _buf, _len, _curr, _last =
      if _curr >= _len then
        __ocaml_lex_refill_buf lexbuf _buf _len _curr _last
      else
        Char.code (Bytes.unsafe_get _buf _curr),
        _buf, _len, (_curr + 1), _last
    in
    begin match next_char with
      (* |'\224' *)
      | 224 ->
        (* *)
        let _last = _curr in
        let _last_action = 5 in
        let next_char, _buf, _len, _curr, _last =
          if _curr >= _len then
            __ocaml_lex_refill_buf lexbuf _buf _len _curr _last
          else
            Char.code (Bytes.unsafe_get _buf _curr),
            _buf, _len, (_curr + 1), _last
        in
        begin match next_char with
          (* |'\160'|'\161'|'\162'|'\163'|'\164'|'\165'|'\166'|'\167'|'\168'|'\169'|'\170'|'\171'|'\172'|'\173'|'\174'|'\175'|'\176'|'\177'|'\178'|'\179'|'\180'|'\181'|'\182'|'\183'|'\184'|'\185'|'\186'|'\187'|'\188'|'\189'|'\190'|'\191' *)
          |160|161|162|163|164|165|166|167|168|169|170|171|172|173|174|175|176|177|178|179|180|181|182|183|184|185|186|187|188|189|190|191 ->
            let next_char, _buf, _len, _curr, _last =
              if _curr >= _len then
                __ocaml_lex_refill_buf lexbuf _buf _len _curr _last
              else
                Char.code (Bytes.unsafe_get _buf _curr),
                _buf, _len, (_curr + 1), _last
            in
            begin match next_char with
              (* |'\128'|'\129'|'\130'|'\131'|'\132'|'\133'|'\134'|'\135'|'\136'|'\137'|'\138'|'\139'|'\140'|'\141'|'\142'|'\143'|'\144'|'\145'|'\146'|'\147'|'\148'|'\149'|'\150'|'\151'|'\152'|'\153'|'\154'|'\155'|'\156'|'\157'|'\158'|'\159'|'\160'|'\161'|'\162'|'\163'|'\164'|'\165'|'\166'|'\167'|'\168'|'\169'|'\170'|'\171'|'\172'|'\173'|'\174'|'\175'|'\176'|'\177'|'\178'|'\179'|'\180'|'\181'|'\182'|'\183'|'\184'|'\185'|'\186'|'\187'|'\188'|'\189'|'\190'|'\191' *)
              |128|129|130|131|132|133|134|135|136|137|138|139|140|141|142|143|144|145|146|147|148|149|150|151|152|153|154|155|156|157|158|159|160|161|162|163|164|165|166|167|168|169|170|171|172|173|174|175|176|177|178|179|180|181|182|183|184|185|186|187|188|189|190|191 ->
                (* *)
                lexbuf.Lexing.lex_curr_pos <- _curr;
                lexbuf.Lexing.lex_last_pos <- _last;
                3
              | _ ->
                let _curr = _last in
                lexbuf.Lexing.lex_curr_pos <- _curr;
                lexbuf.Lexing.lex_last_pos <- _last;
                5 (* = last_action *)
            end
          | _ ->
            let _curr = _last in
            lexbuf.Lexing.lex_curr_pos <- _curr;
            lexbuf.Lexing.lex_last_pos <- _last;
            5 (* = last_action *)
        end
      (* |';' *)
      | 59 ->
        (* *)
        let _last = _curr in
        let _last_action = 3 in
        let next_char, _buf, _len, _curr, _last =
          if _curr >= _len then
            __ocaml_lex_refill_buf lexbuf _buf _len _curr _last
          else
            Char.code (Bytes.unsafe_get _buf _curr),
            _buf, _len, (_curr + 1), _last
        in
        begin match next_char with
          (* |')' *)
          | 41 ->
            (* *)
            lexbuf.Lexing.lex_curr_pos <- _curr;
            lexbuf.Lexing.lex_last_pos <- _last;
            0
          | _ ->
            let _curr = _last in
            lexbuf.Lexing.lex_curr_pos <- _curr;
            lexbuf.Lexing.lex_last_pos <- _last;
            3 (* = last_action *)
        end
      (* |'(' *)
      | 40 ->
        (* *)
        let _last = _curr in
        let _last_action = 3 in
        let next_char, _buf, _len, _curr, _last =
          if _curr >= _len then
            __ocaml_lex_refill_buf lexbuf _buf _len _curr _last
          else
            Char.code (Bytes.unsafe_get _buf _curr),
            _buf, _len, (_curr + 1), _last
        in
        begin match next_char with
          (* |';' *)
          | 59 ->
            (* *)
            lexbuf.Lexing.lex_curr_pos <- _curr;
            lexbuf.Lexing.lex_last_pos <- _last;
            1
          | _ ->
            let _curr = _last in
            lexbuf.Lexing.lex_curr_pos <- _curr;
            lexbuf.Lexing.lex_last_pos <- _last;
            3 (* = last_action *)
        end
      (* |'\240' *)
      | 240 ->
        (* *)
        let _last = _curr in
        let _last_action = 5 in
        let next_char, _buf, _len, _curr, _last =
          if _curr >= _len then
            __ocaml_lex_refill_buf lexbuf _buf _len _curr _last
          else
            Char.code (Bytes.unsafe_get _buf _curr),
            _buf, _len, (_curr + 1), _last
        in
        begin match next_char with
          (* |'\144'|'\145'|'\146'|'\147'|'\148'|'\149'|'\150'|'\151'|'\152'|'\153'|'\154'|'\155'|'\156'|'\157'|'\158'|'\159'|'\160'|'\161'|'\162'|'\163'|'\164'|'\165'|'\166'|'\167'|'\168'|'\169'|'\170'|'\171'|'\172'|'\173'|'\174'|'\175'|'\176'|'\177'|'\178'|'\179'|'\180'|'\181'|'\182'|'\183'|'\184'|'\185'|'\186'|'\187'|'\188'|'\189'|'\190'|'\191' *)
          |144|145|146|147|148|149|150|151|152|153|154|155|156|157|158|159|160|161|162|163|164|165|166|167|168|169|170|171|172|173|174|175|176|177|178|179|180|181|182|183|184|185|186|187|188|189|190|191 ->
            let next_char, _buf, _len, _curr, _last =
              if _curr >= _len then
                __ocaml_lex_refill_buf lexbuf _buf _len _curr _last
              else
                Char.code (Bytes.unsafe_get _buf _curr),
                _buf, _len, (_curr + 1), _last
            in
            begin match next_char with
              (* |'\128'|'\129'|'\130'|'\131'|'\132'|'\133'|'\134'|'\135'|'\136'|'\137'|'\138'|'\139'|'\140'|'\141'|'\142'|'\143'|'\144'|'\145'|'\146'|'\147'|'\148'|'\149'|'\150'|'\151'|'\152'|'\153'|'\154'|'\155'|'\156'|'\157'|'\158'|'\159'|'\160'|'\161'|'\162'|'\163'|'\164'|'\165'|'\166'|'\167'|'\168'|'\169'|'\170'|'\171'|'\172'|'\173'|'\174'|'\175'|'\176'|'\177'|'\178'|'\179'|'\180'|'\181'|'\182'|'\183'|'\184'|'\185'|'\186'|'\187'|'\188'|'\189'|'\190'|'\191' *)
              |128|129|130|131|132|133|134|135|136|137|138|139|140|141|142|143|144|145|146|147|148|149|150|151|152|153|154|155|156|157|158|159|160|161|162|163|164|165|166|167|168|169|170|171|172|173|174|175|176|177|178|179|180|181|182|183|184|185|186|187|188|189|190|191 ->
                let next_char, _buf, _len, _curr, _last =
                  if _curr >= _len then
                    __ocaml_lex_refill_buf lexbuf _buf _len _curr _last
                  else
                    Char.code (Bytes.unsafe_get _buf _curr),
                    _buf, _len, (_curr + 1), _last
                in
                begin match next_char with
                  (* |'\128'|'\129'|'\130'|'\131'|'\132'|'\133'|'\134'|'\135'|'\136'|'\137'|'\138'|'\139'|'\140'|'\141'|'\142'|'\143'|'\144'|'\145'|'\146'|'\147'|'\148'|'\149'|'\150'|'\151'|'\152'|'\153'|'\154'|'\155'|'\156'|'\157'|'\158'|'\159'|'\160'|'\161'|'\162'|'\163'|'\164'|'\165'|'\166'|'\167'|'\168'|'\169'|'\170'|'\171'|'\172'|'\173'|'\174'|'\175'|'\176'|'\177'|'\178'|'\179'|'\180'|'\181'|'\182'|'\183'|'\184'|'\185'|'\186'|'\187'|'\188'|'\189'|'\190'|'\191' *)
                  |128|129|130|131|132|133|134|135|136|137|138|139|140|141|142|143|144|145|146|147|148|149|150|151|152|153|154|155|156|157|158|159|160|161|162|163|164|165|166|167|168|169|170|171|172|173|174|175|176|177|178|179|180|181|182|183|184|185|186|187|188|189|190|191 ->
                    (* *)
                    lexbuf.Lexing.lex_curr_pos <- _curr;
                    lexbuf.Lexing.lex_last_pos <- _last;
                    3
                  | _ ->
                    let _curr = _last in
                    lexbuf.Lexing.lex_curr_pos <- _curr;
                    lexbuf.Lexing.lex_last_pos <- _last;
                    5 (* = last_action *)
                end
              | _ ->
                let _curr = _last in
                lexbuf.Lexing.lex_curr_pos <- _curr;
                lexbuf.Lexing.lex_last_pos <- _last;
                5 (* = last_action *)
            end
          | _ ->
            let _curr = _last in
            lexbuf.Lexing.lex_curr_pos <- _curr;
            lexbuf.Lexing.lex_last_pos <- _last;
            5 (* = last_action *)
        end
      (* |'\244' *)
      | 244 ->
        (* *)
        let _last = _curr in
        let _last_action = 5 in
        let next_char, _buf, _len, _curr, _last =
          if _curr >= _len then
            __ocaml_lex_refill_buf lexbuf _buf _len _curr _last
          else
            Char.code (Bytes.unsafe_get _buf _curr),
            _buf, _len, (_curr + 1), _last
        in
        begin match next_char with
          (* |'\128'|'\129'|'\130'|'\131'|'\132'|'\133'|'\134'|'\135'|'\136'|'\137'|'\138'|'\139'|'\140'|'\141'|'\142'|'\143' *)
          |128|129|130|131|132|133|134|135|136|137|138|139|140|141|142|143 ->
            let next_char, _buf, _len, _curr, _last =
              if _curr >= _len then
                __ocaml_lex_refill_buf lexbuf _buf _len _curr _last
              else
                Char.code (Bytes.unsafe_get _buf _curr),
                _buf, _len, (_curr + 1), _last
            in
            begin match next_char with
              (* |'\128'|'\129'|'\130'|'\131'|'\132'|'\133'|'\134'|'\135'|'\136'|'\137'|'\138'|'\139'|'\140'|'\141'|'\142'|'\143'|'\144'|'\145'|'\146'|'\147'|'\148'|'\149'|'\150'|'\151'|'\152'|'\153'|'\154'|'\155'|'\156'|'\157'|'\158'|'\159'|'\160'|'\161'|'\162'|'\163'|'\164'|'\165'|'\166'|'\167'|'\168'|'\169'|'\170'|'\171'|'\172'|'\173'|'\174'|'\175'|'\176'|'\177'|'\178'|'\179'|'\180'|'\181'|'\182'|'\183'|'\184'|'\185'|'\186'|'\187'|'\188'|'\189'|'\190'|'\191' *)
              |128|129|130|131|132|133|134|135|136|137|138|139|140|141|142|143|144|145|146|147|148|149|150|151|152|153|154|155|156|157|158|159|160|161|162|163|164|165|166|167|168|169|170|171|172|173|174|175|176|177|178|179|180|181|182|183|184|185|186|187|188|189|190|191 ->
                let next_char, _buf, _len, _curr, _last =
                  if _curr >= _len then
                    __ocaml_lex_refill_buf lexbuf _buf _len _curr _last
                  else
                    Char.code (Bytes.unsafe_get _buf _curr),
                    _buf, _len, (_curr + 1), _last
                in
                begin match next_char with
                  (* |'\128'|'\129'|'\130'|'\131'|'\132'|'\133'|'\134'|'\135'|'\136'|'\137'|'\138'|'\139'|'\140'|'\141'|'\142'|'\143'|'\144'|'\145'|'\146'|'\147'|'\148'|'\149'|'\150'|'\151'|'\152'|'\153'|'\154'|'\155'|'\156'|'\157'|'\158'|'\159'|'\160'|'\161'|'\162'|'\163'|'\164'|'\165'|'\166'|'\167'|'\168'|'\169'|'\170'|'\171'|'\172'|'\173'|'\174'|'\175'|'\176'|'\177'|'\178'|'\179'|'\180'|'\181'|'\182'|'\183'|'\184'|'\185'|'\186'|'\187'|'\188'|'\189'|'\190'|'\191' *)
                  |128|129|130|131|132|133|134|135|136|137|138|139|140|141|142|143|144|145|146|147|148|149|150|151|152|153|154|155|156|157|158|159|160|161|162|163|164|165|166|167|168|169|170|171|172|173|174|175|176|177|178|179|180|181|182|183|184|185|186|187|188|189|190|191 ->
                    (* *)
                    lexbuf.Lexing.lex_curr_pos <- _curr;
                    lexbuf.Lexing.lex_last_pos <- _last;
                    3
                  | _ ->
                    let _curr = _last in
                    lexbuf.Lexing.lex_curr_pos <- _curr;
                    lexbuf.Lexing.lex_last_pos <- _last;
                    5 (* = last_action *)
                end
              | _ ->
                let _curr = _last in
                lexbuf.Lexing.lex_curr_pos <- _curr;
                lexbuf.Lexing.lex_last_pos <- _last;
                5 (* = last_action *)
            end
          | _ ->
            let _curr = _last in
            lexbuf.Lexing.lex_curr_pos <- _curr;
            lexbuf.Lexing.lex_last_pos <- _last;
            5 (* = last_action *)
        end
      (* |'\241'|'\242'|'\243' *)
      |241|242|243 ->
        (* *)
        let _last = _curr in
        let _last_action = 5 in
        let next_char, _buf, _len, _curr, _last =
          if _curr >= _len then
            __ocaml_lex_refill_buf lexbuf _buf _len _curr _last
          else
            Char.code (Bytes.unsafe_get _buf _curr),
            _buf, _len, (_curr + 1), _last
        in
        begin match next_char with
          (* |'\128'|'\129'|'\130'|'\131'|'\132'|'\133'|'\134'|'\135'|'\136'|'\137'|'\138'|'\139'|'\140'|'\141'|'\142'|'\143'|'\144'|'\145'|'\146'|'\147'|'\148'|'\149'|'\150'|'\151'|'\152'|'\153'|'\154'|'\155'|'\156'|'\157'|'\158'|'\159'|'\160'|'\161'|'\162'|'\163'|'\164'|'\165'|'\166'|'\167'|'\168'|'\169'|'\170'|'\171'|'\172'|'\173'|'\174'|'\175'|'\176'|'\177'|'\178'|'\179'|'\180'|'\181'|'\182'|'\183'|'\184'|'\185'|'\186'|'\187'|'\188'|'\189'|'\190'|'\191' *)
          |128|129|130|131|132|133|134|135|136|137|138|139|140|141|142|143|144|145|146|147|148|149|150|151|152|153|154|155|156|157|158|159|160|161|162|163|164|165|166|167|168|169|170|171|172|173|174|175|176|177|178|179|180|181|182|183|184|185|186|187|188|189|190|191 ->
            let next_char, _buf, _len, _curr, _last =
              if _curr >= _len then
                __ocaml_lex_refill_buf lexbuf _buf _len _curr _last
              else
                Char.code (Bytes.unsafe_get _buf _curr),
                _buf, _len, (_curr + 1), _last
            in
            begin match next_char with
              (* |'\128'|'\129'|'\130'|'\131'|'\132'|'\133'|'\134'|'\135'|'\136'|'\137'|'\138'|'\139'|'\140'|'\141'|'\142'|'\143'|'\144'|'\145'|'\146'|'\147'|'\148'|'\149'|'\150'|'\151'|'\152'|'\153'|'\154'|'\155'|'\156'|'\157'|'\158'|'\159'|'\160'|'\161'|'\162'|'\163'|'\164'|'\165'|'\166'|'\167'|'\168'|'\169'|'\170'|'\171'|'\172'|'\173'|'\174'|'\175'|'\176'|'\177'|'\178'|'\179'|'\180'|'\181'|'\182'|'\183'|'\184'|'\185'|'\186'|'\187'|'\188'|'\189'|'\190'|'\191' *)
              |128|129|130|131|132|133|134|135|136|137|138|139|140|141|142|143|144|145|146|147|148|149|150|151|152|153|154|155|156|157|158|159|160|161|162|163|164|165|166|167|168|169|170|171|172|173|174|175|176|177|178|179|180|181|182|183|184|185|186|187|188|189|190|191 ->
                let next_char, _buf, _len, _curr, _last =
                  if _curr >= _len then
                    __ocaml_lex_refill_buf lexbuf _buf _len _curr _last
                  else
                    Char.code (Bytes.unsafe_get _buf _curr),
                    _buf, _len, (_curr + 1), _last
                in
                begin match next_char with
                  (* |'\128'|'\129'|'\130'|'\131'|'\132'|'\133'|'\134'|'\135'|'\136'|'\137'|'\138'|'\139'|'\140'|'\141'|'\142'|'\143'|'\144'|'\145'|'\146'|'\147'|'\148'|'\149'|'\150'|'\151'|'\152'|'\153'|'\154'|'\155'|'\156'|'\157'|'\158'|'\159'|'\160'|'\161'|'\162'|'\163'|'\164'|'\165'|'\166'|'\167'|'\168'|'\169'|'\170'|'\171'|'\172'|'\173'|'\174'|'\175'|'\176'|'\177'|'\178'|'\179'|'\180'|'\181'|'\182'|'\183'|'\184'|'\185'|'\186'|'\187'|'\188'|'\189'|'\190'|'\191' *)
                  |128|129|130|131|132|133|134|135|136|137|138|139|140|141|142|143|144|145|146|147|148|149|150|151|152|153|154|155|156|157|158|159|160|161|162|163|164|165|166|167|168|169|170|171|172|173|174|175|176|177|178|179|180|181|182|183|184|185|186|187|188|189|190|191 ->
                    (* *)
                    lexbuf.Lexing.lex_curr_pos <- _curr;
                    lexbuf.Lexing.lex_last_pos <- _last;
                    3
                  | _ ->
                    let _curr = _last in
                    lexbuf.Lexing.lex_curr_pos <- _curr;
                    lexbuf.Lexing.lex_last_pos <- _last;
                    5 (* = last_action *)
                end
              | _ ->
                let _curr = _last in
                lexbuf.Lexing.lex_curr_pos <- _curr;
                lexbuf.Lexing.lex_last_pos <- _last;
                5 (* = last_action *)
            end
          | _ ->
            let _curr = _last in
            lexbuf.Lexing.lex_curr_pos <- _curr;
            lexbuf.Lexing.lex_last_pos <- _last;
            5 (* = last_action *)
        end
      (* |'\237' *)
      | 237 ->
        (* *)
        let _last = _curr in
        let _last_action = 5 in
        let next_char, _buf, _len, _curr, _last =
          if _curr >= _len then
            __ocaml_lex_refill_buf lexbuf _buf _len _curr _last
          else
            Char.code (Bytes.unsafe_get _buf _curr),
            _buf, _len, (_curr + 1), _last
        in
        begin match next_char with
          (* |'\128'|'\129'|'\130'|'\131'|'\132'|'\133'|'\134'|'\135'|'\136'|'\137'|'\138'|'\139'|'\140'|'\141'|'\142'|'\143'|'\144'|'\145'|'\146'|'\147'|'\148'|'\149'|'\150'|'\151'|'\152'|'\153'|'\154'|'\155'|'\156'|'\157'|'\158'|'\159' *)
          |128|129|130|131|132|133|134|135|136|137|138|139|140|141|142|143|144|145|146|147|148|149|150|151|152|153|154|155|156|157|158|159 ->
            let next_char, _buf, _len, _curr, _last =
              if _curr >= _len then
                __ocaml_lex_refill_buf lexbuf _buf _len _curr _last
              else
                Char.code (Bytes.unsafe_get _buf _curr),
                _buf, _len, (_curr + 1), _last
            in
            begin match next_char with
              (* |'\128'|'\129'|'\130'|'\131'|'\132'|'\133'|'\134'|'\135'|'\136'|'\137'|'\138'|'\139'|'\140'|'\141'|'\142'|'\143'|'\144'|'\145'|'\146'|'\147'|'\148'|'\149'|'\150'|'\151'|'\152'|'\153'|'\154'|'\155'|'\156'|'\157'|'\158'|'\159'|'\160'|'\161'|'\162'|'\163'|'\164'|'\165'|'\166'|'\167'|'\168'|'\169'|'\170'|'\171'|'\172'|'\173'|'\174'|'\175'|'\176'|'\177'|'\178'|'\179'|'\180'|'\181'|'\182'|'\183'|'\184'|'\185'|'\186'|'\187'|'\188'|'\189'|'\190'|'\191' *)
              |128|129|130|131|132|133|134|135|136|137|138|139|140|141|142|143|144|145|146|147|148|149|150|151|152|153|154|155|156|157|158|159|160|161|162|163|164|165|166|167|168|169|170|171|172|173|174|175|176|177|178|179|180|181|182|183|184|185|186|187|188|189|190|191 ->
                (* *)
                lexbuf.Lexing.lex_curr_pos <- _curr;
                lexbuf.Lexing.lex_last_pos <- _last;
                3
              | _ ->
                let _curr = _last in
                lexbuf.Lexing.lex_curr_pos <- _curr;
                lexbuf.Lexing.lex_last_pos <- _last;
                5 (* = last_action *)
            end
          | _ ->
            let _curr = _last in
            lexbuf.Lexing.lex_curr_pos <- _curr;
            lexbuf.Lexing.lex_last_pos <- _last;
            5 (* = last_action *)
        end
      (* |'\n' *)
      | 10 ->
        (* *)
        lexbuf.Lexing.lex_curr_pos <- _curr;
        lexbuf.Lexing.lex_last_pos <- _last;
        2
      (* |'\128'|'\129'|'\130'|'\131'|'\132'|'\133'|'\134'|'\135'|'\136'|'\137'|'\138'|'\139'|'\140'|'\141'|'\142'|'\143'|'\144'|'\145'|'\146'|'\147'|'\148'|'\149'|'\150'|'\151'|'\152'|'\153'|'\154'|'\155'|'\156'|'\157'|'\158'|'\159'|'\160'|'\161'|'\162'|'\163'|'\164'|'\165'|'\166'|'\167'|'\168'|'\169'|'\170'|'\171'|'\172'|'\173'|'\174'|'\175'|'\176'|'\177'|'\178'|'\179'|'\180'|'\181'|'\182'|'\183'|'\184'|'\185'|'\186'|'\187'|'\188'|'\189'|'\190'|'\191'|'\192'|'\193'|'\245'|'\246'|'\247'|'\248'|'\249'|'\250'|'\251'|'\252'|'\253'|'\254'|'\255' *)
      |128|129|130|131|132|133|134|135|136|137|138|139|140|141|142|143|144|145|146|147|148|149|150|151|152|153|154|155|156|157|158|159|160|161|162|163|164|165|166|167|168|169|170|171|172|173|174|175|176|177|178|179|180|181|182|183|184|185|186|187|188|189|190|191|192|193|245|246|247|248|249|250|251|252|253|254|255 ->
        (* *)
        lexbuf.Lexing.lex_curr_pos <- _curr;
        lexbuf.Lexing.lex_last_pos <- _last;
        5
      (* |eof *)
      | 256 ->
        (* *)
        lexbuf.Lexing.lex_curr_pos <- _curr;
        lexbuf.Lexing.lex_last_pos <- _last;
        4
      (* |'\225'|'\226'|'\227'|'\228'|'\229'|'\230'|'\231'|'\232'|'\233'|'\234'|'\235'|'\236'|'\238'|'\239' *)
      |225|226|227|228|229|230|231|232|233|234|235|236|238|239 ->
        (* *)
        let _last = _curr in
        let _last_action = 5 in
        let next_char, _buf, _len, _curr, _last =
          if _curr >= _len then
            __ocaml_lex_refill_buf lexbuf _buf _len _curr _last
          else
            Char.code (Bytes.unsafe_get _buf _curr),
            _buf, _len, (_curr + 1), _last
        in
        begin match next_char with
          (* |'\128'|'\129'|'\130'|'\131'|'\132'|'\133'|'\134'|'\135'|'\136'|'\137'|'\138'|'\139'|'\140'|'\141'|'\142'|'\143'|'\144'|'\145'|'\146'|'\147'|'\148'|'\149'|'\150'|'\151'|'\152'|'\153'|'\154'|'\155'|'\156'|'\157'|'\158'|'\159'|'\160'|'\161'|'\162'|'\163'|'\164'|'\165'|'\166'|'\167'|'\168'|'\169'|'\170'|'\171'|'\172'|'\173'|'\174'|'\175'|'\176'|'\177'|'\178'|'\179'|'\180'|'\181'|'\182'|'\183'|'\184'|'\185'|'\186'|'\187'|'\188'|'\189'|'\190'|'\191' *)
          |128|129|130|131|132|133|134|135|136|137|138|139|140|141|142|143|144|145|146|147|148|149|150|151|152|153|154|155|156|157|158|159|160|161|162|163|164|165|166|167|168|169|170|171|172|173|174|175|176|177|178|179|180|181|182|183|184|185|186|187|188|189|190|191 ->
            let next_char, _buf, _len, _curr, _last =
              if _curr >= _len then
                __ocaml_lex_refill_buf lexbuf _buf _len _curr _last
              else
                Char.code (Bytes.unsafe_get _buf _curr),
                _buf, _len, (_curr + 1), _last
            in
            begin match next_char with
              (* |'\128'|'\129'|'\130'|'\131'|'\132'|'\133'|'\134'|'\135'|'\136'|'\137'|'\138'|'\139'|'\140'|'\141'|'\142'|'\143'|'\144'|'\145'|'\146'|'\147'|'\148'|'\149'|'\150'|'\151'|'\152'|'\153'|'\154'|'\155'|'\156'|'\157'|'\158'|'\159'|'\160'|'\161'|'\162'|'\163'|'\164'|'\165'|'\166'|'\167'|'\168'|'\169'|'\170'|'\171'|'\172'|'\173'|'\174'|'\175'|'\176'|'\177'|'\178'|'\179'|'\180'|'\181'|'\182'|'\183'|'\184'|'\185'|'\186'|'\187'|'\188'|'\189'|'\190'|'\191' *)
              |128|129|130|131|132|133|134|135|136|137|138|139|140|141|142|143|144|145|146|147|148|149|150|151|152|153|154|155|156|157|158|159|160|161|162|163|164|165|166|167|168|169|170|171|172|173|174|175|176|177|178|179|180|181|182|183|184|185|186|187|188|189|190|191 ->
                (* *)
                lexbuf.Lexing.lex_curr_pos <- _curr;
                lexbuf.Lexing.lex_last_pos <- _last;
                3
              | _ ->
                let _curr = _last in
                lexbuf.Lexing.lex_curr_pos <- _curr;
                lexbuf.Lexing.lex_last_pos <- _last;
                5 (* = last_action *)
            end
          | _ ->
            let _curr = _last in
            lexbuf.Lexing.lex_curr_pos <- _curr;
            lexbuf.Lexing.lex_last_pos <- _last;
            5 (* = last_action *)
        end
      (* |'\194'|'\195'|'\196'|'\197'|'\198'|'\199'|'\200'|'\201'|'\202'|'\203'|'\204'|'\205'|'\206'|'\207'|'\208'|'\209'|'\210'|'\211'|'\212'|'\213'|'\214'|'\215'|'\216'|'\217'|'\218'|'\219'|'\220'|'\221'|'\222'|'\223' *)
      |194|195|196|197|198|199|200|201|202|203|204|205|206|207|208|209|210|211|212|213|214|215|216|217|218|219|220|221|222|223 ->
        (* *)
        let _last = _curr in
        let _last_action = 5 in
        let next_char, _buf, _len, _curr, _last =
          if _curr >= _len then
            __ocaml_lex_refill_buf lexbuf _buf _len _curr _last
          else
            Char.code (Bytes.unsafe_get _buf _curr),
            _buf, _len, (_curr + 1), _last
        in
        begin match next_char with
          (* |'\128'|'\129'|'\130'|'\131'|'\132'|'\133'|'\134'|'\135'|'\136'|'\137'|'\138'|'\139'|'\140'|'\141'|'\142'|'\143'|'\144'|'\145'|'\146'|'\147'|'\148'|'\149'|'\150'|'\151'|'\152'|'\153'|'\154'|'\155'|'\156'|'\157'|'\158'|'\159'|'\160'|'\161'|'\162'|'\163'|'\164'|'\165'|'\166'|'\167'|'\168'|'\169'|'\170'|'\171'|'\172'|'\173'|'\174'|'\175'|'\176'|'\177'|'\178'|'\179'|'\180'|'\181'|'\182'|'\183'|'\184'|'\185'|'\186'|'\187'|'\188'|'\189'|'\190'|'\191' *)
          |128|129|130|131|132|133|134|135|136|137|138|139|140|141|142|143|144|145|146|147|148|149|150|151|152|153|154|155|156|157|158|159|160|161|162|163|164|165|166|167|168|169|170|171|172|173|174|175|176|177|178|179|180|181|182|183|184|185|186|187|188|189|190|191 ->
            (* *)
            lexbuf.Lexing.lex_curr_pos <- _curr;
            lexbuf.Lexing.lex_last_pos <- _last;
            3
          | _ ->
            let _curr = _last in
            lexbuf.Lexing.lex_curr_pos <- _curr;
            lexbuf.Lexing.lex_last_pos <- _last;
            5 (* = last_action *)
        end
      | _ ->
        (* *)
        lexbuf.Lexing.lex_curr_pos <- _curr;
        lexbuf.Lexing.lex_last_pos <- _last;
        3
    end
  in
  begin
    let _curr_p = lexbuf.Lexing.lex_curr_p in
    if _curr_p != Lexing.dummy_pos then begin
      lexbuf.Lexing.lex_start_p <- _curr_p;
      lexbuf.Lexing.lex_curr_p <-
        {_curr_p with Lexing.pos_cnum =
         lexbuf.Lexing.lex_abs_pos+lexbuf.Lexing.lex_curr_pos}
    end
  end;
  match __ocaml_lex_result with
  | 0 ->
# 714 "text/lexer.mll"
         ( () )
# 5247 "text/lexer.ml"

  | 1 ->
# 715 "text/lexer.mll"
         ( comment (Lexing.lexeme_start_p lexbuf) lexbuf; comment start lexbuf )
# 5252 "text/lexer.ml"

  | 2 ->
# 716 "text/lexer.mll"
         ( Lexing.new_line lexbuf; comment start lexbuf )
# 5257 "text/lexer.ml"

  | 3 ->
# 717 "text/lexer.mll"
               ( comment start lexbuf )
# 5262 "text/lexer.ml"

  | 4 ->
# 718 "text/lexer.mll"
        ( error_nest start lexbuf "unclosed comment" )
# 5267 "text/lexer.ml"

  | 5 ->
# 719 "text/lexer.mll"
      ( error lexbuf "malformed UTF-8 encoding" )
# 5272 "text/lexer.ml"

  | _ -> raise (Failure "lexing: empty token")


;;

